package cvc3;

import java.util.*;

public class ContextMut extends Context {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public ContextMut(Object ContextMut, EmbeddedManager embeddedManager) {
	super(ContextMut, embeddedManager);
    }

    
    /// API (mutable)
}
