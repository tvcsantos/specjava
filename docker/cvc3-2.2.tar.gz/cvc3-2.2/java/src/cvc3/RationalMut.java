package cvc3;

import java.util.*;

public class RationalMut extends Rational {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public RationalMut(Object RationalMut, EmbeddedManager embeddedManager) {
	super(RationalMut, embeddedManager);
    }

    
    /// API (mutable)
}
