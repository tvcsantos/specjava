package cvc3;

import java.util.*;

public class Proof extends Embedded {
    // jni methods

    /// Constructor

    public Proof(Object Proof, EmbeddedManager embeddedManager) {
	super(Proof, embeddedManager);
    }


    /// API (immutable)

}
