package cvc3;

import java.util.*;

public class TypeMut extends Type {
    // jni methods
    
    
    /// Constructor

    // create embedded object
    public TypeMut(Object TypeMut, EmbeddedManager embeddedManager) {
	super(TypeMut, embeddedManager);
    }

    
    /// API (mutable)
}
