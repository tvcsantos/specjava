void testgeorge1();
void testgeorge2();
void testgeorge3();
void testgeorge4();
void testgeorge5();
