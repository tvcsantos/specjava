package specjava.visit;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;
import specjava.types.SpecJavaContext;

public class VariableVisitor extends ContextVisitor {
	
	public Set vars = new HashSet();

	public VariableVisitor(Job job, TypeSystem ts, NodeFactory nf) {
		super(job, ts, nf);
	}
	
	protected Node leaveCall(Node old, Node n, NodeVisitor v)
			throws SemanticException {
		vars.addAll(((SpecJavaContext)context()).variablesInScope());		
		return n;
	}
}