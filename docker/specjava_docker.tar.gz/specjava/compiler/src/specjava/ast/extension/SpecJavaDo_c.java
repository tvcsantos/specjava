package specjava.ast.extension;

import polyglot.ast.Do_c;
import polyglot.ast.Expr;
import polyglot.ast.Node;
import polyglot.ast.NodeList;
import polyglot.ast.Stmt;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.procedure.LoopInvariantNode;

/**
 * A immutable representation of a SpecJava language <code>do</code> statement.
 * It contains a statement to be executed and an expression to be tested 
 * indicating whether to reexecute the statement,
 * and has an invariant associated. 
 */ 
public class SpecJavaDo_c extends Do_c implements SpecJavaLoop {

	protected LoopInvariantNode inv;
	
	public SpecJavaDo_c(Position pos, Stmt body, Expr cond, LoopInvariantNode inv) {
		super(pos, body, cond);
		assert (inv != null);
		this.inv = inv;		
	}
	
	public LoopInvariantNode invariant() {
		return inv;
	}

	public SpecJavaLoop invariant(LoopInvariantNode inv) {
		SpecJavaDo_c n = (SpecJavaDo_c) copy();
		n.inv = inv;
		return n;
	}
	
	protected SpecJavaDo_c reconstruct(Stmt body, Expr cond, LoopInvariantNode inv) {
		if (inv != this.inv) {
			SpecJavaDo_c n = (SpecJavaDo_c) copy();
			n.inv = inv;
			return (SpecJavaDo_c) n.reconstruct(body, cond);
		}

		return (SpecJavaDo_c) super.reconstruct(body, cond);
	}
	
	public Node visitChildren(NodeVisitor v) {
		Node body = visitChild(this.body, v);
		if (body instanceof NodeList)
			body = ((NodeList) body).toBlock();
		Expr cond = (Expr) visitChild(this.cond, v);
		LoopInvariantNode inv = (LoopInvariantNode) visitChild(this.inv, v);
		return reconstruct((Stmt) body, cond, inv);
	}
}
