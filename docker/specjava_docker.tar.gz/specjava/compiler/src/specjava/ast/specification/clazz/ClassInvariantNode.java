package specjava.ast.specification.clazz;

import specjava.ast.specification.formula.DualNode;

/**
 * Interface representing a class invariant
 * specification node.
 */
public interface ClassInvariantNode extends ClassSpecificationNode {
	/**
	 * Set the dual node of
	 * the specification node.
	 */
	ClassInvariantNode dualNode(DualNode dn);
}