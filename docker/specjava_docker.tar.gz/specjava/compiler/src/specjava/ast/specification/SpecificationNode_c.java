package specjava.ast.specification;

import polyglot.ast.Node_c;
import polyglot.util.Position;

/**
 * Abstract class that represents the base of all
 * SpecJava specification nodes.
 */
public abstract class SpecificationNode_c extends 
	Node_c implements SpecificationNode {

	public SpecificationNode_c(Position pos) {
		super(pos);
	}
}
