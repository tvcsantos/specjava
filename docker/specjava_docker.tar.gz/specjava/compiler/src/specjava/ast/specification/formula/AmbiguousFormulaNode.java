package specjava.ast.specification.formula;

import polyglot.ast.Ambiguous;
import specjava.ast.specification.formula.atomic.SinglePropertyNode;

/**
 * Interface representing an ambiguous
 * FormulaNode.
 */
public interface AmbiguousFormulaNode extends SinglePropertyNode, Ambiguous { }
