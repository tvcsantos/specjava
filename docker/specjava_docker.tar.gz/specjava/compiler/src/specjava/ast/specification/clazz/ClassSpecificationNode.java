package specjava.ast.specification.clazz;

import polyglot.ast.ClassMember;
import specjava.ast.specification.SpecificationNode;
import specjava.ast.specification.formula.DualNode;

/**
 * Interface that represents the base of all
 * SpecJava class specification nodes.
 */
public interface ClassSpecificationNode extends SpecificationNode, ClassMember {
	ClassSpecificationNode dualNode(DualNode dn);
}
