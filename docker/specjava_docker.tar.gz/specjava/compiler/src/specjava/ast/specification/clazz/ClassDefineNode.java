package specjava.ast.specification.clazz;

import polyglot.ast.Id;
import specjava.ast.specification.formula.DualNode;
import specjava.types.Property;

/**
 * Interface representing a class state
 * definition node.
 */
public interface ClassDefineNode extends ClassSpecificationNode {
	/**
	 * The name of the state.
	 */
	Id id();
	
	/**
	 * Set the name of the state.
	 */
	ClassDefineNode id(Id id);
	
	/**
	 * The property/state type.
	 */
	Property property();
	
	/**
	 * Set the property/state type.
	 */
	ClassDefineNode property(Property prop);
		
	/**
	 * Set the dual node of
	 * the definition node.
	 * If null then is abstract definition
	 * otherwise is concrete.
	 */
	ClassDefineNode dualNode(DualNode dn);
}
