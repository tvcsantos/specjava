package specjava.ast.specification.formula;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.ast.Unary;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeChecker;
import specjava.logic.formula.unary.Not;

/**
 * Class implementing UnaryFormulaNode.
 */
public class UnaryFormulaNode_c extends FormulaNode_c implements UnaryFormulaNode {
	
	protected Unary.Operator op;
	protected FormulaNode fnode;
	
	public UnaryFormulaNode_c(Position pos, Unary.Operator op,
			FormulaNode fnode) {
		super(pos);
		assert(op != null && fnode != null);
		this.op = op;
		this.fnode = fnode;
	}
	
	public Precedence precedence() {
		return Precedence.UNARY;
	}

	public polyglot.ast.Unary.Operator operator() {
		return this.op;
	}

	public UnaryFormulaNode operator(polyglot.ast.Unary.Operator op) {
		UnaryFormulaNode_c n = (UnaryFormulaNode_c) copy();
		n.op = op;
		return n;
	}

	public FormulaNode formulaNode() {
		return this.fnode;
	}

	public UnaryFormulaNode formulaNode(FormulaNode fn) {
		UnaryFormulaNode_c n = (UnaryFormulaNode_c) copy();
		n.fnode = fn;
		return n;
	}
	
	public UnaryFormulaNode_c reconstruct(FormulaNode fn) {
        if (this.fnode != fn) {
            UnaryFormulaNode_c n = (UnaryFormulaNode_c) copy();
            n.fnode = fn;
            n.op = op;
            return n;
        }

        return this;
    }
	
	public Node visitChildren(NodeVisitor v) {
		FormulaNode fnode = (FormulaNode) visitChild(this.fnode, v);
		return reconstruct(fnode);
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		UnaryFormulaNode_c n = (UnaryFormulaNode_c) super.typeCheck(tc);
		return n.formula(new Not(n.fnode.formula()));
	}
	
	public String toString() {
		return op.toString() + fnode;
	}
}
