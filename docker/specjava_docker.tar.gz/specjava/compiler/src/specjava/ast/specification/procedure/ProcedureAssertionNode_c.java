package specjava.ast.specification.procedure;

import polyglot.ast.Node;
import polyglot.ast.Node_c;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.formula.DualNode;

/**
 * Class implementing ProcedureAssertionNode.
 */
public class ProcedureAssertionNode_c extends Node_c implements ProcedureAssertionNode {

	protected DualNode dual;
	protected boolean requires;	
	
	public ProcedureAssertionNode_c(Position pos, DualNode dual, boolean requires) {
		super(pos);
		assert(dual != null);
		this.dual = dual;
		this.requires = requires;
	}
	
	public ProcedureAssertionNode_c(Position pos) {
		super(pos);
	}
	
	public boolean isRequires() {
		return requires;
	}
	
	public boolean isEnsures() {
		return !requires;
	}
	
	public ProcedureAssertionNode_c reconstruct(DualNode dual) {
        if (this.dual != dual) {
            ProcedureAssertionNode_c n = (ProcedureAssertionNode_c) copy();
            n.dual = dual;
            return n;
        }

        return this;
    }
	
	public Node visitChildren(NodeVisitor v) {
		DualNode dual = (DualNode) visitChild(this.dual, v);
		return reconstruct(dual);
	}
	
	public DualNode dualNode() {
		return dual;
	}

	public ProcedureAssertionNode dualNode(DualNode dn) {
		ProcedureAssertionNode_c n = (ProcedureAssertionNode_c) copy();
		n.dual = dn;
		return n;
	}
	
	public String toString() {
		if (isEnsures())
			return "ensures " + dual;
		else return "requires " + dual;
	}
}
