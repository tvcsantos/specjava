package specjava.ast.specification.clazz;

import java.util.List;

import polyglot.ast.Id;
import polyglot.ast.Node;
import polyglot.ast.Term;
import polyglot.types.Context;
import polyglot.types.MemberInstance;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.CFGBuilder;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeBuilder;
import polyglot.visit.TypeChecker;
import specjava.ast.specification.formula.DualNode;
import specjava.logic.DualLogic;
import specjava.logic.formula.Dual;
import specjava.logic.formula.DualImpl;
import specjava.types.Property;
import specjava.types.SpecJavaContext;
import specjava.types.SpecJavaParsedClassType;
import specjava.types.SpecJavaTypeSystem;

/**
 * Class implementing ClassDefineNode.
 */
public class ClassDefineNode_c extends ClassSpecificationNode_c 
	implements ClassDefineNode {
	
	protected Property p;
	protected Id id;
	protected DualNode dual;
	
	public ClassDefineNode_c(Position pos, Id id, DualNode dual) {
		super(pos);
		assert(id != null);
		this.id = id;
		this.dual = dual;
	}
	
	public DualNode dualNode() {
		return dual;
	}
	
	public MemberInstance memberInstance() {
		return null;
	}

	public List acceptCFG(CFGBuilder v, List succs) {
		return succs;
	}

	public Term firstChild() {
		return null;
	}
	
	protected ClassDefineNode_c reconstruct(Id id, DualNode dual) {
		if (id != this.id || dual != this.dual) {
			ClassDefineNode_c n = (ClassDefineNode_c) copy();
			n.id = id;
			n.dual = dual;
			return n;
		}

		return this;
	}
	
	public Node visitChildren(NodeVisitor v) {
		Id id = (Id) visitChild(this.id, v);
		DualNode dual = (DualNode) visitChild(this.dual, v);
		return reconstruct(id, dual);
	}
	
	public ClassDefineNode dualNode(DualNode dn) {
		ClassDefineNode_c n = (ClassDefineNode_c) copy();
		n.dual = dn;
		return n;
	}
	
	public Node buildTypes(TypeBuilder tb) throws SemanticException {
		ClassDefineNode_c n = (ClassDefineNode_c) super.buildTypes(tb);
		
		SpecJavaTypeSystem sjts = (SpecJavaTypeSystem) tb.typeSystem();
		
		Property p = null;
		
		SpecJavaParsedClassType type = (SpecJavaParsedClassType) tb.currentClass();
		
		if (id.id().compareTo("pos") == 0)
			p = sjts.NumberProperty(id.position(), Property.POS);
		else if (id.id().compareTo("neg") == 0)
			p = sjts.NumberProperty(id.position(), Property.NEG);
		else if (id.id().compareTo("zero") == 0)
			p = sjts.NumberProperty(id.position(), Property.ZERO);
		else if (id.id().compareTo("true") == 0)
			p = sjts.BooleanProperty(id.position(), true);
		else if (id.id().compareTo("false") == 0)
			p = sjts.BooleanProperty(id.position(), false);
		else if (id.id().compareTo("null") == 0)
			p = sjts.NullProperty(id.position());
		else // NAMED PROPERTY
			p = sjts.NamedProperty(id.position(), id.id(), type);
						
		type.addProperty(p);

		return n.property(p);
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		ClassDefineNode_c n = (ClassDefineNode_c) super.typeCheck(tc);
		
		SpecJavaParsedClassType sjpct = (SpecJavaParsedClassType) tc.context().currentClass();
		
		Dual d = null;
		if (n.dual != null)
			d = new DualImpl(n.dual.classicFormula().formula(),
				DualLogic.getFormulas(n.dual.sepLogicFormulas()));
		
		sjpct.mapDefine(n.property(), d);
		
		return n;
	}
	
	public void addDecls(Context c) {
		SpecJavaContext fsjc = (SpecJavaContext) c;
		fsjc.addProperty(p);
	}
	
	public Property property() {
		return p;
	}

	public ClassDefineNode property(Property prop) {
		ClassDefineNode_c n = (ClassDefineNode_c) copy();
		n.p = prop;
		return n;
	}
	
	public Id id() {
		return id;
	}

	public ClassDefineNode id(Id id) {
		ClassDefineNode_c n = (ClassDefineNode_c) copy();
		n.id = id;
		return n;
	}
	
	public String toString() {
		String res = "define " + id;
		if (dual != null) res += " = " + dual;
		res += ";";
		return res;
	}

}
