package specjava.ast.specification.procedure;

import polyglot.ast.Stmt;
import specjava.ast.specification.SpecificationNode;
import specjava.ast.specification.formula.DualNode;

/**
 * An immutable representation of a <code>assume</code> statement.
 * This statement behaves like empty statement and it is used
 * only at compile time for specifications.
 */
public interface Assume extends Stmt, SpecificationNode {
	/**
	 * Set the dual node of
	 * the assume node.
	 */
	Assume dualNode(DualNode dn);
}
