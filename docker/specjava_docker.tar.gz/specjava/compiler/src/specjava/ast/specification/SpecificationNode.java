package specjava.ast.specification;

import polyglot.ast.Node;
import specjava.ast.specification.formula.DualNode;

/**
 * Interface that represents the base of all
 * SpecJava specification nodes.
 */
public interface SpecificationNode extends Node {
	/**
	 * The dual node associated
	 * to this specification node.
	 */
	DualNode dualNode();
	
	/**
	 * Set the dual node of
	 * the specification node.
	 */
	SpecificationNode dualNode(DualNode dn);
}
