package specjava.ast.specification.formula;

import polyglot.ast.Id;
import polyglot.ast.Node;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.TypeChecker;
import specjava.ast.factory.SpecJavaNodeFactory;
import specjava.ast.specification.formula.atomic.SinglePropertyNode_c;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode;
import specjava.logic.formula.Formula;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.SpecialTerm;
import specjava.types.Property;
import specjava.types.SpecJavaContext;

public class AmbiguousFormulaNode_c extends SinglePropertyNode_c implements
		AmbiguousFormulaNode {
	
	public AmbiguousFormulaNode_c(Position pos, Id prop) {
		super(pos, prop);
	}
		
	public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
		SpecJavaContext sjc = (SpecJavaContext) ar.context();
		SpecJavaNodeFactory sjnf = (SpecJavaNodeFactory) ar.nodeFactory();
		String id = prop.id();
		Property p = sjc.findPropertySilent(id);
		if (p == null) {
			if (id.compareTo("true") == 0 || id.compareTo("false") == 0) {
				boolean b = Boolean.parseBoolean(id);
				return sjnf.TruthConstantNode(position, b).formula(
						b ? Formula.TRUE : Formula.FALSE);
			}
			throw new SemanticException("Property \"" + id + "\" not found.");
		}
		/* Disambiguate in a property of "this" class */
		SpecialPropertyNode spn = sjnf.ThisPropertyNode(position, prop);
		spn = (SpecialPropertyNode) spn.formula(new StatePredicate(
				spn.property().id(), new SpecialTerm(spn.kind(),
						ar.typeSystem().unknownType(position()))));
		return spn;
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		return this;
	}
	
	public String toString() {
		return prop + "{amb}";
	}

}
