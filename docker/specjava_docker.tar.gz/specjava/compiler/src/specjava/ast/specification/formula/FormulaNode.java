package specjava.ast.specification.formula;

import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.util.CodeWriter;
import polyglot.visit.PrettyPrinter;
import specjava.logic.formula.Formula;

public interface FormulaNode extends Node {	
	public static final Precedence IMPLY		= new Precedence("=>", 132);
	public static final Precedence EQUIVALENT	= new Precedence("<=>", 138);

	/** Get the precedence of the FormulaNode. */
    Precedence precedence();
    
	/**
     * Correctly parenthesize the sub-formula <code>form</code>
     * based on its precedence and the precedence of this expression.
     *
     * If the sub-property has the same precedence as this property
     * we parenthesize if the sub-property does not associate; e.g.,
     * we parenthesis the right sub-property of a left-associative
     * operator.
     */
     void printSubForm(FormulaNode form, boolean associative,
                       CodeWriter w, PrettyPrinter pp);

    /**
     * Correctly parenthesize the sub-property <code>form</code>
     * based on its precedence and the precedence of this expression.
     *
     * This is equivalent to <code>printSubForm(form, true, w, pp)</code>
     */
    void printSubForm(FormulaNode form, CodeWriter w, PrettyPrinter pp);
    
    Formula formula();
    
    FormulaNode formula(Formula formula);
}
