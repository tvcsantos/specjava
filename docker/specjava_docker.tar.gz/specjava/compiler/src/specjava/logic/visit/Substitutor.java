package specjava.logic.visit;

import polyglot.ast.Expr;
import polyglot.ast.Node;
import polyglot.ast.Special;
import polyglot.ast.Variable;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode.Kind;
import specjava.logic.formula.term.SpecialTerm;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;

public class Substitutor extends AbstractPLVisitor {
	
	public String toString() {
		return "[" + x + "/" + (y == null ? t : y) + "]";
	}

	protected String x;
	protected Variable y;
	protected String ex;
	protected Term t;
	protected final Replacer rep;
	
	public Substitutor(Variable x, Variable y) {
		this(x.toString(), y);
	}
	
	public Substitutor(String x, Variable y) {
		this.x = x;
		this.y = y;
		this.t = null;
		this.rep = new Replacer(x, y);
	}
	
	
	public Substitutor(Variable x, Term t) {
		this(x.toString(), t);
	}
	
	public Substitutor(String x, Term t) {
		this.x = x;
		this.t = t;
		if (t instanceof VariableTerm) {
			VariableTerm et = (VariableTerm) t;
			rep = new Replacer(x, et.getExpr());
		}
		else rep = null;
	}
	
	public Term visit(VariableTerm v) {
		Expr expr = v.getExpr();
		if (expr == null) {
			System.out.println("Substitutor.visit()");
			System.err.println("ERRO");
			return v;
		}
		
		if (y != null || (t instanceof VariableTerm)) {
			Expr nexpr = (Expr) expr.visit(rep);
			return new VariableTerm(nexpr);
		}
		
		if (expr instanceof Variable ||
				expr instanceof Special) {
			if (expr.toString().compareTo(x) == 0)
				if (t != null) return t;
				else return new VariableTerm(y);
		}
		
		return v;
	}
	
	public Term visit(SpecialTerm st) {
		Kind k = st.getKind();
		if (x.compareTo(k.toString()) == 0)
			if (t != null) return t;
			else return new VariableTerm(y);
		return st;
	}
	
	private class Replacer extends NodeVisitor {
		
		private String x;
		private Expr e;
		
		public Replacer(String x, Expr e) {
			this.x = x;
			this.e = e;
		}
		
		public Node leave(Node old, Node n, NodeVisitor v) {
			if (n instanceof Variable) {
				Variable va = (Variable) n;
				if (va.toString().compareTo(x) == 0)
					return e;
			} else if (n instanceof Special) {
				Special s = (Special) n;
				if (s.toString().compareTo(x) == 0)
					return e;
			}
			
			return super.leave(old, n, v);
		}
	}
}
