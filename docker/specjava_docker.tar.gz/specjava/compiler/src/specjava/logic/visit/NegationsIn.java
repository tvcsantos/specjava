package specjava.logic.visit;

import specjava.logic.formula.False;
import specjava.logic.formula.Formula;
import specjava.logic.formula.True;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.unary.Not;

public class NegationsIn extends AbstractPLVisitor {

	public Formula visit(Not fs) throws VisitorException {
		Formula s = fs.getNegated();
		
		// Double negation elimination	~(~a) = a	
		if (s instanceof Not)
		{
			return (Formula) ((Not)s).getNegated().accept(this);
		}
		
		// Atomic ~true = false
		if (s instanceof True)
			return Formula.FALSE;
		
		// Atomic ~false = true		
		if (s instanceof False)
			return Formula.TRUE;
		
		// De Morgan Law ~(a and b) = ~a or ~b
		if (s instanceof And) {
			And a = (And)s;
			Formula sl = (Formula) new Not(a.getLeft()).accept(this);
			Formula sr = (Formula) new Not(a.getRight()).accept(this);
			return new Or(sl, sr);
		}
		
		// De Morgan Law ~(a or b) = ~a and ~b
		if (s instanceof Or) {
			Or a = (Or)s;
			Formula sl = (Formula) new Not(a.getLeft()).accept(this);
			Formula sr = (Formula) new Not(a.getRight()).accept(this);
			return new And(sl, sr);
		}
		
		return fs;
	}
}
