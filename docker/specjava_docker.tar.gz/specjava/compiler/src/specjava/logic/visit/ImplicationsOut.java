package specjava.logic.visit;

import specjava.logic.formula.Formula;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.unary.Not;

public class ImplicationsOut extends AbstractPLVisitor {
	
	public Formula visit(Equivalence fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		// a <=> b == a => b & b => a
		// transform to implication
		Formula trans = new And(new Implication(sl, sr), new Implication(sr, sl));
		return (Formula) trans.accept(this);
	}

	public Formula visit(Implication fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		return new Or(new Not(sl), sr);
	}
}
