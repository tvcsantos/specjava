package specjava.logic.formula.predicate;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Eq extends AbstractPredicate {
	
	private static final long serialVersionUID = -2108591273464109396L;

	public Eq(Term left, Term right) {
		super(new Term[]{left, right});
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}
