package specjava.logic.formula;

import java.io.Serializable;
import java.util.Set;

import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public interface Formula extends Serializable {
	
	public static final Formula TRUE = new True();
	
	public static final Formula FALSE = new False();
	
	public Object accept(PLVisitor pv) throws VisitorException;
	
	public Formula cnf() throws VisitorException;
	
	public boolean isCanonical();
	
	public Set symbols();
	
	public Set targets();
	
	public Set pureSymbols();
	
	public Set linearSymbols();
}


