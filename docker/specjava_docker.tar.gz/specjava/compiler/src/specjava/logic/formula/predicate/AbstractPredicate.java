package specjava.logic.formula.predicate;

import java.util.HashSet;
import java.util.Set;

import specjava.logic.formula.Formula;
import specjava.logic.formula.term.Term;

public abstract class AbstractPredicate implements Predicate {

	private static final long serialVersionUID = 773681696867732205L;
	
	protected final int arity;
	protected final Term[] terms;
	
	protected AbstractPredicate() {
		this.arity = 0;
		this.terms = new Term[0];
	}
	
	protected AbstractPredicate(Term[] terms) {
		this.arity = terms.length;
		this.terms = terms;
	}
	
	public final int arity() {
		return arity;
	}
	
	public final Term getTerm(int n)
		throws IndexOutOfBoundsException
	{
		if (n < 0 || n >= terms.length)
			throw new IndexOutOfBoundsException();
		return terms[n];
	}
	
	public final Formula cnf() {
		return this;
	}
	
	public final Set symbols() {
		Set res = new HashSet();
		for (int i = 0; i < terms.length; i++) {
			Term t = terms[i];
			res.addAll(t.symbols());			
		}
		return res;
	}
	
	public final Set pureSymbols() {
		Set res = new HashSet();
		for (int i = 0; i < terms.length; i++) {
			Term t = terms[i];
			res.addAll(t.pureSymbols());			
		}
		return res;
	}
	
	public final Set linearSymbols() {
		Set res = new HashSet();
		for (int i = 0; i < terms.length; i++) {
			Term t = terms[i];
			res.addAll(t.linearSymbols());			
		}
		return res;
	}
	
	public final Set targets() {
		Set res = new HashSet();
		for (int i = 0; i < terms.length; i++) {
			Term t = terms[i];
			res.addAll(t.targets());			
		}
		return res;
	}
	
	public final boolean isCanonical() {
		for (int i = 0; i < terms.length; i++)
			if (!terms[i].isCanonical()) return false;
		return true;
	}
	
	public String toString() {
		String name = getClass().getSimpleName();
		String res = name + "(";
		if (terms.length >= 1) res += terms[0].toString();
		for (int i = 1; i < terms.length; i++) {
			Term t = terms[i];
			res += ", " + t.toString();
		}
		return res + ")";
	}
}
