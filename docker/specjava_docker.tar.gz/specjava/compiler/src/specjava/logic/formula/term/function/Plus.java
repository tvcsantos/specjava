package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Plus extends AbstractFunction {

	private static final long serialVersionUID = 2460172241160140464L;

	public Plus(Term t) {
		super(new Term[]{ t });
	}
	
	public Plus(Term left, Term right) {
		super(new Term[]{left, right});
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}
