package specjava.logic;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.Field;
import polyglot.ast.Receiver;
import polyglot.ast.Special;
import polyglot.types.SemanticException;
import polyglot.util.Pair;
import specjava.ast.specification.formula.atomic.FieldPath;
import specjava.logic.formula.Dual;
import specjava.logic.formula.DualImpl;
import specjava.logic.formula.Formula;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.Simplifier;
import specjava.logic.visit.Substitutor;
import specjava.logic.visit.VisitorException;

public class Utils {
	private Utils() {}
	
	public static FieldPath getFieldPathSilent(Field f) {
		try {
			return getFieldPath(f);
		} catch (SemanticException e) {
			return null;
		}
	}
	
	public static FieldPath getFieldPath(Field f) throws SemanticException {
		FieldPath fp = null;
		LinkedList l = new LinkedList();
		Field curr = f;
		while (curr != null) {
			l.add(0, curr.fieldInstance());
			Receiver r = curr.target();
			if (!(r instanceof Field)) {
				if (!(r instanceof Special)) {
					// something wrong
					throw new SemanticException("Wrong target!", r.position());
				} else {
					Special c = (Special)r;
					if (c.kind() != Special.THIS) {
						// wrong again - we do not allow other Kinds
						throw new SemanticException("Wrong Special Kind!", c.position());
					}
					if (c.qualifier() != null) {
						// wrong again - we do not allow qualifiers
						throw new SemanticException("Qualifier not allowed!", 
								c.qualifier().position());						
					}
					// ok just push type onto the list
					fp = new FieldPath(c.type(), l);
					//l.add(0, c.type());
					curr = null;
				}
			} else {
				Field ff = (Field)r;
				curr = ff;
			}
		}
		return fp;
	}
	
	public static final List visitList(List l, PLVisitor v) throws VisitorException {
		List res = new LinkedList();
		for (Iterator it = l.iterator() ; it.hasNext() ; )
			res.add(((Formula) it.next()).accept(v));
		return res;
	}
		
	public static final Dual visit(Dual d, Simplifier pv) throws VisitorException {
		Formula f = d.classicFormula();
		List l = d.sepLogicFormulas();
		return new DualImpl((Formula)f.accept(pv), Utils.visitList(l, pv));
	}
	
	public static final Dual visit(Dual d, Substitutor pv) throws VisitorException {
		Formula f = d.classicFormula();
		List l = d.sepLogicFormulas();
		return new DualImpl((Formula)f.accept(pv), Utils.visitList(l, pv));
	}
	
	public static final List visitDualList(List l, Substitutor pv) 
		throws VisitorException {
		List res = new LinkedList();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Pair p = (Pair) it.next();
			Dual d = (Dual) p.part1();
			Dual nd = visit(d, pv);
			res.add(new Pair(nd, p.part2()));
		}
		return res;
	}
	
	public static final List visitDualList(List/*[Pair[Dual, Position]]*/ l, Simplifier pv) throws VisitorException {
		List res = new LinkedList();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Pair p = (Pair) it.next();
			Dual d = (Dual) p.part1();
			Dual nd = visit(d, pv);
			if (!(nd.classicFormula() == Formula.TRUE
					&& nd.sepLogicFormulas().isEmpty()))
				res.add(new Pair(nd, p.part2()));
		}
		return res;
	}
}
