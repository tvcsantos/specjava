package specjava.extension.statement;

import java.util.List;

import polyglot.ast.Ext;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;

public interface SpecJavaStmtExt extends Ext {
	/**
	 * Calculate the weakest precondition of the statement in respect
	 * to the postcondition in argument. 
	 */
	public Dual wp(WPCalculus calc, Dual post) throws WPCalculusException;
	
	/**
	 * Calculate the verification conditions of the statement in respect
	 * to the postcondition in argument.
	 */
	public List vc(WPCalculus calc, Dual post) throws WPCalculusException;
}
