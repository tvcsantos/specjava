package specjava.extension;

import polyglot.types.SemanticException;
import polyglot.util.Position;

public class WPCalculusException extends SemanticException {

	private static final long serialVersionUID = -7149532980579457201L;

	public WPCalculusException() {
		super();
	}

	public WPCalculusException(Position position) {
		super(position);
	}

	public WPCalculusException(String m, Position position) {
		super(m, position);
	}

	public WPCalculusException(String m, Throwable cause) {
		super(m, cause);
	}

	public WPCalculusException(String m) {
		super(m);
	}

	public WPCalculusException(Throwable cause) {
		super(cause);
	}
	
}
