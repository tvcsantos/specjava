package specjava.extension;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import polyglot.ast.ArrayAccess;
import polyglot.ast.Assign;
import polyglot.ast.Block;
import polyglot.ast.Call;
import polyglot.ast.ConstructorCall;
import polyglot.ast.Do;
import polyglot.ast.Empty;
import polyglot.ast.Eval;
import polyglot.ast.Expr;
import polyglot.ast.Field;
import polyglot.ast.FloatLit;
import polyglot.ast.For;
import polyglot.ast.If;
import polyglot.ast.IntLit;
import polyglot.ast.Local;
import polyglot.ast.LocalDecl;
import polyglot.ast.Loop;
import polyglot.ast.New;
import polyglot.ast.NodeFactory;
import polyglot.ast.NullLit;
import polyglot.ast.Receiver;
import polyglot.ast.Return;
import polyglot.ast.Special;
import polyglot.ast.Stmt;
import polyglot.ast.Synchronized;
import polyglot.ast.Variable;
import polyglot.ast.While;
import polyglot.types.FieldInstance;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.Pair;
import polyglot.util.Position;
import specjava.UniqueID;
import specjava.ast.extension.SpecJavaLoop;
import specjava.ast.specification.formula.DualNode;
import specjava.ast.specification.procedure.Assume;
import specjava.ast.specification.procedure.LoopInvariantNode;
import specjava.ast.specification.procedure.StaticAssert;
import specjava.extension.statement.SpecJavaStmtExt;
import specjava.logic.DualLogic;
import specjava.logic.Utils;
import specjava.logic.formula.AbstractFormula;
import specjava.logic.formula.Dual;
import specjava.logic.formula.DualImpl;
import specjava.logic.formula.Formula;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.formula.term.function.Constant;
import specjava.logic.formula.unary.Not;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.Simplifier;
import specjava.logic.visit.Substitutor;
import specjava.logic.visit.VisitorException;
import specjava.types.SpecJavaClassType;
import specjava.types.SpecJavaFlags;
import specjava.types.SpecJavaProcedureInstance;
import specjava.visit.DeepCopier;

public class WPCalculus {

	protected TypeSystem ts;
	protected NodeFactory nf;
	protected Set vars;
	protected Dual methodpre;
	protected Dual methodpost;
	protected Type type;
	
	public List subs;

	public WPCalculus(NodeFactory nf, TypeSystem ts, Set vars, Type type) {
		this.nf = nf;
		this.ts = ts;
		this.vars = vars;
		this.type = type;
		subs = new LinkedList();
	}
	
	public void setMethodpre(Dual methodpre) {
		this.methodpre = methodpre;
	}

	public void setMethodpost(Dual methodpost) {
		this.methodpost = methodpost;
	}	

	// ////////////////////////////// Utils ////////////////////////////////

	private static List pure(List ys, List ps) {
		List res = new LinkedList();
		for (Iterator yi = ys.iterator(), pi = ps.iterator(); yi.hasNext()
				&& pi.hasNext();) {
			LocalInstance li = (LocalInstance) pi.next();
			Object y = yi.next();
			Type t = li.type();
			if (DualLogic.isPure(t))
				res.add(new Pair(y, li));
		}
		return res;
	}

	private static List linear(List ys, List ps) {
		List res = new LinkedList();
		for (Iterator yi = ys.iterator(), pi = ps.iterator(); yi.hasNext()
				&& pi.hasNext();) {
			LocalInstance li = (LocalInstance) pi.next();
			Object y = yi.next();
			Type t = li.type();
			if (!DualLogic.isPure(t))
				res.add(new Pair(y, li));
		}
		return res;
	}

	private Assign translate(LocalDecl ld) {
		Expr e = ld.init();
		Type t = ld.localInstance().type();
		if (e == null) {
			if (t.isReference()) // null init
				e = nf.NullLit(Position.COMPILER_GENERATED).type(ts.Null());
			else if (t.isBoolean())
				e = nf.BooleanLit(Position.COMPILER_GENERATED, false).type(ts.Boolean());
			else if (t.isChar())
				e = nf.CharLit(Position.COMPILER_GENERATED, (char)0).type(ts.Char());
			else if (t.isLong())
				e = nf.IntLit(Position.COMPILER_GENERATED, IntLit.LONG, 0).type(ts.Long());
			else if (t.isInt())
				e = nf.IntLit(Position.COMPILER_GENERATED, IntLit.INT, 0).type(ts.Int());
			else if (t.isFloat())
				e = nf.FloatLit(Position.COMPILER_GENERATED, FloatLit.FLOAT, 0).type(ts.Float());
			else if (t.isDouble())
				e = nf.FloatLit(Position.COMPILER_GENERATED, FloatLit.DOUBLE, 0).type(ts.Double());
		}
		if (e != null) {
			Local l = (Local) nf.Local(ld.position(),
					nf.Id(ld.position(), ld.name())).localInstance(
					ld.localInstance()).type(ld.localInstance().type());
			Assign a = (Assign) nf.LocalAssign(ld.position(), l, Assign.ASSIGN,
					e).type(l.type());
			return a;
		}
		return null;
	}

	private static Dual assertNotNull(SpecJavaProcedureInstance spi, Dual d) {
		if (d != null)
			return d;
		System.err.println("WARNING: " + spi + " condition is null assuming "
				+ Dual.TRUE_EMPTY);
		return Dual.TRUE_EMPTY;
	}

	private static List assertNotNull(SpecJavaProcedureInstance spi, List l) {
		if (l != null)
			return l;
		System.err.println("WARNING: " + spi + " list is null assuming "
				+ Collections.emptyList());
		return Collections.emptyList();
	}

	public static Variable getFresh(Variable x, Type t, NodeFactory nf, TypeSystem ts, Set vars) {
		if (x == null) {
			Position pos = Position.COMPILER_GENERATED;
			String id = UniqueID.newID("fresh", vars);
			Local l = (Local) nf.Local(pos, nf.Id(pos, id)).localInstance(
					ts.localInstance(pos, Flags.NONE, t, id)).type(t);
			return l;
		}
		Variable fresh = ((Variable) x.visit(new DeepCopier()));
		String nid = UniqueID.newID("fresh", vars);
		if (fresh instanceof Field) {
			Field ff = (Field)fresh;
			FieldInstance fi = ff.fieldInstance();
			fi = fi.name(nid);
			ff = ff.name(nid).fieldInstance(fi);
			return ff;
		} else if (fresh instanceof Local) {
			Local lf = (Local)fresh;
			LocalInstance li = lf.localInstance();
			li = li.name(nid);
			lf = lf.name(nid).localInstance(li);
			return lf;
		} else if (fresh instanceof ArrayAccess) {
			// FIXME support arrays?!
		}
		return x;
	}

	private static void assertNotEquals(Object x, Object y) {
		if (x == y) {
			System.err.println("WARNING: " + x + " and " + y
					+ " are the same object");
		}
	}

	public static final WPCalculusException warp(Exception e, Position p) {
		WPCalculusException ex = new WPCalculusException(e.getMessage(), p);
		ex.initCause(e);
		return ex;
	}
	
	// /////////////////////////////////////////////////////////////////////

	// ////////////////////// Weakest Preconditions ////////////////////////

	public Dual wp(LocalDecl ld, Dual post) throws WPCalculusException {
		try {
			Dual wp = null;
			Assign a = translate(ld);
			if (a != null)
				wp = wp(a, post);
			else
				wp = post;
			Formula cf = wp.classicFormula();
			System.out.println(cf);
			List sep = wp.sepLogicFormulas();

			if (a != null) {
				Variable x = (Variable) a.left();
				Variable fresh = getFresh(x, x.type(), nf, ts, vars);

				assertNotEquals(x, fresh);

				PLVisitor v = new Substitutor(ld.varInstance().name(), fresh);
				subs.add(v);

				if (DualLogic.isPure(ld.declType()))
					cf = (Formula) cf.accept(v);
				else
					sep = Utils.visitList(sep, v);

			}

			Dual res = new DualImpl(cf, sep);
			return res;
		} catch (Exception e) {
			throw warp(e, ld.position());
		}
	}

	public Dual wp(Eval e, Dual post) throws WPCalculusException {
		Expr expr = e.expr();
		if (expr instanceof Assign)
			return wp((Assign) expr, post);
		else if (expr instanceof New)
			return wp(null, (New) expr, post);
		else if (expr instanceof Call) {
			Call mc = (Call) expr;
			MethodInstance mi = mc.methodInstance();
			if (mi.returnType().isVoid() && mi.returnType().isPrimitive())
				return wp(mc, post);
			else
				return wp(null, mc, post);
		} else
			throw new WPCalculusException("Expression not supported", expr
					.position());
	}

	/**
	 * Compute the weakest precondition of assign, null assign,
	 * object creation and method call.
	 */
	private Dual wp(Assign a, Dual post) throws WPCalculusException { // OK
		if (!(a.left() instanceof Variable))
			throw new WPCalculusException("Left side of the assignment " +
					"must be a variable", a.position());
		Variable x = (Variable) a.left();
		Expr eps = a.right();
		if (eps instanceof New) return wp(x, (New) eps, post);
		else if (eps instanceof Call) return wp(x, (Call) eps, post);

		if (DualLogic.isPure(x.type())) return wppure(a, post);
		else return wplinear(a, post);
	}

	/**
	 * Compute the weakest precondition of pure assign.
	 */
	private Dual wppure(Assign a, Dual post) throws WPCalculusException { // OK
		Variable x = (Variable) a.left();
		Expr eps = a.right(); // can be null assign

		// x = eps or x = null -> C[x/eps] or C[x/null]

		Formula cf = post.classicFormula();
		List sep = post.sepLogicFormulas();

		try {
			if (eps.type().isBoolean() && !eps.isConstant()) {
				Formula form = AbstractFormula.boolExprToFormula(eps);
				if (form.linearSymbols().isEmpty()) {
					Formula left = AbstractFormula.boolExprToFormula(x);
					Dual d = new DualImpl(form, new LinkedList());
					d = DualLogic.equivalent(left, d);
					return DualLogic.imply(d, post);
				} else {
					List l = new LinkedList();
					l.add(form);
					Formula left = AbstractFormula.boolExprToFormula(x);
					Dual d = new DualImpl(Formula.TRUE, l);
					d = DualLogic.equivalent(left, d);
					return DualLogic.imply(d, post);
				}
			} else {
			Term et = AbstractFormula.exprToTerm(eps);

			Substitutor sub = new Substitutor(x, et);
			subs.add(sub);
			
			cf = (Formula) cf.accept(sub);
			sep = Utils.visitList(sep, sub);

			Dual res = new DualImpl(cf, sep);
			return res;
			}

		} catch (SemanticException e) {
			throw warp(e, a.position());
		} catch (VisitorException e) {
			throw warp(e, a.position());
		}

	}

	/**
	 * Compute the weakest precondition of linear assign.
	 */
	private Dual wplinear(Assign a, Dual post) throws WPCalculusException { // OK
		Variable x = (Variable) a.left();
		Expr y = a.right(); // can be null assign
		Formula cf = post.classicFormula();
		List sep = post.sepLogicFormulas();

		try {

			// x = y or x = null -> S[x/y] or S[x/null]

			Substitutor sub = new Substitutor(x, new VariableTerm(y));
			subs.add(sub);
			sep = Utils.visitList(sep, sub);

			Dual res = new DualImpl(cf, sep);
			return res;

		} catch (VisitorException e) {
			throw warp(e, a.position());
		}
	}

	/**
	 * Compute the weakest precondition of pure/linear return. Pure return
	 * delegates to {@link WPCalculus#wppure(Return, Dual)}. Linear return
	 * delegates to {@link WPCalculus#wplinear(Return, Dual)}.
	 */
	public Dual wp(Return r, Dual post) throws WPCalculusException { // OK
		/*
		 * ignore post because the postcondition of a return corresponds always
		 * to the method postcondition, since a return corresponds to the end of
		 * the method execution
		 */
		if (DualLogic.isPure(type)) return wppure(r, methodpost);
		else return wplinear(r, methodpost);
	}

	/**
	 * Compute the weakest precondition of pure return and pure null return.
	 */
	private Dual wppure(Return r, Dual post) throws WPCalculusException { // OK
		Expr eps = r.expr(); // can be null return
		Formula cf = post.classicFormula();
		List sep = post.sepLogicFormulas();
			
		try {

			Term et = AbstractFormula.exprToTerm(eps);
			
			Substitutor sub = new Substitutor("return", et);
			subs.add(sub);
			
			cf = (Formula) cf.accept(sub);
			sep = Utils.visitList(sep, sub);

			Dual res = new DualImpl(cf, sep);
			return res;
			
		} catch (SemanticException e) {
			throw warp(e, r.position());
		} catch (VisitorException e) {
			throw warp(e, r.position());
		}
	}

	/**
	 * Compute the weakest precondition of linear return and linear null return.
	 */
	private Dual wplinear(Return r, Dual post) throws WPCalculusException { // OK
		Expr eps = r.expr(); // can be null return

		Formula cf = post.classicFormula();
		List sep = post.sepLogicFormulas();
		
		try {

			Term et = AbstractFormula.exprToTerm(eps);

			PLVisitor vis = new Substitutor("return", et);
			subs.add(vis);

			sep = Utils.visitList(sep, vis);

			Dual res = new DualImpl(cf, sep);
			return res;
			
		} catch (SemanticException e) {
			throw warp(e, r.position());
		} catch (VisitorException e) {
			throw warp(e, r.position());
		}
	}

	/**
	 * Compute the weakest precondition of a loop. Loop wp delegates to
	 * {@link WPCalculus#wp(While, Dual)} if it is a while loop, to
	 * {@link WPCalculus#wp(Do, Dual)} if it is a do loop or to
	 * {@link WPCalculus#wp(For, Dual)} if it is a for loop.
	 */
	public Dual wp(Loop l, Dual post) throws WPCalculusException { // OK
		if (l instanceof While)
			return wp((While) l, post);
		else if (l instanceof Do)
			return wp((Do) l, post);
		else if (l instanceof For)
			return wp((For) l, post);
		/*
		 * should not happen because in Java we only have while, do and for but
		 * check it anyway to avoid wp-calculus errors on possible extensions to
		 * the language
		 */
		else throw new WPCalculusException("Loop type not supported", l.position());
	}

	/**
	 * Compute the weakest precondition of a while loop.
	 */
	private Dual wp(While w, Dual post) throws WPCalculusException { // OK
		SpecJavaLoop l = (SpecJavaLoop) w.del();
		LoopInvariantNode invn = l.invariant();
		DualNode fn = invn.dualNode();
		Formula cf = fn.classicFormula().formula();
		List sep = DualLogic.getFormulas(fn.sepLogicFormulas());

		Dual res = new DualImpl(cf, sep);
		return res;
	}

	/**
	 * Compute the weakest precondition of a for loop.
	 */
	private Dual wp(For f, Dual post) throws WPCalculusException { // OK
		SpecJavaLoop l = (SpecJavaLoop) f.del();
		List list = f.inits();
		LoopInvariantNode invn = l.invariant();
		DualNode fn = invn.dualNode();
		Formula cf = fn.classicFormula().formula();
		List sep = DualLogic.getFormulas(fn.sepLogicFormulas());
		ListIterator it = list.listIterator(list.size());
		Dual wp = new DualImpl(cf, sep);
		while (it.hasPrevious()) {
			Stmt s = (Stmt) it.previous();
			SpecJavaStmtExt sext = (SpecJavaStmtExt) s.ext();
			wp = sext.wp(this, wp);
		}
		return wp;
	}

	/**
	 * Compute the weakest precondition of do while loop.
	 */
	private Dual wp(Do d, Dual post) throws WPCalculusException { // OK
		SpecJavaLoop l = (SpecJavaLoop) d.del();
		Stmt s = l.body();
		SpecJavaStmtExt sext = (SpecJavaStmtExt) s.ext();
		LoopInvariantNode invn = l.invariant();
		DualNode fn = invn.dualNode();
		Formula cf = fn.classicFormula().formula();
		List sep = DualLogic.getFormulas(fn.sepLogicFormulas());
		Dual inv = new DualImpl(cf, sep);
		return sext.wp(this, inv);
	}

	/**
	 * Compute the weakest precondition of conditional statement.
	 */
	public Dual wp(If i, Dual post) throws WPCalculusException { // OK
		SpecJavaStmtExt st1 = (SpecJavaStmtExt) i.consequent().ext();
		Expr eps = i.cond();
		DeepCopier dc = new DeepCopier();
		
		Formula e1,e2;
		try {
			e1 = AbstractFormula.boolExprToFormula((Expr) eps.visit(dc));
			e2 = new Not(AbstractFormula.boolExprToFormula((Expr) eps.visit(dc)));
		} catch(SemanticException e) {
			throw warp(e, i.position());
		}
		
		System.err.println("wp(IF) epsilon = " + e1);
		Dual da1 = st1.wp(this, post);

		Dual db1 = DualLogic.imply(e1, da1);

		Stmt b2 = i.alternative();
		Dual altwp = post;
		if (b2 != null) { // has alternative
			SpecJavaStmtExt st2 = (SpecJavaStmtExt) b2.ext();
			altwp = st2.wp(this, post);
		}
		// else // no alternative
		Dual db2 = DualLogic.imply(e2, altwp);

		Dual res = DualLogic.and(db1, db2);
		return res;
	}

	/**
	 * Compute the weakest precondition of composition statement.
	 */
	public Dual wp(Block b, Dual post) throws WPCalculusException { // OK
		Dual wp = wp(b.statements(), post);
		subs.clear();
		return wp;
	}
	
	private Dual wp(List stmts, Dual post) throws WPCalculusException { // OK
		Dual wp = post;
		ListIterator it = stmts.listIterator(stmts.size());
		Simplifier simpl = new Simplifier();
		System.out.println("----- STARTING BLOCK WP -----");
		while (it.hasPrevious()) {
			Stmt s = (Stmt) it.previous();
			SpecJavaStmtExt sext = (SpecJavaStmtExt) s.ext();
			wp = sext.wp(this, wp);
			try {
				System.out.println(wp = Utils.visit(wp, simpl));
			} catch (VisitorException e) {
				throw warp(e, s.position());
			}
		}
		System.out.println("----- ENDING BLOCK WP -----");
		return wp;
	}

	/**
	 * Compute the weakest precondition of skip/empty statement.
	 */
	public Dual wp(Empty e, Dual post) throws WPCalculusException { // OK
		return post;
	}

	/**
	 * Compute the weakest precondition of static assert.
	 */
	public Dual wp(StaticAssert s, Dual post) throws WPCalculusException { // OK
		DualNode safn = s.dualNode();
		Formula sacf = safn.classicFormula().formula();
		List sasep = DualLogic.getFormulas(safn.sepLogicFormulas());

		Dual sad = new DualImpl(sacf, sasep);

		return DualLogic.and(sad, post);
	}

	/**
	 * Compute the weakest precondition of assume.
	 */
	public Dual wp(Assume a, Dual post) throws WPCalculusException { // OK
		DualNode asfn = a.dualNode();
		Formula ascf = asfn.classicFormula().formula();
		List assep = DualLogic.getFormulas(asfn.sepLogicFormulas());

		Dual asd = new DualImpl(ascf, assep);

		return DualLogic.imply(asd, post);
	}

	/**
	 * Compute the weakest precondition of pure/linear creation. Pure creation
	 * delegates to {@link WPCalculus#wppure(Variable, New, Dual)}. Linear
	 * creation delegates to {@link WPCalculus#wplinear(Variable, New, Dual)}.
	 */
	private Dual wp(Variable x, New n, Dual post) throws WPCalculusException { // XXX OK
		Flags f = n.constructorInstance().flags();
		if (f.contains(SpecJavaFlags.PURE)) return wppure(x, n, post);
		else return wplinear(x, n, post);
	}

	/**
	 * Compute the weakest precondition of pure creation.
	 */
	private Dual wppure(Variable x, New n, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi = 
				(SpecJavaProcedureInstance) n.procedureInstance();
			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List ys = n.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			Type t = null;
			if (x != null) t = x.type();
			else t = n.type();

			Variable fresh = getFresh(x, t, nf, ts, vars);

			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("this", fresh);
			mpostcf = (Formula) mpostcf.accept(sub);
			mpostsep = Utils.visitList(mpostsep, sub);
			
			Substitutor sub2 = null;
			if (x != null) {
				sub2 = new Substitutor(x, fresh);
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}
			
			List pure = pure(ys, ps);
			List linear = linear(ys, ps);

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis);// XXX added
				
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
			}

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}
			
			if (x != null) se.add(x.toString()); //exclude x // XXX added
			
			List hrest = DualLogic.restrict(postsep, se);
			
			if (x != null) hrest = Utils.visitList(hrest, sub2);
			
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
						
			sep.addAll(hex);

			VariableTerm et = null;
			if (fresh instanceof Local) {
				Local l = (Local) fresh;
				et = new VariableTerm(l);
			} else if (fresh instanceof Field) {
				Field f = (Field) fresh;
				et = new VariableTerm(f);
			} else if (fresh instanceof ArrayAccess) {
				// FIXME array support
				System.err.println("ERROR @ wp pure object creation");
			}

			StatePredicate sp = new StatePredicate("null", et);

			Formula cf = new And(mprecf, new Implication(new And(new Not(sp),
					mpostcf), postcf));

			Dual res = new DualImpl(cf, sep);
			return res;
		} catch (VisitorException e) {
			throw warp(e, n.position());
		}
	}

	/**
	 * Compute the weakest precondition of linear creation.
	 */
	private Dual wplinear(Variable x, New n, Dual post) // OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) n.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List ys = n.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(ys, ps);
			List linear = linear(ys, ps);
			
			Type t = null;
			if (x != null) t = x.type();
			else t = n.type();

			Variable fresh = getFresh(x, t, nf, ts, vars);

			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("this", fresh);
			mpostcf = (Formula) mpostcf.accept(sub);
			
			if (x != null) {
				Substitutor sub2 = new Substitutor(x, fresh);
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();				
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}		

			if (x != null) se.add(x.toString());
			List sep = DualLogic.exclude(postsep, se);
			sep.addAll(mpresep);

			Dual res = new DualImpl(cf, sep);
			return res;
		} catch (VisitorException e) {
			throw warp(e, n.position());
		}
	}

	/**
	 * Compute the weakest precondition of pure/linear special call. Pure
	 * special call delegates to
	 * {@link WPCalculus#wppure(ConstructorCall, Dual)}. Linear special call
	 * delegates to {@link WPCalculus#wplinear(ConstructorCall, Dual)}.
	 */
	public Dual wp(ConstructorCall c, Dual post) throws WPCalculusException { // XXX OK
		Flags f = c.constructorInstance().flags();
		if (f.contains(SpecJavaFlags.PURE)) return wppure(c, post);
		else return wplinear(c, post);
	}

	/**
	 * Compute the weakest precondition of pure special call.
	 */
	private Dual wppure(ConstructorCall c, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi = 
				(SpecJavaProcedureInstance) c.procedureInstance();
			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List ys = c.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(ys, ps);
			List linear = linear(ys, ps);

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis);// XXX added
				
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
			}

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}
			
			se.add("this");
			
			List hrest = DualLogic.restrict(postsep, se);
			
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
						
			sep.addAll(hex);

			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Dual res = new DualImpl(cf, sep);
			return res;
		} catch (VisitorException e) {
			throw warp(e, c.position());
		}
	}

	/**
	 * Compute the weakest precondition of linear special call.
	 */
	private Dual wplinear(ConstructorCall c, Dual post) // OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) c.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List ys = c.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(ys, ps);
			List linear = linear(ys, ps);

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}

			se.add("this"); // XXX added
			List sep = DualLogic.exclude(postsep, se);
			sep.addAll(mpresep);

			Dual res = new DualImpl(cf, sep);
			return res;
		} catch (VisitorException e) {
			throw warp(e, c.position());
		}
	}

	/**
	 * Compute the weakest precondition of void method call
	 */
	// k.mn(\overline{y}, \overline{z})
	// hypotheses
	// k,mn,\overline{y} \in pure \overline{z} \in linear
	// mn,\overline{y} \in pure k,\overline{z} \in linear
	// \overline{y} \in pure k,mn,\overline{z} \in linear
	private Dual wp(Call mc, Dual post) throws WPCalculusException { // OK
		Receiver rec = mc.target();
		MethodInstance mi = mc.methodInstance();
		if (DualLogic.isPure(rec.type())) {
			// method must be pure
			// check anyway
			if (!mi.flags().contains(SpecJavaFlags.PURE))
				throw new WPCalculusException("Mismatch Problem: " + rec
						+ " is pure but " + mi + " is not");
			// k,mn \in pure
			return wpkpmp(mc, post);
		} else {
			// k \in linear
			if (mi.flags().contains(SpecJavaFlags.PURE)) {
				// k \in linear m \in pure
				return wpklmp(mc, post);
			} else { // k,m \in linear
				return wpklml(mc, post);
			}
		}
	}

	private Dual wpkpmp(Call mc, Dual post) throws WPCalculusException { // OK
		try {
			SpecJavaProcedureInstance spi = 
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			Expr k = null;
			if (mc.target() instanceof Expr) {
				k = (Expr) mc.target();
			}

			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mprecf = (Formula) mprecf.accept(v);
				mpostcf = (Formula) mpostcf.accept(v);
				
				mpresep = Utils.visitList(mpresep, v);// XXX added
				mpostsep = Utils.visitList(mpostsep, v);
			}

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis);// XXX added
				
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
			}
			
			Formula cf;

			if (k != null) {

				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
				StatePredicate sp = new StatePredicate("null", et);

				cf = new And(new Not(sp), new And(mprecf, new Implication(
						new And(new Not(sp), mpostcf), postcf)));

			} else cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}
			
			if (k != null) se.add(k.toString()); // XXX added
			
			List hrest = DualLogic.restrict(postsep, se);		
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
						
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mc.methodInstance(), res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private Dual wpklmp(Call mc, Dual post) throws WPCalculusException { // OK
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			
			if (mc.target() instanceof Expr) {
				k = (Expr) mc.target();
			}

			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpresep = Utils.visitList(mpresep, v);
				mpostsep = Utils.visitList(mpostsep, v);
				
				mprecf = (Formula) mprecf.accept(v); // XXX added
				mpostcf = (Formula) mpostcf.accept(v); // XXX added
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}

			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));			

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}

			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}

			List hrest = DualLogic.restrict(postsep, se);
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mc.methodInstance(), res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private Dual wpklml(Call mc, Dual post) throws WPCalculusException { // OK
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpresep = Utils.visitList(mpresep, v);
				
				mprecf = (Formula)mprecf.accept(v); // XXX added
				mpostcf = (Formula)mpostcf.accept(v); // XXX added
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				//subs.add(vis);
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
			}
			
			List hex = DualLogic.exclude(postsep, se);
			List sep = mpresep;
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mc.methodInstance(), res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	/**
	 * Compute the weakest precondition of pure/linear method call. Pure method
	 * call delegates to {@link WPCalculus#wppure(Variable, Call, Dual)}. Linear
	 * method call delegates to
	 * {@link WPCalculus#wplinear(Variable, Call, Dual)}.
	 */
	// x = k.mn(\overline{y}, \overline{z})
	// hypotheses
	// k,mn,x \in pure \emptyset \in linear
	// k,mn \in pure x \in linear
	// mn,x \in pure k \in linear
	// mn \in pure k,x \in linear
	// x \in pure k,mn \in linear
	// \emptyset \in pure k,mn,x \in linear
	private Dual wp(Variable x, Call mc, Dual post) throws WPCalculusException { // OK
		Receiver rec = mc.target();
		MethodInstance mi = mc.methodInstance();
		if (DualLogic.isPure(rec.type())) {
			// method must be pure
			// check anyway
			if (!mi.flags().contains(SpecJavaFlags.PURE))
				throw new WPCalculusException("Mismatch Problem: " + rec
						+ " is pure but " + mi + " is not", mc.position());
			// k,mn \in pure
			if (DualLogic.isPure(mi.returnType()))
				return wpkpmpxp(x, mc, post);
			else
				throw new WPCalculusException("Pure objects cannot " +
						"return linear objects: " + rec
						+ " is linear but " + mi + " is pure", mc.position());
		} else {
			// k \in linear
			if (mi.flags().contains(SpecJavaFlags.PURE)) {
				// k \in linear m \in pure
				if (DualLogic.isPure(mi.returnType()))
					return wpklmpxp(x, mc, post);
				else
					return wpklmpxl(x, mc, post);
			} else { // k,m \in linear
				if (DualLogic.isPure(mi.returnType()))
					return wpklmlxp(x, mc, post);
				else
					return wpklmlxl(x, mc, post);
			}
		}
	}

	private Dual wpkpmpxp(Variable x, Call mc, Dual post) // OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi = 
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			Expr k = null;
			if (mc.target() instanceof Expr) {
				k = (Expr) mc.target();
			}

			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mprecf = (Formula) mprecf.accept(v);
				mpostcf = (Formula) mpostcf.accept(v);
				
				mpresep = Utils.visitList(mpresep, v);// XXX added
				mpostsep = Utils.visitList(mpostsep, v);
			}

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis);// XXX added
				
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
			}

			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));
			mpostcf = (Formula) mpostcf.accept(sub);
			mpostsep = Utils.visitList(mpostsep, sub);
			
			Substitutor sub2 = null;
			if (x != null) {
				sub2 = new Substitutor(x,new VariableTerm(fresh));
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}

			Formula cf;

			if (k != null) {

				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
				StatePredicate sp = new StatePredicate("null", et);

				cf = new And(new Not(sp), new And(mprecf, new Implication(
						new And(new Not(sp), mpostcf), postcf)));

			} else cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}
			
			if (k != null) se.add(k.toString()); // XXX added
			if (x != null) se.add(x.toString()); // XXX added
			
			List hrest = DualLogic.restrict(postsep, se);
			if (x != null) hrest = Utils.visitList(hrest, sub2);			
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
						
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mi, res);
			//////////////////////////////////			
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}
	
	private Dual assumeInvariant(Expr k, MethodInstance mi, Dual d)
	throws VisitorException {
		ReferenceType rt = mi.container();
		Dual res = d;
		if (k != null && !mi.flags().isStatic() && rt.isClass()) {
			Dual is = null;
			SpecJavaClassType sjct = (SpecJavaClassType)rt.toClass();
			List invs = sjct.invariants();
			Iterator it = invs.iterator();
			if (it.hasNext()) is = (Dual)it.next();			
			while(it.hasNext()) {
				Dual i = (Dual)it.next();
				is = DualLogic.and(is, i);
			}
			if (is != null) {
				Substitutor v = new Substitutor("this", new VariableTerm(k));
				is = Utils.visit(is, v);
				res = DualLogic.imply(is, res);
			}
		}
		return res;
	}

	private Dual wpklmpxp(Variable x, Call mc, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi = 
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();
			List mpostsep = mpost.sepLogicFormulas();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				
				mprecf = (Formula) mprecf.accept(v); // XXX added
				mpostcf = (Formula) mpostcf.accept(v); // XXX added
				
				mpresep = Utils.visitList(mpresep, v);
				mpostsep = Utils.visitList(mpostsep, v);
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
				
				mpostcf = (Formula) mpostcf.accept(vis);
			}

			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));
			mpostcf = (Formula) mpostcf.accept(sub);
			
			mpostsep = Utils.visitList(mpostsep, sub); // XXX added
			
			Substitutor sub2 = null;
			if (x != null) {
				sub2 = new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				
				mpostsep = Utils.visitList(mpostsep, vis);
				
				se.add(z.toString());
			}
			
			if (k != null) se.add(k.toString());			
			if (x != null) se.add(x.toString()); // XXX added

			if (k != null) {
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);

				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}
			
			List hrest = DualLogic.restrict(postsep, se);
			if (x != null) hrest = Utils.visitList(hrest, sub2);
			List sep2 = DualLogic.imply(mpostsep, hrest);
			List sep = DualLogic.and(mpresep, sep2);
			List hex = DualLogic.exclude(postsep, se);
			
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mi, res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private Dual wpklmpxl(Variable x, Call mc, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				
				mprecf = (Formula) mprecf.accept(v); // XXX added
				mpostcf = (Formula) mpostcf.accept(v); // XXX added
				
				mpresep = Utils.visitList(mpresep, v);
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}
			
			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);
			
			Substitutor sub2 = null;
			if (x != null) {
				sub2 = new Substitutor(x, new VariableTerm(fresh));
				postcf = (Formula) postcf.accept(sub2);
			}

			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}
			
			if (k != null) se.add(k.toString());

			if (k != null) {
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}

				StatePredicate sp = new StatePredicate("null", et);
				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
			}
			
			if (x != null) se.add(x.toString());
			List hex = DualLogic.exclude(postsep, se);
			List sep = mpresep;
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mi, res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private Dual wpklmlxp(Variable x, Call mc, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpresep = Utils.visitList(mpresep, v);
				
				mprecf = (Formula)mprecf.accept(v); // XXX added
				mpostcf = (Formula)mpostcf.accept(v); // XXX added
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}

			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));
			mpostcf = (Formula) mpostcf.accept(sub);
			if (x != null) {
				Substitutor sub2 = new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}
			
			if (x != null) se.add(x.toString()); // XXX added
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
			}

			
			List hex = DualLogic.exclude(postsep, se);
			List sep = mpresep;
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mi, res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private Dual wpklmlxl(Variable x, Call mc, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpre = spi.preconditiond();
			Dual mpost = spi.postconditiond();
			
			if (mpre == null && mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming wp = "
						+ post);
				return post;
			}

			mpre = assertNotNull(spi, mpre);
			mpost = assertNotNull(spi, mpost);

			mpre = mpre.expr(nf);
			mpost = mpost.expr(nf);

			Formula mprecf = mpre.classicFormula();
			List mpresep = mpre.sepLogicFormulas();

			Formula mpostcf = mpost.classicFormula();

			Formula postcf = post.classicFormula();
			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List pure = pure(es, ps);
			List linear = linear(es, ps);
			
			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpresep = Utils.visitList(mpresep, v);
				
				mprecf = (Formula)mprecf.accept(v); // XXX added
				mpostcf = (Formula)mpostcf.accept(v); // XXX added
			}

			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mprecf = (Formula) mprecf.accept(vis);
				mpostcf = (Formula) mpostcf.accept(vis);
				
				mpresep = Utils.visitList(mpresep, vis); // XXX added
			}

			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			if (x != null) {
				Substitutor sub2 = new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				postcf = (Formula) postcf.accept(sub2);
			}
			
			Formula cf = new And(mprecf, new Implication(mpostcf, postcf));

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				LocalInstance p2 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p2.name(), new VariableTerm(z));
				mpresep = Utils.visitList(mpresep, vis);
				se.add(z.toString());
			}
			
			if (x != null) se.add(x.toString()); // XXX added
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
				mpresep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpresep);
			}

			
			List hex = DualLogic.exclude(postsep, se);
			List sep = mpresep;
			sep.addAll(hex);

			Dual res = new DualImpl(cf, sep);
			
			////// XXX ASSUME INVARIANT //////
			res = assumeInvariant(k, mi, res);
			//////////////////////////////////
			
			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	public Dual wp(Synchronized syn, Dual post) throws WPCalculusException { // OK
		Block b = syn.body();
		SpecJavaStmtExt sjsext = (SpecJavaStmtExt) b.ext();
		Dual wp = sjsext.wp(this, post);
		Expr e = syn.expr();
		Type t = e.type();
		Formula cf = wp.classicFormula();
		List sl = wp.sepLogicFormulas();
		Term ter = null;
		if (e instanceof NullLit) ter = new Constant((NullLit)e); 
		else ter = new VariableTerm(e);
		Formula f = new Not(new StatePredicate("null", ter));
		if (DualLogic.isPure(t)) cf = new And(f, cf);
		else sl = DualLogic.and(DualLogic.makeSep(f), sl);
		Dual res = new DualImpl(cf, sl);
		return res;
	}

	// /////////////////////////////////////////////////////////////////////

	// ///////////////////// Verification Conditions ///////////////////////

	public List vc(LocalDecl ld, Dual post) throws WPCalculusException { // OK
		Assign a = translate(ld);
		if (a != null) return vc(a, post);
		return new LinkedList();
	}

	public List vc(Eval e, Dual post) throws WPCalculusException { // FIXME CHECK
		Expr expr = e.expr();
		if (expr instanceof Assign)
			return vc((Assign) expr, post);
		else if (expr instanceof New)
			return vc(null, (New) expr, post);
		else if (expr instanceof Call) {
			Call mc = (Call) expr;
			MethodInstance mi = mc.methodInstance();
			if (mi.returnType().isVoid() && mi.returnType().isPrimitive())
				return vc(mc, post);
			else return vc(null, mc, post);
		} else throw new WPCalculusException("Expression not supported", 
												expr.position());
	}

	private List vc(Assign a, Dual post) throws WPCalculusException { // OK
		if (!(a.left() instanceof Variable))
			throw new WPCalculusException(
					"Left side of the assignment must be a variable",
					a.position());
		Variable x = (Variable) a.left();
		Expr eps = a.right();
		if (eps instanceof New)
			return vc(x, (New) eps, post);
		else if (eps instanceof Call)
			return vc(x, (Call) eps, post);

		if (DualLogic.isPure(x.type())) return vcpure(a, post);
		else return vclinear(a, post);
	}

	/**
	 * Pure assign, pure null assign.
	 */
	private List vcpure(Assign a, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	/**
	 * Linear assign, linear null assign Linear creation delegates to vclinear.
	 */
	private List vclinear(Assign a, Dual post) throws WPCalculusException { // OK
		Expr y = a.right(); // can be null assign
		Variable x = (Variable) a.left(); // XXX added

		if (y instanceof NullLit) // can be aliased
			return new LinkedList();
		
		List postsep = post.sepLogicFormulas();
		Variable yv = (Variable) y;
		Set se = new HashSet();
		if (x.toString().compareTo(yv.toString()) != 0) // XXX added if x = y alias ok
			se.add(yv.toString());
		List hex = DualLogic.restrict(postsep, se);
		if (!hex.isEmpty())
			throw new WPCalculusException("Variable " + a.left() + 
					" is an alias",	a.position());
		else return new LinkedList();
	}

	public List vc(Return r, Dual post) throws WPCalculusException { // OK
		// ignore post because the postcondition
		// of a return corresponds always to
		// the method postcondition,
		// since a return corresponds
		// to the end of the method execution
		if (DualLogic.isPure(type)) return vcpure(r, methodpost);
		else return vclinear(r, methodpost);
	}

	private List vcpure(Return r, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	private List vclinear(Return r, Dual post) throws WPCalculusException { // XXX OK		
		if (r.expr() instanceof NullLit)
			return new LinkedList();
		
		if (!(r.expr() instanceof Variable))
			throw new WPCalculusException(
					"Linear return expression must be a variable", r.position());
		
		List postsep = post.sepLogicFormulas();
		Variable yv = (Variable) r.expr();
		Set se = new HashSet();
		se.add(yv.toString());
		List hex = DualLogic.restrict(postsep, se);
		if (!hex.isEmpty())
			throw new WPCalculusException("Variable " + yv + " will be aliased",
					yv.position());
		else return new LinkedList();
	}

	/**
	 * Loop
	 */
	public List vc(Loop l, Dual post) throws WPCalculusException { // OK
		if (l instanceof For)
			return vc((For) l, post);
		else if (l instanceof While || l instanceof Do) {
			SpecJavaLoop loop = (SpecJavaLoop) l.del();
			LoopInvariantNode invn = loop.invariant();
			Formula inv = invn.dualNode().classicFormula().formula();
			List invlf = DualLogic.getFormulas(invn.dualNode().sepLogicFormulas());
			SpecJavaStmtExt body = (SpecJavaStmtExt) loop.body().ext();
			Expr eps = loop.cond();
			List vcs = new LinkedList();
			DeepCopier dc = new DeepCopier();
			Formula e1 = null;
			Formula e2 = null;
			try {
				e1 = AbstractFormula.boolExprToFormula((Expr) eps.visit(dc));
				e2 = new Not(AbstractFormula.boolExprToFormula((Expr) eps.visit(dc)));
			} catch (SemanticException e) {
				throw warp(e, l.position());
			}

			System.err.println("vc(Loop) epsilon = " + e1);

			Dual invd = new DualImpl(inv, invlf);

			Dual wpd = body.wp(this, invd);

			// (I and Cond) => wp(ST, I)
			Dual df1 = DualLogic.and(e1, invd);
			Dual da1 = DualLogic.imply(df1, wpd);

			vcs.add(new Pair(da1, l.position()));

			// vc(ST, I)
			vcs.addAll(body.vc(this, invd));

			// (I and !Cond) => Post
			Dual df2 = DualLogic.and(e2, invd);
			Dual da2 = DualLogic.imply(df2, post);

			vcs.add(new Pair(da2, l.position()));

			return vcs;
		} else
			throw new WPCalculusException("Loop type not supported",
					l.position());
	}

	/**
	 * For
	 */
	private List vc(For f, Dual post) throws WPCalculusException { // XXX OK
		SpecJavaLoop loop = (SpecJavaLoop) f.del();
		LoopInvariantNode invn = loop.invariant();
		Formula inv = invn.dualNode().classicFormula().formula();
		List invlf = DualLogic.getFormulas(invn.dualNode().sepLogicFormulas());
		Dual invd = new DualImpl(inv, invlf);
		
		List vcs = new LinkedList();
		vcs.addAll(vc(f.inits(), invd));
		
		List stmts = new LinkedList();
		stmts.add(loop.body());
		stmts.addAll(f.iters());

		Expr eps = loop.cond();
		DeepCopier dc = new DeepCopier();
		Formula e1 = null;
		Formula e2 = null;
		try {
			e1 = AbstractFormula.boolExprToFormula((Expr) eps.visit(dc));
			e2 = new Not(AbstractFormula.boolExprToFormula((Expr) eps.visit(dc)));
		} catch (SemanticException e) {
			throw warp(e, f.position());
		}
		System.err.println("vc(For) epsilon = " + e1);

		Dual wpd = wp(stmts, invd);

		// (I and Cond) => wp(ST;Updates, I)
		Dual df1 = DualLogic.and(e1, invd);
		Dual da1 = DualLogic.imply(df1, wpd);

		vcs.add(new Pair(da1, f.position()));

		// vc(ST;Updates, I)
		vcs.addAll(vc(stmts, invd));

		// (I and !Cond) => Post
		Dual df2 = DualLogic.and(e2, invd);
		Dual da2 = DualLogic.imply(df2, post);

		vcs.add(new Pair(da2, f.position()));

		return vcs;
	}
	
	private static List apply(List vcs, List subs)
		throws VisitorException {
		for (Iterator it = subs.iterator(); it.hasNext();) {
			Substitutor sub = (Substitutor) it.next();
			vcs = Utils.visitDualList(vcs, sub);
		}
		return vcs;
	}
	
	private static List imp(Formula f, List vcs) {
		List res = new LinkedList();
		for (Iterator it = vcs.iterator(); it.hasNext();) {
			Pair p = (Pair) it.next();
			Dual d = (Dual) p.part1();
			Position pos = (Position) p.part2();
			List sep = d.sepLogicFormulas();
			sep = impsep(f, sep);
			Dual nd = new DualImpl(d.classicFormula(), sep);
			res.add(new Pair(nd, pos));
		}
		return res;
	}
	
	private static List impsep(Formula f, List sep) {
		List res = new LinkedList();
		for (Iterator it = sep.iterator(); it.hasNext();) {
			Formula fo = (Formula) it.next();
			res.add(new Implication(f, fo));
		}
		return res;
	}

	/**
	 * Conditional
	 */
	public List vc(If i, Dual post) throws WPCalculusException { // XXX OK
		List vcs = new LinkedList();
		SpecJavaStmtExt st1 = (SpecJavaStmtExt) i.consequent().ext();
		Expr eps = i.cond();
		DeepCopier dc = new DeepCopier();
		Formula e1,e2;		
		try {
			e1 = AbstractFormula.boolExprToFormula((Expr) eps.visit(dc));
			e2 = new Not(AbstractFormula.boolExprToFormula((Expr) eps.visit(dc)));
		} catch (SemanticException e) {
			throw warp(e, i.position());
		}
		
		List vcsST1 = st1.vc(this, post);
		vcsST1 = imp(e1, vcsST1);
		vcs.addAll(vcsST1);
		
		Stmt b2 = i.alternative();
		if (b2 != null) { // has alternative
			SpecJavaStmtExt st2 = (SpecJavaStmtExt) b2.ext();
			List vcsST2 = st2.vc(this, post);
			vcsST2 = imp(e2, vcsST2);
			vcs.addAll(vcsST2);
		}
		/*
		 * else not nedeed because same has alternative being
		 * skip and vc(skip, post) = empty
		 */
		return vcs;
	}

	/**
	 * Composition
	 */
	public List vc(Block b, Dual post) throws WPCalculusException { // OK
		return vc(b.statements(), post);
	}
	
	private List vc(List stmts, Dual post) throws WPCalculusException { // OK
		Dual wp = post;
		ListIterator it = stmts.listIterator(stmts.size());
		LinkedList vcs = new LinkedList();
		Simplifier simpl = new Simplifier();
		System.out.println("----- STARTING BLOCK VC -----");
		while (it.hasPrevious()) {
			Stmt s = (Stmt) it.previous();
			SpecJavaStmtExt sext = (SpecJavaStmtExt) s.ext();
			List vcss = sext.vc(this, wp);
			wp = sext.wp(this, wp);
			try {
				vcss = apply(vcss, subs);
				subs.clear();
				vcs.addAll(0, vcss);
				System.out.println(vcss = Utils.visitDualList(vcss, simpl));
			} catch (VisitorException e) {
				throw warp(e, s.position());
			}
		}
		System.out.println("----- ENDING BLOCK VC -----");
		return vcs;	
	}

	/**
	 * Skip
	 */
	public List vc(Empty e, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	/**
	 * Static assert
	 */
	public List vc(StaticAssert s, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	/**
	 * Assume
	 */
	public List vc(Assume a, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	public List vc(Variable x, New n, Dual post) throws WPCalculusException { // XXX OK
		Flags f = n.constructorInstance().flags();
		if (f.contains(SpecJavaFlags.PURE)) return vcpure(x, n, post);
		else return vclinear(x, n, post);
	}

	/**
	 * Pure creation
	 */
	private List vcpure(Variable x, New n, Dual post) // OK
			throws WPCalculusException {		
		return new LinkedList();
	}

	/**
	 * Linear creation
	 */
	private List vclinear(Variable x, New n, Dual post) // FIXME CHECK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) n.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List ys = n.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(ys, ps);
			
			List pure = pure(ys, ps);
			
			Type t = null;
			if (x != null) t = x.type();
			else t = n.type();

			Variable fresh = getFresh(x, t, nf, ts, vars);

			assertNotEquals(x, fresh);
			
			if (x != null) {
				Substitutor sub = new Substitutor("this", fresh);
				mpostsep = Utils.visitList(mpostsep, sub);

				VariableTerm et = null;
				if (fresh instanceof Local) {
					Local l = (Local) fresh;
					et = new VariableTerm(l);
				} else if (fresh instanceof Field) {
					Field f = (Field) fresh;
					et = new VariableTerm(f);
				} else if (fresh instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ vc linear creation");
				}
				StatePredicate sp = new StatePredicate("null", et);

				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);

			}
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			if (x != null) se.remove(x.toString());
			List rest = DualLogic.restrict(postsep, se);
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", n.position()); 

			if (x != null) se.add(x.toString());

			List rh = DualLogic.restrict(postsep, se);
			
			if (x != null) {
				Substitutor sub2 = new Substitutor(x, fresh);
				rh = Utils.visitList(rh, sub2);
			}

			List sep = DualLogic.imply(mpostsep, rh);

			List vcs = new LinkedList();
			Dual vc1 = new DualImpl(Formula.TRUE, sep);
			vcs.add(new Pair(vc1, n.position()));

			return vcs;
		} catch (VisitorException e) {
			throw warp(e, n.position());
		}
	}

	public List vc(ConstructorCall c, Dual post) throws WPCalculusException { // XXX OK
		Flags f = c.constructorInstance().flags();
		if (f.contains(SpecJavaFlags.PURE)) return vcpure(c, post);
		else return vclinear(c, post);
	}

	/**
	 * Pure special call.
	 */
	private List vcpure(ConstructorCall c, Dual post) // OK
			throws WPCalculusException {
		return new LinkedList();
	}

	/**
	 * Linear special call.
	 */
	private List vclinear(ConstructorCall c, Dual post) // OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) c.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List ys = c.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(ys, ps);
			
			List pure = pure(ys, ps);
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}

			Set se = new HashSet();
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			List rest = DualLogic.restrict(postsep, se); 
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", c.position());
			
			se.add("this"); // XXX added

			List rh = DualLogic.restrict(postsep, se);

			List sep = DualLogic.imply(mpostsep, rh);

			List vcs = new LinkedList();
			Dual vc1 = new DualImpl(Formula.TRUE, sep);
			vcs.add(new Pair(vc1, c.position()));

			return vcs;
		} catch (VisitorException e) {
			throw warp(e, c.position());
		}
	}

	private List vc(Call mc, Dual post) throws WPCalculusException { // OK
		Receiver rec = mc.target();
		MethodInstance mi = mc.methodInstance();
		if (DualLogic.isPure(rec.type())) {
			// method must be pure
			// check anyway
			if (!mi.flags().contains(SpecJavaFlags.PURE))
				throw new WPCalculusException("Mismatch Problem: " + rec
						+ " is pure but " + mi + " is not");
			// k,mn \in pure
			return vckpmp(mc, post);
		} else {
			// k \in linear
			if (mi.flags().contains(SpecJavaFlags.PURE)) {
				// k \in linear m \in pure
				return vcklmp(mc, post);
			} else { // k,m \in linear
				return vcklml(mc, post);
			}
		}
	}

	private List vckpmp(Call mc, Dual post) throws WPCalculusException { // OK
		return new LinkedList();
	}

	private List vcklmp(Call mc, Dual post) throws WPCalculusException {
		return new LinkedList();
	}

	private List vcklml(Call mc, Dual post) throws WPCalculusException { // OK
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(es, ps);

			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpostsep = Utils.visitList(mpostsep, v);
			}
			
			List pure = pure(es, ps);
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}
			
			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			List rest = DualLogic.restrict(postsep, se); 
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", mc.position());
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
	
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}

			List hrest = DualLogic.restrict(postsep, se);
			List sep = DualLogic.imply(mpostsep, hrest);
			
			Dual vc = new DualImpl(Formula.TRUE, sep);

			List res = new LinkedList();
			res.add(new Pair(vc, mc.position()));

			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	// x = k.mn(\overline{y}, \overline{z})
	// hipoteses
	// k,mn,x \in pure \emptyset \in linear
	// k,mn \in pure x \in linear
	// mn,x \in pure k \in linear
	// mn \in pure k,x \in linear
	// x \in pure k,mn \in linear
	// \emptyset \in pure k,mn,x \in linear
	private List vc(Variable x, Call mc, Dual post) throws WPCalculusException { // OK
		Receiver rec = mc.target();
		MethodInstance mi = mc.methodInstance();
		if (DualLogic.isPure(rec.type())) {
			// method must be pure
			// check anyway
			if (!mi.flags().contains(SpecJavaFlags.PURE))
				throw new WPCalculusException("Mismatch Problem: " + rec
						+ " is pure but " + mi + " is not", mc.position());
			// k,mn \in pure
			if (DualLogic.isPure(mi.returnType()))
				return vckpmpxp(x, mc, post);
			else
				throw new WPCalculusException("Pure objects cannot " +
						"return linear objects: " + rec
						+ " is linear but " + mi + " is pure", mc.position());
		} else {
			// k \in linear
			if (mi.flags().contains(SpecJavaFlags.PURE)) {
				// k \in linear m \in pure
				if (DualLogic.isPure(mi.returnType()))
					return vcklmpxp(x, mc, post);
				else
					return vcklmpxl(x, mc, post);
			} else { // k,m \in linear
				if (DualLogic.isPure(mi.returnType()))
					return vcklmlxp(x, mc, post);
				else
					return vcklmlxl(x, mc, post);
			}
		}
	}

	private List vckpmpxp(Variable x, Call mc, Dual post) // OK
			throws WPCalculusException {
		return new LinkedList();
	}

	private List vcklmpxp(Variable x, Call mc, Dual post)
			throws WPCalculusException {
		return new LinkedList();
	}

	private List vcklmpxl(Variable x, Call mc, Dual post)
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(es, ps);

			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpostsep = Utils.visitList(mpostsep, v);
			}
			
			List pure = pure(es, ps);
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}
			
			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));
			mpostsep = Utils.visitList(mpostsep, sub);
			
			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			if (x != null) se.remove(x.toString());
			List rest = DualLogic.restrict(postsep, se); 
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", mc.position());
			
			if (x != null) se.add(x.toString());

			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
	
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}
			
			List hrest = DualLogic.restrict(postsep, se);
			if (x != null) {
				Substitutor sub2 =  new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				hrest = Utils.visitList(hrest, sub2);
			}
			List sep = DualLogic.imply(mpostsep, hrest);

			Dual vc = new DualImpl(Formula.TRUE, sep);

			List res = new LinkedList();
			res.add(new Pair(vc, mc.position()));

			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private List vcklmlxp(Variable x, Call mc, Dual post) /// XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(es, ps);

			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpostsep = Utils.visitList(mpostsep, v);
			}
			
			List pure = pure(es, ps);
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}
			
			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));
			mpostsep = Utils.visitList(mpostsep, sub);

			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			List rest = DualLogic.restrict(postsep, se); 
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", mc.position());
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
	
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}
			
			if (x != null) se.add(x.toString());
			List hrest = DualLogic.restrict(postsep, se);
			if (x != null) {
				Substitutor sub2 =  new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				hrest = Utils.visitList(hrest, sub2);
			}
			List sep = DualLogic.imply(mpostsep, hrest);

			Dual vc = new DualImpl(Formula.TRUE, sep);

			List res = new LinkedList();
			res.add(new Pair(vc, mc.position()));

			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	private List vcklmlxl(Variable x, Call mc, Dual post) // XXX OK
			throws WPCalculusException {
		try {
			SpecJavaProcedureInstance spi =
				(SpecJavaProcedureInstance) mc.procedureInstance();

			Dual mpost = spi.postconditiond();
			
			if (mpost == null) {
				System.err.println("WARNING: " + spi + " condition is null assuming vc = "
						+ Collections.EMPTY_LIST);
				return new LinkedList();
			}

			mpost = assertNotNull(spi, mpost);

			mpost = mpost.expr(nf);

			List mpostsep = mpost.sepLogicFormulas();

			List postsep = post.sepLogicFormulas();

			List es = mc.arguments();
			List ps = spi.formalNames();

			ps = assertNotNull(spi, ps);

			List linear = linear(es, ps);

			Expr k = null;
			if (mc.target() instanceof Expr)
				k = (Expr) mc.target();
			
			if (k != null) {
				PLVisitor v = new Substitutor("this", new VariableTerm(k));
				mpostsep = Utils.visitList(mpostsep, v);
			}
			
			List pure = pure(es, ps);
			
			for (Iterator pui = pure.iterator(); pui.hasNext();) {
				Pair pa = (Pair) pui.next();
				Expr y = (Expr) pa.part1();
				LocalInstance p1 = (LocalInstance) pa.part2();
				PLVisitor vis = new Substitutor(p1.name(), new VariableTerm(y));
				mpostsep = Utils.visitList(mpostsep, vis); // XXX added
			}
			
			MethodInstance mi = mc.methodInstance();
			Type t = mi.returnType();
			Variable fresh = getFresh(x, t, nf, ts, vars);
			assertNotEquals(x, fresh);

			Substitutor sub = new Substitutor("return", new VariableTerm(fresh));

			mpostsep = Utils.visitList(mpostsep, sub);

			Set se = new HashSet();			
			for (Iterator lini = linear.iterator(); lini.hasNext();) {
				Pair pa = (Pair) lini.next();
				Expr z = (Expr) pa.part1();
				se.add(z.toString());
			}
			
			if (x != null) se.remove(x.toString());
			List rest = DualLogic.restrict(postsep, se); 
			if (!rest.isEmpty())
				throw new WPCalculusException("Arguments aliased!", mc.position());
			
			if (k != null) {
				se.add(k.toString());
				VariableTerm et = null;
				if (k instanceof Local) {
					Local l = (Local) k;
					et = new VariableTerm(l);
				} else if (k instanceof Field) {
					Field f = (Field) k;
					et = new VariableTerm(f);
				} else if (k instanceof Special) {
					Special s = (Special) k;
					et = new VariableTerm(s);
				} else if (k instanceof ArrayAccess) {
					// FIXME array support
					System.err.println("ERROR @ wp pure method call");
				}
	
				StatePredicate sp = new StatePredicate("null", et);
	
				mpostsep = DualLogic.and(DualLogic.makeSep(new Not(sp)), mpostsep);
			}
			
			if (x != null) se.add(x.toString());
			List hrest = DualLogic.restrict(postsep, se);
			if (x != null) {
				Substitutor sub2 =  new Substitutor(x, new VariableTerm(fresh));
				subs.add(sub2);
				hrest = Utils.visitList(hrest, sub2);
			}
			List sep = DualLogic.imply(mpostsep, hrest);

			Dual vc = new DualImpl(Formula.TRUE, sep);

			List res = new LinkedList();
			res.add(new Pair(vc, mc.position()));

			return res;

		} catch (VisitorException e) {
			throw warp(e, mc.position());
		}
	}

	public List vc(Synchronized syn, Dual post) throws WPCalculusException { // OK
		Block b = syn.body();
		SpecJavaStmtExt sjsext = (SpecJavaStmtExt) b.ext();
		List vcs = sjsext.vc(this, post);
		return vcs;
	}

	///////////////////////////////////////////////////////////////////////
	
}
