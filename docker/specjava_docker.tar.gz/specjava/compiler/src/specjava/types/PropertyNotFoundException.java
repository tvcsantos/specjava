package specjava.types;

public class PropertyNotFoundException extends Exception {

	private static final long serialVersionUID = -4579550686800236369L;

	public PropertyNotFoundException() {
		super();
	}

	public PropertyNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public PropertyNotFoundException(String message) {
		super(message);
	}

	public PropertyNotFoundException(Throwable cause) {
		super(cause);
	}	
}
