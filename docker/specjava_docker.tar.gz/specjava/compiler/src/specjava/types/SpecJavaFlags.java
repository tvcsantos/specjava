package specjava.types;

import polyglot.types.Flags;

public interface SpecJavaFlags {

	public static final Flags PURE = Flags.createFlag("pure", null);	

}
