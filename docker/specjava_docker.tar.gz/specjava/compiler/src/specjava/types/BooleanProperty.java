package specjava.types;

public interface BooleanProperty extends Property {

}
