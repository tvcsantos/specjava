package specjava.types;

import java.util.Collections;
import java.util.List;

import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.MethodInstance_c;
import polyglot.types.ReferenceType;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.Position;
import polyglot.util.TypedList;
import specjava.logic.formula.Dual;

public class SpecJavaMethodInstance_c extends MethodInstance_c implements
		SpecJavaProcedureInstance {

	private static final long serialVersionUID = -5953804635596028915L;

	protected List fnames;
	
	protected Dual pred;
	protected Dual postd;
	
	public boolean isCanonical() {
		return fnames != null && listIsCanonical(fnames)
			&& super.isCanonical();
	}
	
	public boolean isFullCanonical() {
		return isCanonical()
			&& pred != null && pred.isCanonical()
			&& postd != null && postd.isCanonical();
	}

	public SpecJavaMethodInstance_c(TypeSystem ts, Position pos,
			ReferenceType container, Flags flags, Type returnType, String name,
			List formalNames, List formalTypes, List excTypes) {
		super(ts, pos, container, flags, returnType, name, formalTypes, excTypes);
		this.fnames = TypedList.copyAndCheck(formalNames, LocalInstance.class, true);
	}

	public List formalNames() {
		return fnames == null ? null : Collections.unmodifiableList(fnames);
	}

	public SpecJavaProcedureInstance formalNames(List names) {
		SpecJavaMethodInstance_c i = (SpecJavaMethodInstance_c) copy();
		i.fnames = TypedList.copyAndCheck(names, LocalInstance.class, true);
		return i;
	}
	
	public void setFormalNames(List names) {
		this.fnames = TypedList.copyAndCheck(names, LocalInstance.class, true);
	}
	
	public Dual postconditiond() {
		return postd;
	}

	public Dual preconditiond() {
		return pred;
	}

	public void setPostconditiond(Dual post) {
		this.postd = post;
	}

	public void setPreconditiond(Dual pre) {
		this.pred = pre;
	}
}