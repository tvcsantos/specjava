package specjava.types;

import java.util.List;

import polyglot.types.PrimitiveType;

public interface SpecJavaPrimitiveType extends PrimitiveType {
	List properties();
	
	Property propertyNamed(String name);
}
