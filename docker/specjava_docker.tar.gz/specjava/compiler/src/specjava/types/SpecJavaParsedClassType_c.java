package specjava.types;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import polyglot.frontend.Source;
import polyglot.types.LazyClassInitializer;
import polyglot.types.ParsedClassType_c;
import polyglot.types.ProcedureInstance;
import polyglot.types.TypeSystem;
import polyglot.util.Position;
import polyglot.util.TypedList;
import specjava.logic.formula.Dual;

public class SpecJavaParsedClassType_c extends ParsedClassType_c implements
		SpecJavaParsedClassType {
	
	private static final long serialVersionUID = -5047068147815789805L;
	
	protected List props;
	protected List invs;
	protected Map defs;
	
	public SpecJavaParsedClassType_c(TypeSystem ts,
			LazyClassInitializer init, Source fromSource) {
		super(ts, init, fromSource);
		props = new TypedList(new LinkedList(), Property.class, false);
		SpecJavaTypeSystem sjts = (SpecJavaTypeSystem)ts;
		Property nullp = sjts.NullProperty(Position.COMPILER_GENERATED);
		props.add(nullp);
		invs = new TypedList(new LinkedList(), Dual.class, false);
		defs = new HashMap();
		defs.put(nullp, null);
	}

	public void addProperty(Property prop) {
		props.add(prop);
	}

	public void setProperties(List props) {
		this.props = new ArrayList(props);
	}

	public List properties() {
		// XXX init.initProperties() - lazy initialize
		return Collections.unmodifiableList(props);
	}

	public Property propertyNamed(String name) {
		// XXX init.initProperties() - lazy initialize
		
		for (Iterator i = props.iterator(); i.hasNext(); ) {
            Property p = (Property) i.next();
            if (p.name().equals(name)) {
                return p;
            }
        }
		
		return null;
	}
	
	public void setInvariants(List invs) {
		this.invs = new ArrayList(invs);
	}
	
	public List invariants() {
		// XXX init.initInvariants() - lazy initialize
		return Collections.unmodifiableList(invs);
	}
	
	public void addInvariant(Dual inv) {
		invs.add(inv);
	}
	
	public void mapDefine(Property prop, Dual def) {
		defs.put(prop, def);
	}
	
	public boolean isAbstract(Property prop)
		throws PropertyNotFoundException
	{
		if (!defs.containsKey(prop))
			throw new PropertyNotFoundException(prop.toString());
		return defs.containsKey(prop) &&
				defs.get(prop) == null;
	}
	
	public Dual getDefinition(Property prop)
		throws PropertyNotFoundException
	{
		if (!defs.containsKey(prop))
			throw new PropertyNotFoundException(prop.toString());
		return (Dual) defs.get(prop);
	}
	
	public Set definitions() {
		return Collections.unmodifiableSet(defs.entrySet());
	}

	public boolean isPure() {
		for (Iterator it = methods().iterator() ; it.hasNext(); ) {
			if (!((ProcedureInstance)it.next()).
					flags().contains(SpecJavaFlags.PURE))
				return false;
		}
		for (Iterator it = constructors().iterator(); it.hasNext(); ) {
			if (!((ProcedureInstance)it.next()).
					flags().contains(SpecJavaFlags.PURE))
				return false;
		}
		return true;
	}
}
