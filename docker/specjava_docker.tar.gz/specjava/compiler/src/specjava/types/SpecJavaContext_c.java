package specjava.types;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import polyglot.types.Context_c;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;

public class SpecJavaContext_c extends Context_c implements SpecJavaContext {

	protected Map props; 
	
	public SpecJavaContext_c(TypeSystem ts) {
		super(ts);
	}
	
	protected Context_c push() {
		SpecJavaContext_c c = (SpecJavaContext_c) super.push();
		c.props = null;
		return c;
	}
	
	public Property findPropertyz(String name) throws SemanticException {
		Property prop = null;
		
		if (props != null)
			prop = (Property) props.get(name);
		
		if (prop != null)
			return prop;
		
		if (outer != null) 
			return ((SpecJavaContext) outer).findPropertyz(name);
		
		throw new SemanticException("Property \"" + name + "\" not found.");
	}
	
	public void addProperty(Property prop) {
		if (props == null) props = new HashMap();
		props.put(prop.name(), prop);
	}

	public Property findProperty(String name) throws SemanticException {
		Property p = findPropertySilent(name);

		if (p != null)
			return p;

		throw new SemanticException("Property \"" + name + "\" not found.");
	}

	public Property findPropertySilent(String name) {

		Property vi = findPropertyInThisScope(name);

		if (vi != null) {
			return vi;
		}

		if (outer != null) {
			return ((SpecJavaContext) outer).findPropertySilent(name);
		}

		return null;
	}

	public Property findPropertyInThisScope(String name) {
		Property vi = null;
		if (props != null) {
			vi = (Property) props.get(name);
		}
		if (vi == null && isClass()) {
			return ((SpecJavaReferenceType) this.type).propertyNamed(name);
		}
		return vi;
	}
	
	public Set variablesInScope() {
		return vars == null ? new HashSet() : vars.keySet();
	}
}
