package specjava.types;

import java.util.List;

import polyglot.types.ParsedClassType;
import specjava.logic.formula.Dual;

public interface SpecJavaParsedClassType extends SpecJavaClassType, ParsedClassType {
	void addProperty(Property prop);
	void mapDefine(Property prop, Dual def);
	void setProperties(List props);
	void addInvariant(Dual inv);
	void setInvariants(List invs);
}
