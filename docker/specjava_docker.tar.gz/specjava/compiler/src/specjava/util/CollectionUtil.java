package specjava.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Utilities class for operations with
 * collections.
 */
public final class CollectionUtil {

	public static final Set difference(Set s1, Set s2) {
		Set res = new HashSet();
		for (Iterator it = s1.iterator(); it.hasNext() ; ) {
			Object o = it.next();
			if (!s2.contains(o))
				res.add(o);
		}
		return res;
	}

	public static final Set intersection(Set s1, Set s2) {
		Set res = new HashSet();
		for (Iterator it = s1.iterator(); it.hasNext() ; ) {
			Object o = it.next();
			if (s2.contains(o))
				res.add(o);
		}
		return res;
	}

	public static final Set union(Set s1, Set s2) {
		Set res = new HashSet();
		res.addAll(s1);
		res.addAll(s2);
		return res;
	}
	
	public static final Set asSet(List l) {
		Set res = new HashSet();
		for (Iterator it = l.iterator(); it.hasNext();)
			res.add(it.next());
		return res;
	}
	
}
