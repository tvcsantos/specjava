package specjava;

import polyglot.main.Report;

/**
 * Extension information for specjava extension.
 */
public class Topics {
    public static final String specjava = "specjava";

    static {
        Report.topics.add(specjava);
    }
}
