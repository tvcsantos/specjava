package specjava.extension.statement;

import java.util.List;

import polyglot.ast.If;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;

public class SpecJavaIfExt_c extends SpecJavaStmtExt_c implements
		SpecJavaStmtExt {

	public Dual wp(WPCalculus calc, Dual post) throws WPCalculusException {
		return calc.wp((If)node(), post);
	}
	
	public List vc(WPCalculus calc, Dual post) throws WPCalculusException {
		return calc.vc((If)node(), post);
	}
}
