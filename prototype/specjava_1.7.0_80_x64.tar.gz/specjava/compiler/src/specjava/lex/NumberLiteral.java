/*
 * This file is part of the Polyglot extensible compiler framework.
 *
 * Copyright (c) 2000-2006 Polyglot project group, Cornell University
 * 
 */

package specjava.lex;

import polyglot.lex.Literal;
import polyglot.util.Position;

/** Token class for number literals (pos, neg, zero). */
public class NumberLiteral extends Literal {
    protected int val;
  public NumberLiteral(Position position, int n, int sym) {
      super(position, sym);
      this.val = n;
  }
  
  public String toString() {
      return "number literal " + 
	(val < 0 ? "neg" : val > 0 ? "pos" : "zero");
  }

  public boolean isPos()  { return val > 0; }
  public boolean isNeg()  { return val < 0; }
  public boolean isZero() { return val == 0; }
}
