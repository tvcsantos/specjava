package specjava.types;

import polyglot.util.Enum;

public interface NumberProperty extends Property {

	public static final Type POS = new Type("pos");
	public static final Type NEG = new Type("neg");
	public static final Type ZERO = new Type("zero");
			
	public static class Type extends Enum {
		private static final long serialVersionUID = -2039287956843824280L;

		public Type(String name) {
			super(name);
		}
	}
}
