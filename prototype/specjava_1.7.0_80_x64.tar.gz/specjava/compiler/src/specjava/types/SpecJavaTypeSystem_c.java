package specjava.types;

import java.util.LinkedList;
import java.util.List;

import polyglot.frontend.Source;
import polyglot.types.ArrayType;
import polyglot.types.ClassType;
import polyglot.types.ConstructorInstance;
import polyglot.types.Context;
import polyglot.types.Flags;
import polyglot.types.LazyClassInitializer;
import polyglot.types.MethodInstance;
import polyglot.types.ParsedClassType;
import polyglot.types.PrimitiveType;
import polyglot.types.ReferenceType;
import polyglot.types.Type;
import polyglot.types.TypeSystem_c;
import polyglot.types.PrimitiveType.Kind;
import polyglot.util.Position;
import specjava.logic.formula.Dual;

public class SpecJavaTypeSystem_c extends TypeSystem_c implements SpecJavaTypeSystem {

	// implement new methods in SpecJavaTypeSystem.
    // override methods as needed from TypeSystem_c.
	
	public Property BooleanProperty(Position pos,
			boolean value) {
		return new BooleanProperty_c(this, pos, value);
	}

	public Property NullProperty(Position pos) {
		return new NullProperty_c(this, pos);
	}

	public Property NumberProperty(Position pos, Property.NumberType type) {
		return new NumberProperty_c(this, pos, type);
	}

	public Property NamedProperty(Position pos, String name) {
		return new NamedProperty_c(this, pos, name);
	}
	
	public Property NamedProperty(Position pos, String name, ClassType ct) {
		return new NamedProperty_c(this, pos, name, ct);
	}
	
	public ParsedClassType createClassType(LazyClassInitializer init,
			Source fromSource) {
	    return new SpecJavaParsedClassType_c(this, init, fromSource);
	}
	
	protected ArrayType createArrayType(Position pos, Type type) {
		return new SpecJavaArrayType_c(this, pos, type);
	}
	
	public Context createContext() {
		return new SpecJavaContext_c(this);
	}	
	
	public MethodInstance methodInstance(Position pos, ReferenceType container,
			Flags flags, Type returnType, String name, List argTypes,
			List excTypes) {
		return new SpecJavaMethodInstance_c(this, pos, container, flags, 
				returnType, name, null, argTypes, excTypes);
	}
	
	public ConstructorInstance constructorInstance(Position pos,
			ClassType container, Flags flags, List argTypes, List excTypes) {
		return new SpecJavaConstructorInstance_c(this, pos, container,
				flags, null, argTypes, excTypes);
	}
	
	protected PrimitiveType createPrimitive(Kind kind) {
		return new SpecJavaPrimitiveType_c(this, kind);
	}
	
	public ConstructorInstance defaultConstructor(Position pos,
			ClassType container) {
		SpecJavaConstructorInstance_c ci = (SpecJavaConstructorInstance_c)
			super.defaultConstructor(pos, container);
		ci.setFormalNames(new LinkedList());
		ci.setPreconditiond(Dual.TRUE_EMPTY);
		ci.setPostconditiond(Dual.TRUE_EMPTY);
		return ci;
	}
	
	public Flags legalMethodFlags() {
		return super.legalMethodFlags().set(SpecJavaFlags.PURE);
	}
	
	public Flags legalConstructorFlags() {
		return super.legalConstructorFlags().set(SpecJavaFlags.PURE);
	}
}
