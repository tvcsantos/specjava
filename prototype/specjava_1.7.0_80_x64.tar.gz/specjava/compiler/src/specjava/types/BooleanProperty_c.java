package specjava.types;

import polyglot.types.Type;
import polyglot.types.TypeObject;
import polyglot.types.TypeObject_c;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

public final class BooleanProperty_c
	extends TypeObject_c implements Property {
	
	private static final long serialVersionUID = -7803016956445282379L;
	
	protected boolean value;
	
	public BooleanProperty_c(
			TypeSystem ts, Position pos, boolean value) {
		super(ts, pos);
		this.value = value;
	}

	public String name() {
		return value + "";
	}
	
	public String fullName() {
		return name();
	}

	public boolean isCanonical() {
		return true;
	}

	public boolean typeConforms(Type t) {
		return t.isReference() || t.isBoolean();
	}
	
	public boolean isBaseProperty() {
		return true;
	}
	
	public boolean equalsImpl(TypeObject t) {
		if (t instanceof Property) {
			return name().equalsIgnoreCase(((Property) t).name());
        }
        return false;
	}
	
	public String toString() {
        return name();
    }
	
	public boolean isLocal() {
		return false;
	}
}
