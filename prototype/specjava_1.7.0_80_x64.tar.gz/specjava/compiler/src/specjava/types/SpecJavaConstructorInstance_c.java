package specjava.types;

import java.util.Collections;
import java.util.List;

import polyglot.types.ClassType;
import polyglot.types.ConstructorInstance_c;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.TypeSystem;
import polyglot.util.Position;
import polyglot.util.TypedList;
import specjava.logic.formula.Dual;

public class SpecJavaConstructorInstance_c extends ConstructorInstance_c implements
		SpecJavaProcedureInstance {
	
	private static final long serialVersionUID = -9158042624719097864L;
	
	protected List fnames;
	
	protected Dual pred;
	protected Dual postd;
	
	public boolean isCanonical() {
		return fnames != null && listIsCanonical(fnames)
			&& super.isCanonical();
	}
	
	public boolean isFullCanonical() {
		return isCanonical()
			&& pred != null && pred.isCanonical()
			&& postd != null && postd.isCanonical();
	}

	public SpecJavaConstructorInstance_c(TypeSystem ts, Position pos,
			ClassType container, Flags flags, List formalNames,
			List formalTypes, List excTypes) {
		super(ts, pos, container, flags, formalTypes, excTypes);
		this.fnames = TypedList.copyAndCheck(formalNames, LocalInstance.class, true);
	}

	public List formalNames() {
		return fnames == null ? null : Collections.unmodifiableList(fnames);
	}

	public SpecJavaProcedureInstance formalNames(List names) {
		SpecJavaConstructorInstance_c i = (SpecJavaConstructorInstance_c) copy();
		i.fnames = TypedList.copyAndCheck(names, LocalInstance.class, true);
		return i;
	}
	
	public void setFormalNames(List names) {
		this.fnames = TypedList.copyAndCheck(names, LocalInstance.class, true);
	}

	public Dual postconditiond() {
		return postd;
	}

	public Dual preconditiond() {
		return pred;
	}

	public void setPostconditiond(Dual post) {
		this.postd = post;
	}

	public void setPreconditiond(Dual pre) {
		this.pred = pre;
	}
	
	
}
