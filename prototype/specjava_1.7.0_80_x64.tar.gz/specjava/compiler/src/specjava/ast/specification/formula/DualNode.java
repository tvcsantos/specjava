package specjava.ast.specification.formula;

import java.util.List;

import polyglot.ast.Node;

/**
 * Interface representing a
 * dual formula node.
 */
public interface DualNode extends Node {
	
	/**
	 * The classic formula of
	 * the dual formula.
	 */
	FormulaNode classicFormula();
	
	/**
	 * Set the classic formula
	 * of the dual formula.
	 */
	DualNode classicFormula(FormulaNode pn);
	
	/**
	 * The linear formula of
	 * the dual formula.
	 */
	List sepLogicFormulas(); // List[FormulaNode]

	/**
	 * Set the linear formula
	 * of the dual formula.
	 */
	DualNode sepLogicFormulas(List slf);
}