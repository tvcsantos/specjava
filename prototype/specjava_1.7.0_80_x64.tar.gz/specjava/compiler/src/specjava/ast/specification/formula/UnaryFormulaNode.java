package specjava.ast.specification.formula;

import polyglot.ast.Unary;

/**
 * A <code>UnaryFormulaNode</code> represents a 
 * unary formula node, an immutable pair of
 * a formula node and an an operator.
 */
public interface UnaryFormulaNode extends FormulaNode {
	
	/** The sub-formula node on that to apply the operator. */
	FormulaNode formulaNode();
	
	/** Set the sub-formula node on that to apply the operator. */
	UnaryFormulaNode formulaNode(FormulaNode fn);
	
	/** The operator to apply on the sub-formula node. */
	Unary.Operator operator();
	
	/** Set the operator to apply on the sub-formula node. */
	UnaryFormulaNode operator(Unary.Operator op);
}
