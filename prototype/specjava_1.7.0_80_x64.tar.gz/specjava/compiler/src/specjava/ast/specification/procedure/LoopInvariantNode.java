package specjava.ast.specification.procedure;

import specjava.ast.specification.SpecificationNode;
import specjava.ast.specification.formula.DualNode;

/**
 * Interface representing a loop invariant
 * specification node.
 */
public interface LoopInvariantNode extends SpecificationNode {
	/**
	 * Set the dual node of
	 * the loop invariant node.
	 */
	LoopInvariantNode dualNode(DualNode dn);
}
