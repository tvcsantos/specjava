package specjava.ast.specification.procedure;

import java.util.List;

import polyglot.ast.Node;
import polyglot.ast.Stmt_c;
import polyglot.ast.Term;
import polyglot.util.Position;
import polyglot.visit.CFGBuilder;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.formula.DualNode;

/**
 * Class implementing Assume.
 */
public class Assume_c extends Stmt_c implements Assume {

	protected DualNode dual;
	
	public Assume_c(Position pos, DualNode dual) {
		super(pos);
		assert(dual != null);
		this.dual = dual;
	}

	public List acceptCFG(CFGBuilder v, List succs) {
		return succs;
	}

	public Term firstChild() {
		return null;
	}
	
	protected Assume_c reconstruct(DualNode dual) {
		if (dual != this.dual) {
			Assume_c n = (Assume_c) copy();
			n.dual = dual;
			return n;
		}

		return this;
	}

	public Node visitChildren(NodeVisitor v) {
		DualNode dual = (DualNode) visitChild(this.dual, v);
		return reconstruct(dual);
	}
	
	public DualNode dualNode() {
		return dual;
	}

	public Assume dualNode(DualNode dn) {
		Assume_c n = (Assume_c) copy();
		n.dual = dn;
		return n;
	}
	
	public String toString() {
		return "assume " + dual + ";";
	}
}
