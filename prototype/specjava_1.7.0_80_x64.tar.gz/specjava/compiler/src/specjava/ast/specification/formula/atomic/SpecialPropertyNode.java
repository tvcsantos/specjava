package specjava.ast.specification.formula.atomic;

import polyglot.util.Enum;

/**
 * A <code>SpecialPropertyNode</code> represents
 * property nodes for special names like this and return 
 */
public interface SpecialPropertyNode extends SinglePropertyNode {
	public static class Kind extends Enum {
		private static final long serialVersionUID = -6375434793090568121L;

		public Kind(String name) { super(name); }
    }

    public static final Kind RETURN = new Kind("return");
    public static final Kind THIS  = new Kind("this");
    
    /** Get the kind of special property node: RETURN or THIS. */
    Kind kind();
    
    /** Set the kind of special property node: RETURN or THIS. */
    SpecialPropertyNode kind(Kind kind);
}
