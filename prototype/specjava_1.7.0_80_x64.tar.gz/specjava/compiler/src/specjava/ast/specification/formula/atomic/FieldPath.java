package specjava.ast.specification.formula.atomic;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.Field;
import polyglot.ast.NodeFactory;
import polyglot.ast.Receiver;
import polyglot.ast.Special;
import polyglot.types.FieldInstance;
import polyglot.types.Type;
import polyglot.util.Position;

public class FieldPath implements Serializable {
	
	private static final long serialVersionUID = 8854394796733186564L;
	
	protected Type c;
	protected List path;
	
	public FieldPath(Type c, List path) {
		this.c = c;
		this.path = path;
	}
	
	public final Field toField(NodeFactory nf) {
		Special s = nf.This(c.position());
		Iterator it = path.iterator();
		Field curr = null;
		while (it.hasNext()) {
			FieldInstance fi = (FieldInstance) it.next();
			Position pos = fi.position();
			String name = fi.name();
			Receiver t = null;
			if (curr == null) t = s;
			else t = curr;
			curr = nf.Field(pos, t, nf.Id(pos, name));
		}
		return curr;
	}
}
