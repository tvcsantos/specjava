package specjava.ast.extension;

import java.util.List;

import polyglot.ast.Node;
import polyglot.ast.ProcedureDecl;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;
import specjava.visit.WeakestPreconditionBuilder;

/**
 * A procedure declaration. A procedure is the supertype
 * of methods and constructors.
 */
public interface SpecJavaProcedureDecl extends ProcedureDecl {

	/**
	 * The procedure weakest precondition.
	 * This field may not be valid until
     * after building weakest precondition.
	 */
	Dual weakestPrecondition();	
	
	 /** 
	 * The procedure's specifications.
     * @return A list of {@link specjava.ast.specification.SpecificationNode}.
     */
	List specs();
	
	/**
	 * Builds weakest precondition.
     *
     * This method is called by the <code>leave()</code> method of the
     * visitor. The method should perform work that should be done
     * after visiting the children of the node.  The method may return
     * <code>this</code> or a new copy of the node which will be
     * installed as a child of the node's parent.
     *
     * @param v The visitor which build weakest preconditions.
	 * @throws WPCalculusException 
     */
	Node buildWP(WeakestPreconditionBuilder v) throws WPCalculusException;
	
	/**
	 * The procedure's verification conditions.
	 * This field may not be valid until
     * after building weakest precondition.
     * @return A list of {@link specjava.logic.formula.Dual}.
     */
	List verificationConditions();

}
