package specjava.ast.extension;

import polyglot.ast.Loop;
import specjava.ast.specification.procedure.LoopInvariantNode;

/**
 * An immutable representation of a SpecJava language loop
 * <code>for</code>, <code>do</code>, <code>while</code>
 * statement. Contains a statement to be executed, an expression
 * to be tested indicating whether to re-execute the statement
 * and the invariant of the loop.
 */
public interface SpecJavaLoop extends Loop {
	
	/** Loop invariant. */
	LoopInvariantNode invariant();
	
	/** Set the loop invariant. */
	SpecJavaLoop invariant(LoopInvariantNode inv);
}
