package specjava.ast.extension;

import java.util.List;

import polyglot.ast.Expr;
import polyglot.ast.For_c;
import polyglot.ast.Node;
import polyglot.ast.NodeList;
import polyglot.ast.Stmt;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.procedure.LoopInvariantNode;

/**
 * An immutable representation of a SpecJava language <code>for</code>
 * statement.  Contains a statement to be executed and an expression
 * to be tested indicating whether to reexecute the statement,
 * and has an invariant associated.
 */ 
public class SpecJavaFor_c	extends For_c implements SpecJavaLoop {
	
	protected LoopInvariantNode inv;
	
	public SpecJavaFor_c(Position pos, List inits, Expr cond, List iters,
			LoopInvariantNode inv, Stmt body) {
		super(pos, inits, cond, iters, body);
		assert(inv != null);
		this.inv = inv;
	}
	
	public LoopInvariantNode invariant() {
		return inv;
	}

	public SpecJavaLoop invariant(LoopInvariantNode inv) {
		SpecJavaFor_c n = (SpecJavaFor_c) copy();
		n.inv = inv;
		return n;
	}
	
	protected SpecJavaFor_c reconstruct(List inits, Expr cond, List iters,
			LoopInvariantNode inv, Stmt body) {
		if (inv != this.inv) {
			SpecJavaFor_c n = (SpecJavaFor_c) copy();
			n.inv = inv;
			return (SpecJavaFor_c) n.reconstruct(inits, cond, iters, body);
		}

		return (SpecJavaFor_c) super.reconstruct(inits, cond, iters, body);
	}
	
	public Node visitChildren(NodeVisitor v) {
		List inits = visitList(this.inits, v);
		Expr cond = (Expr) visitChild(this.cond, v);
		List iters = visitList(this.iters, v);
		LoopInvariantNode inv = (LoopInvariantNode) visitChild(this.inv, v);
		Node body = visitChild(this.body, v);
		if (body instanceof NodeList)
			body = ((NodeList) body).toBlock();
		return reconstruct(inits, cond, iters, inv, (Stmt) body);
	}
}
