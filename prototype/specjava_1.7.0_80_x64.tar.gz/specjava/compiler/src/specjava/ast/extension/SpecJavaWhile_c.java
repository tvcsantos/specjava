package specjava.ast.extension;

import polyglot.ast.Expr;
import polyglot.ast.Node;
import polyglot.ast.NodeList;
import polyglot.ast.Stmt;
import polyglot.ast.While_c;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.procedure.LoopInvariantNode;

/**
 * An immutable representation of a SpecJava language <code>while</code>
 * statement.  It contains a statement to be executed and an expression
 * to be tested indicating whether to reexecute the statement,
 * and has an invariant associated.
 */ 
public class SpecJavaWhile_c extends While_c implements SpecJavaLoop {
	
	protected LoopInvariantNode inv;

	public SpecJavaWhile_c(Position pos, Expr cond, LoopInvariantNode inv, Stmt body) {
		super(pos, cond, body);
		assert(inv != null);
		this.inv = inv;
	}

	public LoopInvariantNode invariant() {
		return inv;
	}

	public SpecJavaLoop invariant(LoopInvariantNode inv) {
		SpecJavaWhile_c n = (SpecJavaWhile_c) copy();
		n.inv = inv;
		return n;
	}
	
	protected SpecJavaWhile_c reconstruct(Expr cond, LoopInvariantNode inv, Stmt body) {
		if (inv != this.inv) {
			SpecJavaWhile_c n = (SpecJavaWhile_c) copy();
			n.inv = inv;
			return (SpecJavaWhile_c) n.reconstruct(cond, body);
		}

		return (SpecJavaWhile_c) super.reconstruct(cond, body);
	}
	
	public Node visitChildren(NodeVisitor v) {
		Expr cond = (Expr) visitChild(this.cond, v);
		LoopInvariantNode inv = (LoopInvariantNode) visitChild(this.inv, v);
		Node body = visitChild(this.body, v);
		if (body instanceof NodeList)
			body = ((NodeList) body).toBlock();
		return reconstruct(cond, inv, (Stmt) body);
	}
}
