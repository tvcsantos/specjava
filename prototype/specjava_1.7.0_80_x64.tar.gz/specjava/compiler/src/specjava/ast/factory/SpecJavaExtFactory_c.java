package specjava.ast.factory;

import polyglot.ast.AbstractExtFactory_c;
import polyglot.ast.Ext;
import specjava.extension.SpecJavaProcedureDeclExt_c;
import specjava.extension.statement.AssumeExt_c;
import specjava.extension.statement.SpecJavaBlockExt_c;
import specjava.extension.statement.SpecJavaConstructorCallExt_c;
import specjava.extension.statement.SpecJavaEmptyExt_c;
import specjava.extension.statement.SpecJavaEvalExt_c;
import specjava.extension.statement.SpecJavaIfExt_c;
import specjava.extension.statement.SpecJavaLocalDeclExt_c;
import specjava.extension.statement.SpecJavaLoopExt_c;
import specjava.extension.statement.SpecJavaReturnExt_c;
import specjava.extension.statement.SpecJavaStmtExt_c;
import specjava.extension.statement.SpecJavaSynchronizedExt_c;
import specjava.extension.statement.StaticAssertExt_c;

/**
 * ExtFactory for specjava extension.
 */
public class SpecJavaExtFactory_c extends AbstractExtFactory_c implements
		SpecJavaExtFactory {

	public SpecJavaExtFactory_c() {
		super();
	}

	public final Ext extStaticAssert() {
		Ext e = extStaticAssertImpl();
		return e;
	}
	
	public final Ext extAssume() {
		Ext e = extAssumeImpl();
		return e;
	}

	protected Ext extStmtImpl() {
		return new SpecJavaStmtExt_c();
	}

	protected Ext extBlockImpl() {
		return new SpecJavaBlockExt_c();
	}

	protected Ext extIfImpl() {
		return new SpecJavaIfExt_c();
	}

	protected Ext extEvalImpl() {
		return new SpecJavaEvalExt_c();
	}

	protected Ext extReturnImpl() {
		return new SpecJavaReturnExt_c();
	}
	
	protected Ext extLoopImpl() {
		return new SpecJavaLoopExt_c();
	}

	protected Ext extLocalDeclImpl() {
		return new SpecJavaLocalDeclExt_c();
	}
	
	protected Ext extProcedureDeclImpl() {
		return new SpecJavaProcedureDeclExt_c();
	}
	
	protected Ext extAssumeImpl() {
		return new AssumeExt_c();
	}
	
	protected Ext extStaticAssertImpl() {
		return new StaticAssertExt_c();
	}
	
	protected Ext extSynchronizedImpl() {
		return new SpecJavaSynchronizedExt_c();
	}
	
	protected Ext extConstructorCallImpl() {
		return new SpecJavaConstructorCallExt_c();
	}
	
	protected Ext extEmptyImpl() {
		return new SpecJavaEmptyExt_c();
	}
}
