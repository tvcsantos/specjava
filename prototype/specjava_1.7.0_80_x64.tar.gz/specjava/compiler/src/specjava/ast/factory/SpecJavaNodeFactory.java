package specjava.ast.factory;

import java.util.List;

import polyglot.ast.Binary;
import polyglot.ast.Block;
import polyglot.ast.ConstructorDecl;
import polyglot.ast.Do;
import polyglot.ast.Expr;
import polyglot.ast.For;
import polyglot.ast.Id;
import polyglot.ast.MethodDecl;
import polyglot.ast.NodeFactory;
import polyglot.ast.Stmt;
import polyglot.ast.TypeNode;
import polyglot.ast.Unary;
import polyglot.ast.While;
import polyglot.types.Flags;
import polyglot.util.Position;
import specjava.ast.specification.clazz.ClassDefineNode;
import specjava.ast.specification.clazz.ClassInvariantNode;
import specjava.ast.specification.formula.AmbiguousFormulaNode;
import specjava.ast.specification.formula.BinaryFormulaNode;
import specjava.ast.specification.formula.DualNode;
import specjava.ast.specification.formula.FormulaNode;
import specjava.ast.specification.formula.UnaryFormulaNode;
import specjava.ast.specification.formula.atomic.NormalPropertyNode;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode;
import specjava.ast.specification.formula.atomic.TruthConstantNode;
import specjava.ast.specification.procedure.Assume;
import specjava.ast.specification.procedure.LoopInvariantNode;
import specjava.ast.specification.procedure.ProcedureAssertionNode;
import specjava.ast.specification.procedure.StaticAssert;

/**
 * NodeFactory for specjava extension.
 */
public interface SpecJavaNodeFactory extends NodeFactory {
	
	DualNode DualNode(Position pos, FormulaNode classicFormula);
	DualNode DualNode(Position pos, FormulaNode classicFormula, List sepLogicFormulas);
	DualNode DualNode(Position pos, List sepLogicFormulas);
    
	ClassDefineNode ClassConcreteDefineNode(Position pos, Id id, DualNode fn);
	ClassDefineNode ClassAbstractDefineNode(Position pos, Id id);
	ClassInvariantNode ClassInvariantNode(Position pos, DualNode fn);
	ProcedureAssertionNode ProcedureAssertionNode(Position pos, DualNode fn, boolean requires);
	ProcedureAssertionNode RequiresNode(Position pos, DualNode fn);
	ProcedureAssertionNode EnsuresNode(Position pos, DualNode fn);
		
	StaticAssert StaticAssert(Position pos, DualNode fn);
	Assume Assume(Position pos, DualNode fn);
	LoopInvariantNode LoopInvariantNode(Position pos, DualNode fn);
	
	NormalPropertyNode NormalPropertyNode(Position pos, Expr expr, Id prop);	
	SpecialPropertyNode ThisPropertyNode(Position pos, Id prop);
	SpecialPropertyNode ReturnPropertyNode(Position pos, Id prop);
	TruthConstantNode TruthConstantNode(Position pos, boolean value);
	
	AmbiguousFormulaNode AmbiguousFormulaNode(Position pos, Id prop);
	
	BinaryFormulaNode BinaryFormulaNode(Position pos, FormulaNode left,
			Binary.Operator op, FormulaNode right);
	
	UnaryFormulaNode UnaryFormulaNode(Position pos, Unary.Operator op,
			FormulaNode pnode);
		
	ConstructorDecl SpecJavaConstructorDecl(Position pos,
			Flags flags, Id name, List formals, List specs,
			List throwTypes, Block body);
	
	ConstructorDecl ConstructorDecl(Position pos, Flags flags, Id name,
            List formals, List throwTypes,
            Block body);
	
	MethodDecl SpecJavaMethodDecl(Position pos, 
			Flags flags, TypeNode returnType, Id name,
            List formals, List specs, List throwTypes, Block body);
	
	MethodDecl MethodDecl(Position pos, Flags flags, TypeNode returnType, Id name,
			List formals, List throwTypes, Block body);
	
	Do SpecJavaDo(Position pos, Stmt body, Expr cond, LoopInvariantNode inv);
	
	Do Do(Position pos, Stmt body, Expr cond);
	
	While SpecJavaWhile(Position pos, Expr cond, LoopInvariantNode inv, Stmt body);
	
	While While(Position pos, Expr cond, Stmt body);
	
	For SpecJavaFor(Position pos, List inits, Expr cond,
			List iters, LoopInvariantNode inv, Stmt body);
	
	 For For(Position pos, List inits, Expr cond, List iters, Stmt body);
}
