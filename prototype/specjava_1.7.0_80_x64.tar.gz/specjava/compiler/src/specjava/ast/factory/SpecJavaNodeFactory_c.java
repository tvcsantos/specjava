package specjava.ast.factory;

import java.util.LinkedList;
import java.util.List;

import polyglot.ast.Binary;
import polyglot.ast.Block;
import polyglot.ast.ConstructorDecl;
import polyglot.ast.Do;
import polyglot.ast.Expr;
import polyglot.ast.For;
import polyglot.ast.Id;
import polyglot.ast.MethodDecl;
import polyglot.ast.NodeFactory_c;
import polyglot.ast.Stmt;
import polyglot.ast.TypeNode;
import polyglot.ast.Unary;
import polyglot.ast.While;
import polyglot.types.Flags;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import specjava.ast.extension.SpecJavaConstructorDecl_c;
import specjava.ast.extension.SpecJavaDo_c;
import specjava.ast.extension.SpecJavaFor_c;
import specjava.ast.extension.SpecJavaMethodDecl_c;
import specjava.ast.extension.SpecJavaWhile_c;
import specjava.ast.specification.clazz.ClassDefineNode;
import specjava.ast.specification.clazz.ClassDefineNode_c;
import specjava.ast.specification.clazz.ClassInvariantNode;
import specjava.ast.specification.clazz.ClassInvariantNode_c;
import specjava.ast.specification.formula.AmbiguousFormulaNode;
import specjava.ast.specification.formula.AmbiguousFormulaNode_c;
import specjava.ast.specification.formula.BinaryFormulaNode;
import specjava.ast.specification.formula.BinaryFormulaNode_c;
import specjava.ast.specification.formula.DualNode;
import specjava.ast.specification.formula.DualNode_c;
import specjava.ast.specification.formula.FormulaNode;
import specjava.ast.specification.formula.UnaryFormulaNode;
import specjava.ast.specification.formula.UnaryFormulaNode_c;
import specjava.ast.specification.formula.atomic.NormalPropertyNode;
import specjava.ast.specification.formula.atomic.NormalPropertyNode_c;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode_c;
import specjava.ast.specification.formula.atomic.TruthConstantNode;
import specjava.ast.specification.formula.atomic.TruthConstantNode_c;
import specjava.ast.specification.procedure.Assume;
import specjava.ast.specification.procedure.Assume_c;
import specjava.ast.specification.procedure.LoopInvariantNode;
import specjava.ast.specification.procedure.LoopInvariantNode_c;
import specjava.ast.specification.procedure.ProcedureAssertionNode;
import specjava.ast.specification.procedure.ProcedureAssertionNode_c;
import specjava.ast.specification.procedure.StaticAssert;
import specjava.ast.specification.procedure.StaticAssert_c;
import specjava.logic.formula.Formula;

/**
 * NodeFactory for specjava extension.
 */
public class SpecJavaNodeFactory_c extends NodeFactory_c implements SpecJavaNodeFactory {
	
    // Implement factory methods for new AST nodes.
    // Override factory methods for overriden AST nodes.
    // Override factory methods for AST nodes with new extension nodes.
	
	public SpecJavaNodeFactory_c() {
		super(new SpecJavaExtFactory_c(), new SpecJavaDelFactory_c());
	}
	
	public DualNode DualNode(Position pos, FormulaNode classicFormula,
			List sepLogicFormulas) {
		DualNode fn = new DualNode_c(pos, classicFormula, sepLogicFormulas);
		return fn;
	}
	
	public DualNode DualNode(Position pos, FormulaNode classicFormula) {
		DualNode fn = new DualNode_c(pos, classicFormula, new LinkedList());
		return fn;
	}
	
	public DualNode DualNode(Position pos, List sepLogicFormulas) {
		DualNode fn = new DualNode_c(pos, 
				TruthConstantNode(Position.COMPILER_GENERATED, true), sepLogicFormulas);
		return fn;
	}
	
	public ClassDefineNode ClassAbstractDefineNode(
			Position pos, Id id) {
		ClassDefineNode cadn = new ClassDefineNode_c(pos, id, null);
		return cadn;
	}

	public ClassDefineNode ClassConcreteDefineNode(
			Position pos, Id id, DualNode fn) {
		ClassDefineNode ccdn = new ClassDefineNode_c(pos, id, fn);
		return ccdn;
	}

	public ProcedureAssertionNode EnsuresNode(Position pos, DualNode fn) {
		return ProcedureAssertionNode(pos, fn, false);
	}

	public ClassInvariantNode ClassInvariantNode(Position pos,
			DualNode fn) {
		ClassInvariantNode in = new ClassInvariantNode_c(pos, fn);
		return in;
	}
	
	public LoopInvariantNode LoopInvariantNode(Position pos,
			DualNode fn) {
		LoopInvariantNode in = new LoopInvariantNode_c(pos, fn);
		return in;
	}

	public ProcedureAssertionNode RequiresNode(Position pos, DualNode fn) {
		return ProcedureAssertionNode(pos, fn, true);
	}
	
	public ProcedureAssertionNode ProcedureAssertionNode(Position pos,
			DualNode fn, boolean requires) {
		ProcedureAssertionNode rn = new ProcedureAssertionNode_c(pos, fn, requires);
		return rn;
	}
	
	public StaticAssert StaticAssert(Position pos, DualNode fn) {
		StaticAssert sa = new StaticAssert_c(pos, fn);
		sa = (StaticAssert)sa.ext(((SpecJavaExtFactory)extFactory()).extStaticAssert());
		return sa;
	}
	
	public Assume Assume(Position pos, DualNode fn) {
		Assume sa = new Assume_c(pos, fn);
		sa = (Assume)sa.ext(((SpecJavaExtFactory)extFactory()).extAssume());
		return sa;
	}
	
	public BinaryFormulaNode BinaryFormulaNode(Position pos,
			FormulaNode left, Binary.Operator op, FormulaNode right) {
		BinaryFormulaNode bpn = new BinaryFormulaNode_c(pos, left, op, right);
		return bpn;
	}
	
	public NormalPropertyNode NormalPropertyNode(Position pos,
			Expr expr, Id prop) {
		NormalPropertyNode npn = new NormalPropertyNode_c(pos, expr, prop);
		return npn;
	}
	
	public SpecialPropertyNode ThisPropertyNode(Position pos, Id prop) {
		SpecialPropertyNode spn = new SpecialPropertyNode_c(pos,
				SpecialPropertyNode.THIS, prop);
		return spn;
	}
	
	public SpecialPropertyNode ReturnPropertyNode(Position pos, Id prop) {
		SpecialPropertyNode spn = new SpecialPropertyNode_c(pos, 
				SpecialPropertyNode.RETURN, prop);
		return spn;
	}
	
	public AmbiguousFormulaNode AmbiguousFormulaNode(Position pos, Id prop) {
		AmbiguousFormulaNode apn = new AmbiguousFormulaNode_c(pos, prop);
		return apn;
	}
	
	public TruthConstantNode TruthConstantNode(Position pos, boolean value) {
		TruthConstantNode bpn = new TruthConstantNode_c(pos, value);
		return bpn;
	}
	
	public UnaryFormulaNode UnaryFormulaNode(Position pos,
			Unary.Operator op, FormulaNode pnode) {
		UnaryFormulaNode upn = new UnaryFormulaNode_c(pos, op, pnode);
		return upn;
	}
	
	public ConstructorDecl SpecJavaConstructorDecl(
			Position pos, Flags flags, Id name, List formals,
			List specs, List throwTypes, Block body) {
		ConstructorDecl condecl = 
			new SpecJavaConstructorDecl_c(pos, flags, name, formals, specs, throwTypes, body);
		condecl = (ConstructorDecl)condecl.ext(extFactory().extConstructorDecl());
		return condecl;
	}
	
	public ConstructorDecl ConstructorDecl(Position pos, Flags flags, Id name,
			List formals, List throwTypes, Block body) {
		List specs = new LinkedList();
		TruthConstantNode rtct = (TruthConstantNode) 
			TruthConstantNode(Position.COMPILER_GENERATED, true).formula(Formula.TRUE);
		TruthConstantNode etct = (TruthConstantNode)
			TruthConstantNode(Position.COMPILER_GENERATED, true).formula(Formula.TRUE);
		specs.add(RequiresNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, rtct, new LinkedList())));
		specs.add(EnsuresNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, etct, new LinkedList())));
		return SpecJavaConstructorDecl(pos, flags, name, formals, specs, throwTypes, body);
	}

	public MethodDecl SpecJavaMethodDecl(Position pos,
			Flags flags, TypeNode returnType, Id name,
			List formals, List specs, List throwTypes, Block body) {
		MethodDecl mdecl = 
			new SpecJavaMethodDecl_c(pos, flags, returnType, name, formals, specs, throwTypes, body);
		mdecl = (MethodDecl)mdecl.ext(extFactory().extMethodDecl());
		return mdecl;
	}
	
	public MethodDecl MethodDecl(Position pos, Flags flags,
			TypeNode returnType, Id name, List formals, List throwTypes,
			Block body) {
		List specs = new LinkedList();
		specs.add(RequiresNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, new LinkedList())));
		specs.add(EnsuresNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, new LinkedList())));
		return SpecJavaMethodDecl(pos, flags, returnType, name, formals, specs, throwTypes, body);
	}
	
	public Do SpecJavaDo(Position pos, Stmt body, Expr cond, LoopInvariantNode inv) {
		Do n = new SpecJavaDo_c(pos, body, cond, inv);
        n = (Do)n.ext(extFactory().extDo());
        n = (Do)n.del(delFactory().delDo());
		return n;
	}
	
	public Do Do(Position pos, Stmt body, Expr cond) {
		return SpecJavaDo(pos, body, cond, LoopInvariantNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, new LinkedList())));
	}
	
	public While SpecJavaWhile(Position pos, Expr cond, LoopInvariantNode inv, Stmt body) {
		While n = new SpecJavaWhile_c(pos, cond, inv, body);
        n = (While)n.ext(extFactory().extWhile());
        n = (While)n.del(delFactory().delWhile());
        return n;
	}
	
	public While While(Position pos, Expr cond, Stmt body) {
		return SpecJavaWhile(pos, cond, LoopInvariantNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, new LinkedList())), body);
	}
	
	public For SpecJavaFor(Position pos, List inits, Expr cond,
			List iters, LoopInvariantNode inv, Stmt body) {
		For n = new SpecJavaFor_c(pos, CollectionUtil.nonNullList(inits), cond, 
				CollectionUtil.nonNullList(iters), inv, body);
        n = (For)n.ext(extFactory().extFor());
        n = (For)n.del(delFactory().delFor());
		return n;
	}
	
	public For For(Position pos, List inits, Expr cond,
			List iters, Stmt body) {
		return SpecJavaFor(pos, inits, cond, iters, LoopInvariantNode(Position.COMPILER_GENERATED,
				DualNode(Position.COMPILER_GENERATED, new LinkedList())), body);
	}
	
}
