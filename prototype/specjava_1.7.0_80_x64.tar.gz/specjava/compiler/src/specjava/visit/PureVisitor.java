package specjava.visit;

import polyglot.ast.Assign;
import polyglot.ast.ConstructorCall;
import polyglot.ast.Expr;
import polyglot.ast.Field;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ast.ProcedureCall;
import polyglot.frontend.Job;
import polyglot.types.ConstructorInstance;
import polyglot.types.ProcedureInstance;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;
import specjava.types.SpecJavaFlags;

public class PureVisitor extends ErrorHandlingVisitor {
	private ProcedureInstance pi;
	private boolean isConstructor;
	private boolean isPure;

	public PureVisitor(Job job, TypeSystem ts, NodeFactory nf,
			ProcedureInstance pi) {
		super(job, ts, nf);
		this.pi = pi;
		isConstructor = false;
		isPure = false;
		if (this.pi instanceof ConstructorInstance)
			isConstructor = true;
		if (this.pi.flags().contains(SpecJavaFlags.PURE))
			isPure = true;
	}
	
	protected Node leaveCall(Node old, Node n, NodeVisitor v)
			throws SemanticException {
		
		if (n instanceof Assign) {
			Assign a = (Assign)n;
			Expr left = a.left();
			if (left instanceof Field && !isConstructor && isPure)
				throw new SemanticException("Procedure cannot " +
						"be pure. Assign to fields!", a.position());				
		} else if (n instanceof ProcedureCall) {
			ProcedureCall pc = (ProcedureCall)n;
			if (pc instanceof ConstructorCall) {
				ConstructorCall cc = (ConstructorCall)pc;
				if (cc.kind() == ConstructorCall.SUPER)
					return n;
			}
			ProcedureInstance pcpi = pc.procedureInstance();
			if (!pcpi.flags().contains(SpecJavaFlags.PURE) && isPure)
				throw new SemanticException("Procedure cannot " +
						"be pure. Calling a linear procedure!", pc.position());
		}
		
		return n;
	}

}
