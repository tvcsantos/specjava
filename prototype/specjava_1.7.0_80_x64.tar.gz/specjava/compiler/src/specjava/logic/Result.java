package specjava.logic;

import polyglot.util.Position;

public class Result {
	private int status;
	private Position pos;
	
	public Result(int status, Position pos) {
		this.status = status;
		this.pos = pos;
	}
	
	public Result(int status) {
		this(status, null);
	}
	
	public int getStatus() {
		return status;
	}
	
	public Position getPosition() {
		return pos;
	}
}
