package specjava.logic.formula.predicate;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class StatePredicate extends AbstractPredicate {

	private static final long serialVersionUID = 2814017510570927075L;
	
	private String prop;
	
	public StatePredicate(String prop, Term t) {
		super(new Term[]{ t });
		this.prop = prop;
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public String getProperty() {
		return prop;
	}

	public String toString() {
		return prop + "(" + getTerm(0) + ")";
	}
}
