package specjava.logic.formula;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Binary;
import polyglot.ast.BooleanLit;
import polyglot.ast.Expr;
import polyglot.ast.Field;
import polyglot.ast.Lit;
import polyglot.ast.Local;
import polyglot.ast.NamedVariable;
import polyglot.ast.Node;
import polyglot.ast.NullLit;
import polyglot.ast.Receiver;
import polyglot.ast.Special;
import polyglot.ast.Unary;
import polyglot.types.SemanticException;
import polyglot.visit.NodeVisitor;
import specjava.logic.DualLogic;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.predicate.Eq;
import specjava.logic.formula.predicate.Gt;
import specjava.logic.formula.predicate.Lt;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.formula.term.function.Constant;
import specjava.logic.formula.term.function.Div;
import specjava.logic.formula.term.function.Minus;
import specjava.logic.formula.term.function.Mod;
import specjava.logic.formula.term.function.Mul;
import specjava.logic.formula.term.function.Plus;
import specjava.logic.formula.unary.Not;
import specjava.logic.visit.DistributeOrOverAnd;
import specjava.logic.visit.ImplicationsOut;
import specjava.logic.visit.NegationsIn;
import specjava.logic.visit.VisitorException;

public abstract class AbstractFormula implements Formula {

	private static final long serialVersionUID = 8549666653723986785L;

	public Formula cnf() throws VisitorException {
		Formula s1 = (Formula) accept(new ImplicationsOut());
		s1 = (Formula) s1.accept(new NegationsIn());
		s1 = (Formula) s1.accept(new DistributeOrOverAnd());
		return s1;
	}
	
	public static final Set vars(Expr e) {
		class VarsVisitor extends NodeVisitor {
			Set s = new HashSet();

			public Node leave(Node parent, Node old, Node n, NodeVisitor v) {
				if (parent instanceof NamedVariable 
						|| parent instanceof Special)
					return n;
				else if (n instanceof NamedVariable) {
					if (n instanceof Local) {
						Local l = (Local) n;
						s.add(l.toString());
					} else if (n instanceof Field) {
						Field f = (Field) n;
						Expr e = getUltimateTarget(f);
						// XXX check
						//System.err.println("ULTIMATE " + f + " IS " + e);
						s.add(e.toString());
						s.add(f.toString());
					}
				} else if (n instanceof Special)
					s.add(n.toString());
				return n;
			}
		}
		
		VarsVisitor sv = new VarsVisitor();
		e.visit(sv);
		return sv.s;
	}
	
	public static final Set variables(Expr e, Boolean pure) {
		boolean getpure = pure == null || pure;
		boolean getlin = pure == null || !pure;
		class VariableVisitor extends NodeVisitor {
			private Set s = new HashSet();
			private boolean pure,lin;
			
			public VariableVisitor(boolean pure, boolean lin) {
				this.pure = pure;
				this.lin = lin;
			}
			
			public Node leave(Node parent, Node old, Node n, NodeVisitor v) {
				if (parent instanceof NamedVariable 
						|| parent instanceof Special)	
					return n;
				else if (n instanceof NamedVariable) {
					NamedVariable nv = (NamedVariable)n;
					if (pure && DualLogic.isPure(nv.type()))
						s.add(nv.toString());
					else if (lin && !DualLogic.isPure(nv.type()))
						s.add(nv.toString());
						
					/*if (n instanceof Local) {
						Local l = (Local) n;
						if (pure && DualLogic.isPure(l.type()))
							s.add(l.toString());
						else if (lin && !DualLogic.isPure(l.type()))
							s.add(l.toString());
						//s.add(l.toString());
					} else if (n instanceof Field) {
						Field f = (Field) n;
						if (pure && DualLogic.isPure(f.type()))
							s.add(f.toString());
						else if (lin && !DualLogic.isPure(f.type()))
							s.add(f.toString());
						//s.add(f.toString());
					}*/
					
				} else if (n instanceof Special) {
					Special ss = (Special)n;
					if (pure && DualLogic.isPure(ss.type()))
						s.add(n.toString());
					else if (lin && !DualLogic.isPure(ss.type()))
						s.add(n.toString());
				}
				return n;
			}
			
			public Set getVariables() {
				return s;
			}
		}
		
		VariableVisitor sv = new VariableVisitor(getpure, getlin);
		e.visit(sv);
		return sv.getVariables();
	}
	
	public static final Set symbols(Expr e) {
		class SymbolVisitor extends NodeVisitor {
			Set s = new HashSet();
			
			public Node leave(Node parent, Node old, Node n, NodeVisitor v) {
				if (parent instanceof NamedVariable 
						|| parent instanceof Special)
					return n;
				else if (n instanceof NamedVariable) {
					if (n instanceof Local) {
						Local l = (Local) n;
						s.add(l.toString());
					} else if (n instanceof Field) {
						Field f = (Field) n;
						//Expr e = getUltimateTarget(f);
						// XXX check
						//System.err.println("ULTIMATE " + f + " IS " + e);
						//s.add(e.toString());
						s.add(f.toString());
					}
				} else if (n instanceof Special)
					s.add(n.toString());
				return n;
			}
		}
		
		SymbolVisitor sv = new SymbolVisitor();
		e.visit(sv);
		return sv.s;
	}
	
	private static Expr getUltimateTarget(Field f) {
		Expr curr = f;
		Receiver r = f.target();
		while (r != null) {
			if (r instanceof Field) {
				Field fr = (Field) r;
				curr = fr;
				r = fr.target();
			} else if (r instanceof Local) {
				curr = (Local) r;
				r = null;
			} else if (r instanceof Special) {
				curr = (Special) r;
				r = null;
			}
		}
		return curr;
	}
	
	public static Term exprToTerm(Expr expr) throws SemanticException {
		if (expr instanceof Binary) {
			Binary b = (Binary) expr;
			// must be a function
			// left and right must be terms
			Term lt = exprToTerm(b.left());
			Term rt = exprToTerm(b.right());
			Binary.Operator op = b.operator();
			if (op == Binary.ADD)
				return new Plus(lt, rt);
			else if (op == Binary.SUB)
				return new Minus(lt, rt);
			else if (op == Binary.MUL)
				return new Mul(lt, rt);
			else if (op == Binary.MOD)
				return new Mod(lt, rt);
			else if (op == Binary.DIV)
				return new Div(lt, rt, !(b.left().type().isLongOrLess()
										&& b.right().type().isLongOrLess()));
			else throw new SemanticException("Binary operator not supported: " + op, b.position());
		} else if (expr instanceof Unary) {
			Unary u = (Unary) expr;
			Term ut = exprToTerm(u.expr());
			Unary.Operator op = u.operator();
			if (op == Unary.POS)
				return new Plus(ut);
			else if (op == Unary.NEG)
				return new Minus(ut);
			else throw new SemanticException("Unary operator not supported: " + op, u.position());
		} else if (expr instanceof Lit) {
			Lit l = (Lit)expr;
			return new Constant(l);
		} else if (expr instanceof NamedVariable) {
			NamedVariable nv = (NamedVariable)expr;
			return new VariableTerm(nv);
		} else if (expr instanceof Special) {
			Special s = (Special)expr;
			return new VariableTerm(s);
		} else return new VariableTerm(expr);
	}
	
	private static Formula translateToFormula(Unary u) throws SemanticException {
		// assume unary type boolean
		Unary.Operator op = u.operator();
		Expr ue = u.expr();
		if (op == Unary.NOT)
			return new Not(boolExprToFormula(ue));
		else throw new SemanticException("Unary operator not supported: " + op, u.position());
	}
	
	private static Formula translateToFormula(Binary b) throws SemanticException {
		// assume binary type boolean
		Binary.Operator op = b.operator();
		Expr le = b.left();
		Expr re = b.right();
		if (op == Binary.NE
				|| op == Binary.EQ) {
			if (b.left().type().isBoolean()
					&& b.right().type().isBoolean()) {
				Formula lf = boolExprToFormula(le);
				Formula rf = boolExprToFormula(re);
				if (op == Binary.NE)
					return new Not(new Equivalence(lf, rf));
				else return new Equivalence(lf, rf);
			} else {
				// check if left or right is NullLit
				if (le instanceof NullLit) {
					StatePredicate sp = new StatePredicate("null", exprToTerm(re));
					if (op == Binary.EQ)
						return sp;
					else return new Not(sp);
				} else if (re instanceof NullLit) {
					StatePredicate sp = new StatePredicate("null", exprToTerm(le));
					if (op == Binary.EQ)
						return sp;
					else return new Not(sp);
				}					
				// Predicate - left and right are terms
				Term lt = exprToTerm(le);
				Term rt = exprToTerm(re);
				if (op == Binary.EQ)
					return new Eq(lt, rt);
				else return new Not(new Eq(lt, rt));
			}
		} else if (op == Binary.GT ||
				op == Binary.LT ||
				op == Binary.GE ||
				op == Binary.LE) {
			// Predicate - left and right are terms
			Term lt = exprToTerm(le);
			Term rt = exprToTerm(re);
			if (op == Binary.GT)
				return new Gt(lt, rt);
			else if (op == Binary.LT)
				return new Lt(lt, rt);
			else if (op == Binary.GE)
				return new And(new Gt(lt, rt), new Eq(lt, rt));
			else return new And(new Lt(lt, rt), new Eq(lt, rt));
		} else if (op == Binary.COND_AND ||
				op == Binary.BIT_AND ||
				op == Binary.COND_OR ||
				op == Binary.BIT_OR ||
				op == Binary.BIT_XOR) {
			Formula lf = boolExprToFormula(le);
			Formula rf = boolExprToFormula(re);
			if (op == Binary.COND_AND ||
					op == Binary.BIT_AND)
				return new And(lf, rf);
			else if (op == Binary.COND_OR ||
					op == Binary.BIT_OR)
				return new Or(lf, rf);
			else // if (op == Binary.BIT_XOR)
				// a xor b = (a or b) and !(a and b)
				return new And(new Or(lf, rf), new Not(new And(lf, rf)));
		} else throw new SemanticException("Binary operator not supported: " + op, b.position());
	}
	
	public static final Formula boolExprToFormula(Expr expr) throws SemanticException {
		if (!expr.type().isBoolean())
			throw new SemanticException("Expression type must be boolean " +
					"instead of " + expr.type(), expr.position());
		if (expr instanceof Binary) {
			Binary b = (Binary) expr;
			return translateToFormula(b);
		} else if (expr instanceof Unary) {
			Unary u = (Unary) expr;
			return translateToFormula(u);
		} else if (expr instanceof NamedVariable) {
			NamedVariable v = (NamedVariable) expr;
			return new StatePredicate("true", new VariableTerm(v));
		} else if (expr instanceof BooleanLit) {
			BooleanLit l = (BooleanLit) expr;
			return new StatePredicate("true", new Constant(l));
		} else throw new SemanticException("Expression not supported", expr.position());
	}
}
