package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;

public interface Function extends Term {
	public Term getTerm(int n) throws IndexOutOfBoundsException;
	public int arity();
}


