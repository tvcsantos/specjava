package specjava.logic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import polyglot.ast.Expr;
import polyglot.ast.NamedVariable;
import polyglot.ast.Node;
import polyglot.ast.Special;
import polyglot.ast.Variable;
import polyglot.types.Type;
import polyglot.util.Pair;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode.Kind;
import specjava.logic.formula.Dual;
import specjava.logic.formula.False;
import specjava.logic.formula.Formula;
import specjava.logic.formula.True;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.predicate.Eq;
import specjava.logic.formula.predicate.Gt;
import specjava.logic.formula.predicate.Lt;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.SpecialTerm;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.formula.term.function.Constant;
import specjava.logic.formula.term.function.Div;
import specjava.logic.formula.term.function.Minus;
import specjava.logic.formula.term.function.Mod;
import specjava.logic.formula.term.function.Mul;
import specjava.logic.formula.term.function.Plus;
import specjava.logic.formula.unary.Not;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.Simplifier;
import specjava.logic.visit.Substitutor;
import specjava.logic.visit.VisitorException;
import specjava.types.Property;
import specjava.types.SpecJavaPrimitiveType;
import specjava.types.SpecJavaReferenceType;
import cvc3.Op;
import cvc3.QueryResult;
import cvc3.SatResult;
import cvc3.ValidityChecker;

public class CVCProver implements Prover {

	private List l;
	
	private final AVisitor av = new AVisitor();
	
	private ValidityChecker vc;
	private Op pos, neg, zero;
	private cvc3.Type object, integer, real, bool;
	private int count = 0;
	
	public CVCProver(List l) throws ProverException {
		init(l);
	}
	
	private void init(List l) throws ProverException {
		this.l = l;
		initChecker();
	}
	
	private final void initChecker() throws ProverException {
		if (vc != null) vc.delete();
		vc = null;
		try {
			cvc3.FlagsMut flags = ValidityChecker.createFlags(null);
		    //flags.setFlag("dagify-exprs",false);
		    flags.setFlag("dump-log", "test" + count++ + ".cvc");
			vc = ValidityChecker.create(flags);
			object = vc.createType("Object");
			real = vc.realType();
			integer = vc.intType();
			bool = vc.boolType();
			cvc3.Expr x = vc.boundVarExpr("x", "0", real);
			List lx = new LinkedList();
			lx.add(x);
			Op gtz = vc.lambdaExpr(lx, vc.gtExpr(x, vc.ratExpr(0)));
			Op ltz = vc.lambdaExpr(lx, vc.ltExpr(x, vc.ratExpr(0)));
			Op eqz = vc.lambdaExpr(lx, vc.eqExpr(x, vc.ratExpr(0)));
			lx = new LinkedList();
			lx.add(vc.realType());
			pos = vc.createOp("pos", vc.funType(lx, bool), gtz.getExpr());
			neg = vc.createOp("neg", vc.funType(lx, bool), ltz.getExpr());
			zero = vc.createOp("zero", vc.funType(lx, bool), eqz.getExpr());
		} catch (Exception e) {
			ProverException p = new ProverException();
			p.initCause(e);
			if (vc != null) vc.delete();
			throw p;
		}
	}
	
	private final void destroyChecker() {
		if (vc != null) vc.delete();
	}
	
	public Result prove(boolean valid) throws ProverException {
		//////////////// VALID ////////////////
		// let d be a dual in the list
		// valid(d) iff unsat(not d)
		//////////////// VALID ////////////////
		// let n be the size of the list and
		// Result is unknown iff #unknown > 0
		// Result is valid iff all #valid = n
		// Result is sat iff #sat > 0 and #valid + #sat = n
		// Result is unsat iff #unsat > 0 and #unsat + #valid + #sat = n
		int res = UNKNOWN;
		Position rpos = null;
		int satc = 0;
		int unsatc = 0;
		int validc = 0;
		int n = l.size();
		for (Iterator it = l.iterator(); it.hasNext(); ) {
			initChecker();
			//vc.push();
			Pair p = (Pair) it.next();
			Dual d = (Dual)p.part1();
			Position pos = (Position)p.part2();
			int pr = prove(valid, d);
			if (pr == UNKNOWN) return new Result(res, pos);
			if (pr == SAT) satc++;
			if (pr == UNSAT) { 
				if (unsatc == 0) rpos = pos;
				unsatc++;
			}
			if (pr == VALID) validc++;
			//vc.pop();
			String pres = "";
			switch(pr) {
			case VALID: pres = "VALID"; break;
			case SAT: pres = "SAT"; break;
			case UNSAT: pres = "UNSAT"; break;
			case UNKNOWN: pres = "UNKNOWN"; break;
			}
			System.out.println("Proof result: " + pres);
			//if (pr == SAT) { res = SAT; break; }
			//if (pr == SAT) throw new ProverException("Invalid Sentence - " + d, pos);
			//else if (pr == UNKNOWN) throw new ProverException("Unknow Result - " + d, pos);
			//else if (pr == UNKNOWN) { res = UNKNOWN; break; }
		}	
		if (validc == n) res = VALID;
		else if (satc > 0 && validc + satc == n) res = SAT;
		else res = UNSAT;
		destroyChecker();
		return new Result(res, rpos);
	}
	
	private int prove(boolean valid, Dual s) throws ProverException {
		try {
			System.out.println("Proving sentence: " + s);
			CVCVisitor cvc = new CVCVisitor(vc);
			Simplifier simp = new Simplifier();
			cvc3.Expr ss = (cvc3.Expr) ((Formula) new And(s.classicFormula(), DualLogic.anded(s.sepLogicFormulas())).accept(simp)).accept(cvc);
			if (valid) {
				cvc3.QueryResult qr = vc.query(ss);
				if (qr == QueryResult.VALID)
					return VALID;
				else if (qr == QueryResult.INVALID) {
					System.out.println(vc.getCounterExample());
					System.out.flush();
					cvc3.SatResult sr = vc.checkUnsat(ss);
					if (sr == SatResult.SATISFIABLE)
						return SAT;
					else if (sr == SatResult.UNSATISFIABLE)
						return UNSAT;
					else return UNKNOWN;
				}
			} else {
				cvc3.SatResult sr = vc.checkUnsat(ss);
				if (sr == SatResult.SATISFIABLE)
					return SAT;
				else if (sr == SatResult.UNSATISFIABLE)
					return UNSAT;
			}
			return UNKNOWN;
		} catch (VisitorException e) {
			ProverException ex = new ProverException();
			ex.initCause(e);
			throw ex;
		}
	}
	
	private class CVCVisitor implements PLVisitor {
		
		protected final Map vars = new HashMap();
		
		/////// CVC3 ////////
		protected final Map ops = new HashMap();
		protected final Map vs = new HashMap();
		
		protected ValidityChecker vc;
		
		public CVCVisitor(ValidityChecker vc) {
			this.vc = vc;
			ops.put("pos", pos);
			ops.put("neg", neg);
			ops.put("zero", zero);
		}

		private final void declare(Set s) throws VisitorException {
			Iterator it = s.iterator();
			List l1 = new LinkedList();
			l1.add(object);
			while (it.hasNext()) {
				String x = (String) it.next();
				polyglot.types.Type t = (polyglot.types.Type) vars.get(x);
				if (t.isReference()) {
					vs.put(x, vc.varExpr(escape(x), object));
				} else if (t.isLongOrLess()) {
					vs.put(x, vc.varExpr(escape(x), integer));
				} else if (t.isNumeric()) {
					vs.put(x, vc.varExpr(escape(x), real));
				} else if (t.isBoolean()) {
					vs.put(x, vc.varExpr(escape(x), bool));
				}
				
				if (t.isReference()) {
					SpecJavaReferenceType sjct = (SpecJavaReferenceType)t;
					List l = sjct.properties();
					for (Iterator i = l.iterator(); i.hasNext() ; ) {
						Property p = (Property) i.next();
						if (!ops.containsKey(escape(p.toString()))) {
							Op op = vc.createOp(escape(p.toString()), 
									vc.funType(l1, bool));
							ops.put(escape(p.toString()), op);
						}
					}
				}
			}
		}
		
		private final Set difference(Set s1, Set s2) {
			Set res = new HashSet();
			for (Iterator it = s1.iterator(); it.hasNext() ; ) {
				Object o = it.next();
				if (!s2.contains(o))
					res.add(o);
			}
			return res;
		}
		
		public Object visit(True ts) throws VisitorException {
			return vc.trueExpr();
		}

		public Object visit(False fs) throws VisitorException {
			return vc.falseExpr();
		}

		public Object visit(Not fs) throws VisitorException {
			cvc3.Expr neg = (cvc3.Expr) fs.getNegated().accept(this);
			return vc.notExpr(neg);
		}

		public Object visit(Equivalence fs) throws VisitorException {
			cvc3.Expr le = (cvc3.Expr) fs.getLeft().accept(this);
			cvc3.Expr re = (cvc3.Expr) fs.getRight().accept(this);
			return vc.iffExpr(le, re);
		}

		public Object visit(Implication fs) throws VisitorException {
			cvc3.Expr le = (cvc3.Expr) fs.getLeft().accept(this);
			cvc3.Expr re = (cvc3.Expr) fs.getRight().accept(this);
			return vc.impliesExpr(le, re);
		}

		public Object visit(And fs) throws VisitorException {
			cvc3.Expr le = (cvc3.Expr) fs.getLeft().accept(this);
			cvc3.Expr re = (cvc3.Expr) fs.getRight().accept(this);
			return vc.andExpr(le, re);
		}

		public Object visit(Or fs) throws VisitorException {
			cvc3.Expr le = (cvc3.Expr) fs.getLeft().accept(this);
			cvc3.Expr re = (cvc3.Expr) fs.getRight().accept(this);
			return vc.orExpr(le, re);
		}

		public Object visit(Eq eq) throws VisitorException {
			cvc3.Expr fst = (cvc3.Expr) eq.getTerm(0).accept(this);
			cvc3.Expr snd = (cvc3.Expr) eq.getTerm(1).accept(this);			
			return vc.eqExpr(fst, snd);
		}

		public Object visit(Gt gt) throws VisitorException {
			cvc3.Expr fst = (cvc3.Expr) gt.getTerm(0).accept(this);
			cvc3.Expr snd = (cvc3.Expr) gt.getTerm(1).accept(this);			
			return vc.gtExpr(fst, snd);
		}

		public Object visit(Lt lt) throws VisitorException {
			cvc3.Expr fst = (cvc3.Expr) lt.getTerm(0).accept(this);
			cvc3.Expr snd = (cvc3.Expr) lt.getTerm(1).accept(this);			
			return vc.ltExpr(fst, snd);
		}

		public Object visit(StatePredicate sp) throws VisitorException {
			Term ter = sp.getTerm(0);
			
			cvc3.Expr ine = (cvc3.Expr) ter.accept(this);
			cvc3.Expr expr = null;
			if (sp.getProperty().compareTo("true") == 0) {
				expr = ine;
			} else if (sp.getProperty().compareTo("false") == 0) {
				expr = vc.notExpr(ine);
			}
			else expr = vc.funExpr((cvc3.Op)ops.get(escape(sp.getProperty())), ine);
			
			List l1 = new LinkedList();
			l1.add(object);
			
			if (ter instanceof VariableTerm) {
				VariableTerm expterm = (VariableTerm) ter;
				Expr xe = expterm.getExpr();
				polyglot.types.Type t = xe.type();
				if (t.isReference()) {
					SpecJavaReferenceType sjct = (SpecJavaReferenceType)t;
					Set defs = sjct.definitions();
					for (Iterator i = defs.iterator(); i.hasNext();) {
						Entry en = (Entry) i.next();
						Property p = (Property) en.getKey();
						if (!ops.containsKey(escape(p.toString()))) {
							Op op = vc.createOp(escape(p.toString()), 
										vc.funType(l1, bool));
							ops.put(escape(p.toString()), op);
						}
						
						Dual d = (Dual) en.getValue();
						
						if (d == null) continue;
						
						Formula cf = d.classicFormula();
						List sl = d.sepLogicFormulas();
						Substitutor sub = new Substitutor("this", ter);
						cf = (Formula) cf.accept(sub);
						sl = Utils.visitList(sl, sub);
						Simplifier simp = new Simplifier();
						cvc3.Expr ss = (cvc3.Expr) ((Formula) new And(cf, DualLogic.anded(sl)).accept(simp)).accept(this);
						cvc3.Expr left = vc.funExpr((cvc3.Op)ops.get(escape(p.toString())), ine);
						vc.assertFormula(vc.iffExpr(left, ss));
					}
				}
			
			} else if (ter instanceof SpecialTerm) {
				SpecialTerm speterm = (SpecialTerm) ter;
				Type type = speterm.getType();
				if (type instanceof SpecJavaReferenceType) {
					SpecJavaReferenceType sjct = (SpecJavaReferenceType) type;
					if (speterm.getKind() == SpecialPropertyNode.RETURN) {
						Set defs = sjct.definitions();
						for (Iterator i = defs.iterator(); i.hasNext();) {
							Entry en = (Entry) i.next();
							Property p = (Property) en.getKey();
							if (!ops.containsKey(escape(p.toString()))) {
								Op op = vc.createOp(escape(p.toString()), 
											vc.funType(l1, bool));
								ops.put(escape(p.toString()), op);
							}
							
							Dual d = (Dual) en.getValue();
							
							if (d == null) continue;
							
							Formula cf = d.classicFormula();
							List sl = d.sepLogicFormulas();
							Substitutor sub = new Substitutor("return", ter);
							cf = (Formula) cf.accept(sub);
							sl = Utils.visitList(sl, sub);
							Simplifier simp = new Simplifier();
							cvc3.Expr ss = (cvc3.Expr) ((Formula) new And(cf, DualLogic.anded(sl)).accept(simp)).accept(this);
							cvc3.Expr left = vc.funExpr((cvc3.Op)ops.get(escape(sp.getProperty())), ine);
							vc.assertFormula(vc.iffExpr(left, ss));
						}
					} else {
						Set defs = sjct.definitions();
						for (Iterator i = defs.iterator(); i.hasNext();) {
							Entry en = (Entry) i.next();
							Property p = (Property) en.getKey();
							if (!ops.containsKey(escape(p.toString()))) {
								Op op = vc.createOp(escape(p.toString()), 
											vc.funType(l1, bool));
								ops.put(escape(p.toString()), op);
							}
							
							Dual d = (Dual) en.getValue();
							
							if (d == null) continue;
							
							Formula cf = d.classicFormula();
							List sl = d.sepLogicFormulas();
							Simplifier simp = new Simplifier();
							cvc3.Expr ss = (cvc3.Expr) ((Formula) new And(cf, DualLogic.anded(sl)).accept(simp)).accept(this);
							cvc3.Expr left = vc.funExpr((cvc3.Op)ops.get(escape(sp.getProperty())), ine);
							vc.assertFormula(vc.iffExpr(left, ss));
						}
					}
				} else if (type instanceof SpecJavaPrimitiveType) {
					return expr;
				}				
			}
					
			return expr;
		}

		public Object visit(Div div) throws VisitorException {
			if (!div.isReal())
				throw new VisitorException("Integer division not supported by CVC3 prover");
			
			cvc3.Expr fst = (cvc3.Expr) div.getTerm(0).accept(this);
			cvc3.Expr snd = (cvc3.Expr) div.getTerm(1).accept(this);
			
			return vc.divideExpr(fst, snd);
		}

		public Object visit(Minus minus) throws VisitorException {
			if (minus.arity() == 1) {
				cvc3.Expr fst = (cvc3.Expr) minus.getTerm(0).accept(this);
				return vc.uminusExpr(fst);
			} else {
				cvc3.Expr fst = (cvc3.Expr) minus.getTerm(0).accept(this);
				cvc3.Expr snd = (cvc3.Expr) minus.getTerm(1).accept(this);
				return vc.minusExpr(fst, snd);
			}
		}

		public Object visit(Mul mul) throws VisitorException {
			cvc3.Expr fst = (cvc3.Expr) mul.getTerm(0).accept(this);
			cvc3.Expr snd = (cvc3.Expr) mul.getTerm(1).accept(this);
			return vc.multExpr(fst, snd);
		}

		public Object visit(Plus plus) throws VisitorException {
			List kids = new LinkedList();
			cvc3.Expr fst = (cvc3.Expr) plus.getTerm(0).accept(this);
			kids.add(fst);
			if (plus.arity() > 1) {
				cvc3.Expr snd = (cvc3.Expr) plus.getTerm(1).accept(this);
				kids.add(snd);
			}
			return vc.plusExpr(kids);
		}

		public Object visit(SpecialTerm st) throws VisitorException {
			polyglot.types.Type t = null;
			Map m = new HashMap();
			t = st.getType();
			Kind k = st.getKind();
			m.put(k.toString(), t);		
			Set s = difference(m.keySet(), vars.keySet()); // not yet declared
			vars.putAll(m);
			declare(s);
			
			return vc.exprFromString(st.getKind().toString());
		}

		public Object visit(Mod mod) throws VisitorException {
			throw new VisitorException("Modulus operation not supported by CVC3 prover");
		}

		public Object visit(VariableTerm v)
				throws VisitorException {
			Map m = new HashMap();
			Expr xe = v.getExpr();
			xe.visit(av);
			m.putAll(av.getVars());
			av.clear();
			Set s = difference(m.keySet(), vars.keySet()); // not yet declared
			vars.putAll(m);
			declare(s);
			
			return vc.exprFromString(escape(v.getExpr().toString()));
		}

		public Object visit(Constant c) throws VisitorException {
			return vc.exprFromString(c.toString());
		}
		
	}
	
	private class AVisitor extends NodeVisitor {
		
		protected final Map vars = new HashMap();
		
		public Node leave(Node old, Node n, NodeVisitor v) {
			if (n instanceof NamedVariable) {
				NamedVariable va = (NamedVariable)n;
				vars.put(va.toString(), va.type());
			} else if (n instanceof Special) {
				Special s = (Special)n;
				if (s.kind() == Special.THIS)
					vars.put(s.toString(), s.type());
			} else if (n instanceof Variable) { // array access
				System.out.println("#####" + n);
			}
			
			return n;
		}
		
		public void clear() {
			vars.clear();
		}
		
		public Map getVars() {
			return vars;
		}
		
		
	}
	
	private static String escape(String s) {
		String escaped = s.replace("$", "$$").replace('.', '$');
		esc.put(escaped, s);
		return escaped;
	}
	
	private static String undoescape(String escaped) {
		return (String) esc.get(escaped);
	}
	
	private static final Map esc = new HashMap();
	
	public static void main(String[] args) {
		System.out.println(undoescape(escape("a$$$$b.$C.open")));
	}

}
