package specjava.logic;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import polyglot.types.Type;

import specjava.ast.specification.formula.FormulaNode;
import specjava.logic.formula.Dual;
import specjava.logic.formula.DualImpl;
import specjava.logic.formula.Formula;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.types.SpecJavaClassType;
import specjava.util.CollectionUtil;

public class DualLogic {
	private DualLogic() {}
	
	public static final List makeSep(Formula cf) {
		List res = new LinkedList();
		res.add(cf);
		return res;
	}
	
	private static final Set variables(List l, Boolean pure) {
		Set res = new HashSet();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb;
			if (pure == null) smb = form.symbols();
			else if (pure) smb = form.pureSymbols();
			else smb = form.linearSymbols();
			res.addAll(smb);
		}
		return res;
	}
	
	public static final Dual and(Dual d1, Dual d2) {
		Formula d1cf = d1.classicFormula();
		List d1sf = d1.sepLogicFormulas();
		Formula d2cf = d2.classicFormula();
		List d2sf = d2.sepLogicFormulas();
		Dual res = new DualImpl(new And(d1cf, d2cf), and(d1sf, d2sf));
		return res;
	}
	
	public static final List and(List s1, List s2) {
		Set vl1 = variables(s1, false);
		Set vl2 = variables(s2, false);
		List res = new LinkedList();
		Set diff12 = CollectionUtil.difference(vl1, vl2);
		List nl1 = new LinkedList();
		
		// step 1 - remove all s's from l1 that
		// are not in l2 and add them to result
		for (Iterator it = s1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff12).isEmpty())
				nl1.add(form);
			else res.add(form);
		}
		
		// step 2 - remove all s's from l2 that
		// are not in l1 and add them to result
		Set diff21 = CollectionUtil.difference(vl2, vl1);
		List nl2 = new LinkedList();
		for (Iterator it = s2.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff21).isEmpty())
				nl2.add(form);
			else res.add(form);
		}
		
		// step 3 - merge what has left
		// and add to result
		List mergeres = new LinkedList();
		List next = nl2;
		for (Iterator it = nl1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set symb = form.linearSymbols();
			List aux = new LinkedList();
			for (Iterator it2 = next.iterator(); it2.hasNext();) {
				Formula form2 = (Formula) it2.next();
				Set symb2 = form2.linearSymbols();
				if (!Collections.disjoint(symb, symb2)) {
					mergeres.add(new And(form, form2));
				} else aux.add(form2);			
			}
			next = aux;
		}
		res.addAll(mergeres);
		
		return res;
	}
	
	public static final Dual or(Dual d1, Dual d2) {
		Formula d1cf = d1.classicFormula();
		List d1sf = d1.sepLogicFormulas();
		Formula d2cf = d2.classicFormula();
		List d2sf = d2.sepLogicFormulas();
		Dual res = new DualImpl(new Or(d1cf, d2cf), or(d1sf, d2sf));
		return res;
	}
	
	public static final List or(List s1, List s2) {
		Set vl1 = variables(s1, false);
		Set vl2 = variables(s2, false);
		List res = new LinkedList();
		Set diff12 = CollectionUtil.difference(vl1, vl2);
		List nl1 = new LinkedList();
		
		// step 1 - remove all s's from l1 that
		// are not in l2 and do not add them to result
		// because form or true = true
		for (Iterator it = s1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff12).isEmpty())
				nl1.add(form);
		}
		
		// step 2 - remove all s's from l2 that
		// are not in l1 and do not add them to result
		// because true or form = true
		Set diff21 = CollectionUtil.difference(vl2, vl1);
		List nl2 = new LinkedList();
		for (Iterator it = s2.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff21).isEmpty())
				nl2.add(form);
		}
		
		// step 3 - merge what has left
		// and add to result
		List mergeres = new LinkedList();
		List next = nl2;
		for (Iterator it = nl1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set symb = form.linearSymbols();
			List aux = new LinkedList();
			for (Iterator it2 = next.iterator(); it2.hasNext();) {
				Formula form2 = (Formula) it2.next();
				Set symb2 = form2.linearSymbols();
				if (!Collections.disjoint(symb, symb2)) {
					mergeres.add(new Or(form, form2));
				} else aux.add(form2);			
			}
			next = aux;
		}
		res.addAll(mergeres);
		
		return res;
	}
	
	public static final Dual imply(Dual d1, Dual d2) {
		Formula d1cf = d1.classicFormula();
		List d1sf = d1.sepLogicFormulas();
		Formula d2cf = d2.classicFormula();
		List d2sf = d2.sepLogicFormulas();
		Dual res = new DualImpl(new Implication(d1cf, d2cf), imply(d1sf, d2sf));
		return res;
	}
	
	public static final List imply(List s1, List s2) {
		Set vl1 = variables(s1, false);
		Set vl2 = variables(s2, false);
		List res = new LinkedList();
		Set diff12 = CollectionUtil.difference(vl1, vl2);
		List nl1 = new LinkedList();
		
		// step 1 - remove all s's from l1 that
		// are not in l2 and do not add them to result
		// because form => true = true
		for (Iterator it = s1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff12).isEmpty())
				nl1.add(form);
		}
		
		// step 2 - remove all s's from l2 that
		// are not in l1 and add them to result
		// because true => form = form
		Set diff21 = CollectionUtil.difference(vl2, vl1);
		List nl2 = new LinkedList();
		for (Iterator it = s2.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff21).isEmpty())
				nl2.add(form);
			else res.add(form);
		}
		
		// step 3 - merge what has left
		// and add to result
		List mergeres = new LinkedList();
		List next = nl2;
		for (Iterator it = nl1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set symb = form.linearSymbols();
			List aux = new LinkedList();
			for (Iterator it2 = next.iterator(); it2.hasNext();) {
				Formula form2 = (Formula) it2.next();
				Set symb2 = form2.linearSymbols();
				if (!Collections.disjoint(symb, symb2)) {
					mergeres.add(new Implication(form, form2));
				} else aux.add(form2);			
			}
			next = aux;
		}
		res.addAll(mergeres);
		
		return res;
	}	
	
	public static final Dual equivalent(Dual d1, Dual d2) {
		Formula d1cf = d1.classicFormula();
		List d1sf = d1.sepLogicFormulas();
		Formula d2cf = d2.classicFormula();
		List d2sf = d2.sepLogicFormulas();
		Dual res = new DualImpl(new Equivalence(d1cf, d2cf), equivalent(d1sf, d2sf));
		return res;
	}
	
	public static final List equivalent(List s1, List s2) {
		Set vl1 = variables(s1, false);
		Set vl2 = variables(s2, false);
		List res = new LinkedList();
		Set diff12 = CollectionUtil.difference(vl1, vl2);
		List nl1 = new LinkedList();
		
		// step 1 - remove all s's from l1 that
		// are not in l2 and add them to result
		// because form <=> true = form
		for (Iterator it = s1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff12).isEmpty())
				nl1.add(form);
			else res.add(form);
		}
		
		// step 2 - remove all s's from l2 that
		// are not in l1 and add them to result
		// because true <=> form = form
		Set diff21 = CollectionUtil.difference(vl2, vl1);
		List nl2 = new LinkedList();
		for (Iterator it = s2.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set smb = form.linearSymbols();
			if (!CollectionUtil.difference(smb, diff21).isEmpty())
				nl2.add(form);
			else res.add(form);
		}
		
		// step 3 - merge what has left
		// and add to result
		List mergeres = new LinkedList();
		List next = nl2;
		for (Iterator it = nl1.iterator(); it.hasNext();) {
			Formula form = (Formula) it.next();
			Set symb = form.linearSymbols();
			List aux = new LinkedList();
			for (Iterator it2 = next.iterator(); it2.hasNext();) {
				Formula form2 = (Formula) it2.next();
				Set symb2 = form2.linearSymbols();
				if (!Collections.disjoint(symb, symb2)) {
					mergeres.add(new Equivalence(form, form2));
				} else aux.add(form2);			
			}
			next = aux;
		}
		res.addAll(mergeres);
		
		return res;
	}	
	
	public static final Dual and(Formula cf, Dual df) {
		Formula dcf = df.classicFormula();
		List dsf = df.sepLogicFormulas();
		List rsf = new LinkedList();
		for (Iterator it = dsf.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			rsf.add(new And(cf, f));
		}
		return new DualImpl(new And(cf, dcf), rsf);
	}
	
	public static final Dual or(Formula cf, Dual df) {
		Formula dcf = df.classicFormula();
		List dsf = df.sepLogicFormulas();
		List rsf = new LinkedList();
		for (Iterator it = dsf.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			rsf.add(new Or(cf, f));
		}
		return new DualImpl(new Or(cf, dcf), rsf);
	}
	
	public static final Dual imply(Formula cf, Dual df) {
		Formula dcf = df.classicFormula();
		List dsf = df.sepLogicFormulas();
		List rsf = new LinkedList();
		for (Iterator it = dsf.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			rsf.add(new Implication(cf, f));
		}
		return new DualImpl(new Implication(cf, dcf), rsf);
	}
	
	public static final Dual equivalent(Formula cf, Dual df) {
		Formula dcf = df.classicFormula();
		List dsf = df.sepLogicFormulas();
		List rsf = new LinkedList();
		for (Iterator it = dsf.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			rsf.add(new Equivalence(cf, f));
		}
		return new DualImpl(new Equivalence(cf, dcf), rsf);
	}

	public static final List restrict(List l, Set/*[String]*/ s) {
		//XXX System.err.println("RESTRICTING TO: " + s);
		List res = new LinkedList();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			Set fs = f.targets();
			if (!Collections.disjoint(fs, s))
				res.add(f);
		}
		return res;
	}

	public static final List exclude(List l, Set/*[String]*/ s) {
		//XXX System.err.println("EXCLUDING: " + s);
		List res = new LinkedList();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Formula f = (Formula) it.next();
			Set fs = f.targets();
			if (Collections.disjoint(fs, s))
				res.add(f);
		}
		return res;
	}

	public static final List getFormulas(List l) {
		List res = new LinkedList();
		for (Iterator it = l.iterator(); it.hasNext() ; )
			res.add(((FormulaNode)it.next()).formula());
		return res;
	}

	public static boolean isPure(Type t) {
		if (t.isPrimitive()) return true;
		else if (t.isClass()) {
			SpecJavaClassType sjct = 
				(SpecJavaClassType) t.toClass();
			return sjct.isPure();
		}
		else return false;
	}

	public static final Formula anded(List l) {
		if (l.isEmpty()) return Formula.TRUE;
		else {
			Formula res = null;
			for (Iterator it = l.iterator() ; it.hasNext() ; )
				if (res == null) res = (Formula)it.next();
				else res = new And(res, (Formula)it.next());
			return res;
		}
	}
	
}
