package specjava;

import java.util.Set;

import polyglot.types.Context;

/** A unique identifier generator. */
public class UniqueID {
    private static int count = 0;

	public static String newID(String s, Context c) {
		String uid = s + "$" + count;
		count++;
		if (c.findVariableSilent(uid) != null)
			return newID(s, c);
		return uid;
	}
	
	public static String newID(String s, Set set) {
		String uid = s + "$" + count;
		count++;
		if (set.contains(uid))
			return newID(s, set);
		return uid;
	}
}
