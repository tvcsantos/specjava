package specjava.ast.factory;

import polyglot.ast.AbstractDelFactory_c;
import polyglot.ast.JL;
import specjava.ast.extension.SpecJavaSynchronizedDel_c;

/**
 * DelFactory for specjava extension.
 */
public class SpecJavaDelFactory_c extends AbstractDelFactory_c {

	protected JL delSynchronizedImpl() {
		return new SpecJavaSynchronizedDel_c();
	}
}
