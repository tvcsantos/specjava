package specjava.ast.factory;

import polyglot.ast.Ext;
import polyglot.ast.ExtFactory;

/**
 * ExtFactory for specjava extension.
 */
public interface SpecJavaExtFactory extends ExtFactory {
	
	Ext extStaticAssert();
	
	Ext extAssume();
}
