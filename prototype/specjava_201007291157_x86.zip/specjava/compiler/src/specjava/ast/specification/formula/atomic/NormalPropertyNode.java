package specjava.ast.specification.formula.atomic;

import polyglot.ast.Expr;

/**
 * A <code>NormalPropertyNode</code> represents
 * property nodes associated to normal names
 * of fields, variables, etc. 
 */
public interface NormalPropertyNode extends SinglePropertyNode {
	
	/** The expression witch the property is assigned to */
	Expr expr();
	
	/** Set the expression which the property is assigned to */
	NormalPropertyNode expr(Expr expr);
}
