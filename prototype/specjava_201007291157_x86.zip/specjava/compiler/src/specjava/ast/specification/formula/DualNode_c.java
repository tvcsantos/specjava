package specjava.ast.specification.formula;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ast.Node_c;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.util.CollectionUtil;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeChecker;
import specjava.ast.specification.formula.atomic.NormalPropertyNode;
import specjava.logic.DualLogic;

/**
 * Class implementing DualNode.
 */
public class DualNode_c extends Node_c implements DualNode {
	
	protected FormulaNode classicFormula;
	protected List sepLogicFormulas;
	
	public String toString() {
		String res = classicFormula.toString();
		Iterator it = sepLogicFormulas.iterator();
		if (it.hasNext()) res = res + " + " + it.next();
		while (it.hasNext()) res += " * " + it.next();
		return res;
	}
	
	public boolean isTypeChecked() {
		return classicFormula.isTypeChecked()
		&& listIsTypeChecked(sepLogicFormulas)
		&& super.isTypeChecked();
	}
	
	protected boolean listIsTypeChecked(List l) {
		for (Iterator it = l.iterator(); it.hasNext();) {
			FormulaNode fn = (FormulaNode) it.next();
			if (!fn.isTypeChecked()) return false;			
		}
		return true;
	}
	
	protected boolean listIsDisambiguated(List l) {
		for (Iterator it = l.iterator(); it.hasNext();) {
			FormulaNode fn = (FormulaNode) it.next();
			if (!fn.isDisambiguated()) return false;			
		}
		return true;
	}
	
	public DualNode_c(Position pos, FormulaNode classicFormula, List slFormulas) {
		super(pos);
		assert(classicFormula != null && slFormulas != null);
		this.classicFormula = classicFormula;
		this.sepLogicFormulas = TypedList.copyAndCheck(slFormulas, FormulaNode.class, true);
	}
	
	protected DualNode_c reconstruct(FormulaNode classicFormula, List slFormulas) {
		if (classicFormula != this.classicFormula || 
				!CollectionUtil.equals(slFormulas, this.sepLogicFormulas)) {
		    DualNode_c n = (DualNode_c) copy();
		    n.classicFormula = classicFormula;
		    n.sepLogicFormulas = TypedList.copyAndCheck(slFormulas, FormulaNode.class, true);
		    return n;
		}
		return this;
	}
	
	public Node visitChildren(NodeVisitor v) {
		FormulaNode classicFormula = (FormulaNode) visitChild(this.classicFormula, v);
		List slFormulas = visitList(this.sepLogicFormulas, v);
		return reconstruct(classicFormula, slFormulas);
	}
	
	public FormulaNode classicFormula() {
		return classicFormula;
	}

	public List sepLogicFormulas() {
		return Collections.unmodifiableList(this.sepLogicFormulas);
	}

	public DualNode classicFormula(FormulaNode pn) {
		DualNode_c n = (DualNode_c) copy();
		n.classicFormula = pn;
		return n;
	}

	public DualNode sepLogicFormulas(List slf) {
		DualNode_c n = (DualNode_c) copy();
		n.sepLogicFormulas = TypedList.copyAndCheck(slf, FormulaNode.class, true);
		return n;
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		DualNode_c n = (DualNode_c) super.typeCheck(tc);
		if (!classicFormula.isTypeChecked())
			return n;
		else if (!listIsTypeChecked(sepLogicFormulas)) return n;
		
		class PureVisitor extends ErrorHandlingVisitor {
			public PureVisitor(Job job, TypeSystem ts, NodeFactory nf) {
				super(job, ts, nf);
			}
			
			protected Node leaveCall(Node old, Node n, NodeVisitor v)
					throws SemanticException {
				if (n instanceof NormalPropertyNode) {
					NormalPropertyNode np = (NormalPropertyNode) n;
					if (!DualLogic.isPure(np.expr().type()))
						throw new SemanticException("Pure side cannot have " +
								"properties about linear variables", np.expr().position());
				}
				return n;
			}
		}
				
		PureVisitor pv = new PureVisitor(tc.job(), tc.typeSystem(), tc.nodeFactory());
		classicFormula.visit(pv);
		
		class DistinctVisitor extends ErrorHandlingVisitor {
			protected Set map;			
			
			public DistinctVisitor(Job job, TypeSystem ts, NodeFactory nf) {
				super(job, ts, nf);
				map = new HashSet();
			}
			
			public Node leaveCall(Node old, Node n, NodeVisitor v)
				throws SemanticException {
				if (n instanceof NormalPropertyNode) {
					NormalPropertyNode npn = (NormalPropertyNode)n;
					if (!DualLogic.isPure(npn.expr().type()))
						map.add(npn.expr().toString());
					if (map.size() > 1)
						throw new SemanticException("must be distinct");
				}
							
				return n;
			}
		}
		
		for (Iterator it = sepLogicFormulas.iterator() ; it.hasNext() ; ) {
			DistinctVisitor dv = new DistinctVisitor(tc.job(), tc.typeSystem(), tc.nodeFactory());
			((FormulaNode)it.next()).visit(dv);
		}
			
		return n;
	}
}
