package specjava.ast.specification.formula.atomic;

import polyglot.ast.Node;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.TypeBuilder;
import specjava.ast.specification.formula.FormulaNode_c;
import specjava.logic.formula.Formula;

public class TruthConstantNode_c extends FormulaNode_c implements
		TruthConstantNode {

	protected boolean value;

	public TruthConstantNode_c(Position pos, boolean value) {
		super(pos);
		this.value = value;
	}
	
	public Node buildTypes(TypeBuilder tb) throws SemanticException {
		return formula(formula = value ? Formula.TRUE : Formula.FALSE);
	}
	
	public boolean value() {
		return this.value;
	}

	public TruthConstantNode value(boolean value) {
		TruthConstantNode_c n = (TruthConstantNode_c) copy();
		n.value = value;
		return n;
	}

	public String toString() {
		return value + "";
	}

}
