package specjava.ast.specification.procedure;

import polyglot.ast.Node;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.SpecificationNode_c;
import specjava.ast.specification.formula.DualNode;

/**
 * Class implementing LoopInvariantNode.
 */
public class LoopInvariantNode_c extends SpecificationNode_c 
	implements LoopInvariantNode {

	protected DualNode dual;
	
	public LoopInvariantNode_c(Position pos, DualNode dual) {
		super(pos);
		assert(dual != null);
		this.dual = dual;
	}
	
	public LoopInvariantNode_c reconstruct(DualNode dual) {
        if (this.dual != dual) {
            LoopInvariantNode_c n = (LoopInvariantNode_c) copy();
            n.dual = dual;
            return n;
        }

        return this;
    }
	
	public Node visitChildren(NodeVisitor v) {
		DualNode dual = (DualNode) visitChild(this.dual, v);
		return reconstruct(dual);
	}

	public DualNode dualNode() {
		return dual;
	}

	public LoopInvariantNode dualNode(DualNode dn) {
		LoopInvariantNode_c n = (LoopInvariantNode_c) copy();
		n.dual = dn;
		return n;
	}
	
	public String toString() {
		return "invariant " + dual;
	}
	
}
