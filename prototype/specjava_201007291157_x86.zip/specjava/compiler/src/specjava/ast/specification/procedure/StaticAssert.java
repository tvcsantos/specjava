package specjava.ast.specification.procedure;

import polyglot.ast.Stmt;
import specjava.ast.specification.SpecificationNode;
import specjava.ast.specification.formula.DualNode;

/**
 * An immutable representation of a <code>sassert</code> statement.
 * This statement behaves like empty statement and it is used
 * only at compile time for specifications.
 */
public interface StaticAssert extends Stmt, SpecificationNode {
	/**
	 * Set the dual node of
	 * the static assert node.
	 */
	StaticAssert dualNode(DualNode dn);
}
