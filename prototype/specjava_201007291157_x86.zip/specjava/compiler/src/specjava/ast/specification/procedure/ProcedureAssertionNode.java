package specjava.ast.specification.procedure;

import specjava.ast.specification.SpecificationNode;
import specjava.ast.specification.formula.DualNode;

/**
 * Interface that represents specification nodes for procedures
 * (<code>requires</code> and <code>ensures</code>).
 */
public interface ProcedureAssertionNode extends SpecificationNode {
	/**
	 * Set the dual node of
	 * the procedure assertion node.
	 */
	ProcedureAssertionNode dualNode(DualNode dn);
	
	/**
	 * Return true if is precondition. 
	 */
	boolean isRequires();
	
	/**
	 * Return true if is postcondition.
	 */
	boolean isEnsures();
}
