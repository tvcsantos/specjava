package specjava.ast.specification.clazz;

import java.util.List;

import polyglot.ast.Node;
import polyglot.ast.Term;
import polyglot.ast.Variable;
import polyglot.types.MemberInstance;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.CFGBuilder;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeChecker;
import specjava.ast.specification.formula.DualNode;
import specjava.logic.DualLogic;
import specjava.logic.formula.DualImpl;
import specjava.types.SpecJavaParsedClassType;

/**
 * Class implementing ClassInvariantNode.
 */
public class ClassInvariantNode_c extends ClassSpecificationNode_c implements ClassInvariantNode {

	protected DualNode dual;
	
	public ClassInvariantNode_c(Position pos, DualNode dual) {
		super(pos);
		assert(dual != null);
		this.dual = dual;
	}

	public MemberInstance memberInstance() {
		return null;
	}
	
	public List acceptCFG(CFGBuilder v, List succs) {
		return succs;
	}

	public Term firstChild() {
		return null;
	}
	
	public ClassInvariantNode_c reconstruct(DualNode dual) {
        if (this.dual != dual) {
            ClassInvariantNode_c n = (ClassInvariantNode_c) copy();
            n.dual = dual;
            return n;
        }

        return this;
    }
	
	public Node visitChildren(NodeVisitor v) {
		DualNode dual = (DualNode) visitChild(this.dual, v);
		return reconstruct(dual);
	}

	public DualNode dualNode() {
		return dual;
	}

	public ClassInvariantNode dualNode(DualNode dn) {
		ClassInvariantNode_c n = (ClassInvariantNode_c) copy();
		n.dual = dn;
		return n;
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		SpecJavaParsedClassType sjpct = (SpecJavaParsedClassType) tc.context().currentClass();
		
		sjpct.addInvariant(new DualImpl(dual.classicFormula().formula(),
				DualLogic.getFormulas(dual.sepLogicFormulas())));
		
		StaticFinder sf = new StaticFinder();
		Node n = visit(sf);
		if (sf.hasStatic)
			throw new SemanticException("Can't acess static fields");
		return n;
	}
		
	private class StaticFinder extends NodeVisitor {
		boolean hasStatic = false;
		
		public Node leave(Node old, Node n, NodeVisitor v) {
			if (n instanceof Variable) {
				Variable va = (Variable)n;
				if (va.flags().isStatic())
					hasStatic = true;
			}
			
			return n;
		}
	}
	
	public String toString() {
		return "invariant " + dual + ";";
	}
}
