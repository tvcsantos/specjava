package specjava.ast.specification.formula.atomic;

import specjava.ast.specification.formula.FormulaNode;

public interface TruthConstantNode extends FormulaNode {

	/**
	 * The boolean property's value.
	 */
	boolean value();

	/**
	 * Set the boolean property's value.
	 */
	TruthConstantNode value(boolean value);
}