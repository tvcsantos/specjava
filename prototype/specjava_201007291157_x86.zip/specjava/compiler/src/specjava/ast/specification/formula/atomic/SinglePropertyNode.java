package specjava.ast.specification.formula.atomic;

import polyglot.ast.Id;
import specjava.ast.specification.formula.FormulaNode;

/**
 * A <code>SinglePropertyNode</code> represents the 
 * base property node of the form x:S or just S,
 * when x is omitted and refers to <code>this</code>.
 */
public interface SinglePropertyNode extends FormulaNode {
	
	/** The property assigned to the property node */
	Id property();
	
	SinglePropertyNode property(Id prop);
}