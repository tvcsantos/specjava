package specjava.ast.specification.formula.atomic;

import polyglot.ast.Id;
import polyglot.ast.Node;
import polyglot.types.CodeInstance;
import polyglot.types.FunctionInstance;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.util.Position;
import polyglot.visit.TypeChecker;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.SpecialTerm;
import specjava.types.Property;
import specjava.types.SpecJavaPrimitiveType;
import specjava.types.SpecJavaReferenceType;

public class SpecialPropertyNode_c extends SinglePropertyNode_c implements SpecialPropertyNode {
	
	protected SpecialPropertyNode.Kind kind;
	
	public SpecialPropertyNode_c(Position pos, SpecialPropertyNode.Kind kind, 
			Id prop) {
		super(pos, prop);
		assert(kind != null);
		this.kind = kind;
	}
	
	public SpecialPropertyNode.Kind kind() {
		return this.kind;
	}
	
	public SpecialPropertyNode kind(SpecialPropertyNode.Kind kind) {
		SpecialPropertyNode_c n = (SpecialPropertyNode_c) copy();
		n.kind = kind;
		return n;
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		SpecialPropertyNode_c n = (SpecialPropertyNode_c) super.typeCheck(tc);
		Type kt = null;
		Property p = null;
		if (n.kind == THIS) {
			kt = tc.context().currentClassScope();
			if (n.prop.id().compareTo("null") == 0)
				throw new SemanticException("this class can't be null", n.position());
			p = ((SpecJavaReferenceType)kt).propertyNamed(n.prop.id());
			if (p == null)
				throw new SemanticException("this class does not contain " + n.prop + " defined.", n.prop.position());
		} else if (n.kind == RETURN) {
			/* Always a method with return non void because the
			 * grammar does not allow the keyword return
			 * on non void methods. Check for it anyway
			 * to avoid errors.
			 */
			CodeInstance ci = tc.context().currentCode();
			if (ci instanceof FunctionInstance) {
				FunctionInstance fi = (FunctionInstance)ci;
				kt = fi.returnType();
				if (kt.isVoid())
					throw new SemanticException(kt + " is void", kt.position());
				if (kt.isReference()) {
					SpecJavaReferenceType sjrt = (SpecJavaReferenceType) kt.toReference();
					p = sjrt.propertyNamed(n.prop.id());
					if (p == null)
						throw new SemanticException(kt + " does not contain " + n.prop + " defined.", n.prop.position());
				} else if (kt.isPrimitive()) {
					SpecJavaPrimitiveType sjpt = (SpecJavaPrimitiveType)kt;
					p = sjpt.propertyNamed(n.prop.id());					
					if (p == null)
						throw new SemanticException(kt + " does not contain " + n.prop + " defined.", n.prop.position());
				} else {
					System.err.println("NOT REFERENCE NOR PRIMITIVE");
					return n;
				}
			} else throw new SemanticException(ci + " is not a function", ci.position());
		}
		
		return n.formula(new StatePredicate(p.toString(), new SpecialTerm(n.kind, kt)));
	}
	
	public String toString() {
		return kind + ":" + prop;		
	}
}
