package specjava.ast.specification.formula;

import polyglot.ast.Binary;
import polyglot.ast.Node;
import polyglot.ast.Precedence;
import polyglot.ast.Binary.Operator;
import polyglot.types.SemanticException;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeChecker;
import specjava.logic.formula.Formula;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;

/**
 * Class implementing BinaryFormulaNode.
 */
public class BinaryFormulaNode_c extends FormulaNode_c implements BinaryFormulaNode {

	protected FormulaNode left;
	protected Binary.Operator op;
	protected FormulaNode right;
	protected Precedence precedence;
	
	public BinaryFormulaNode_c(Position pos, FormulaNode left,
			Binary.Operator op, FormulaNode right) {
		super(pos);
		assert(left != null && op != null && right != null);
		this.left = left;
		this.op = op;
		this.right = right;
		this.precedence = op.precedence();
	}
		
	public FormulaNode left() {
		return this.left;
	}
	
	public BinaryFormulaNode left(FormulaNode left) {
		BinaryFormulaNode_c n = (BinaryFormulaNode_c) copy();
		n.left = left;
		return n;
	}
	
	public Operator operator() {
		return this.op;
	}
	
	public BinaryFormulaNode operator(Operator op) {
		BinaryFormulaNode_c n = (BinaryFormulaNode_c) copy();
		n.op = op;
		return n;
	}
	
	public BinaryFormulaNode precedence(Precedence precedence) {
		BinaryFormulaNode_c n = (BinaryFormulaNode_c) copy();
		n.precedence = precedence;
		return n;
	}
	
	public FormulaNode right() {
		return this.right;
	}
	
	public BinaryFormulaNode right(FormulaNode right) {
		BinaryFormulaNode_c n = (BinaryFormulaNode_c) copy();
		n.right = right;
		return n;
	}

	public Precedence precedence() {
		return this.precedence;
	}
	
	protected BinaryFormulaNode_c reconstruct(FormulaNode left, FormulaNode right) {
		if (left != this.left || right != this.right) {
			BinaryFormulaNode_c n = (BinaryFormulaNode_c) copy();
			n.left = left;
			n.right = right;
			return n;
		}

		return this;
	}
	
	public Node visitChildren(NodeVisitor v) {
		FormulaNode left = (FormulaNode) visitChild(this.left, v);
		FormulaNode right = (FormulaNode) visitChild(this.right, v);
		return reconstruct(left, right);
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		BinaryFormulaNode_c n = (BinaryFormulaNode_c) super.typeCheck(tc);
		
		Formula f = null;
		if (op == Binary.COND_AND) {
			f = new And(left.formula(), right.formula());
		} else if (op == Binary.COND_OR) {
			f = new Or(left.formula(), right.formula());
		} else if (op == BinaryFormulaNode.IMPLY) {
			f = new Implication(left.formula(), right.formula());
		} else if (op == BinaryFormulaNode.EQUIVALENT) {
			f = new Equivalence(left.formula(), right.formula());
		}
		
		return n.formula(f);
	}
		
	public String toString() {
		return left + " " + op + " " + right;
	}
}
