package specjava.ast.specification.formula;

import polyglot.ast.Node;
import polyglot.ast.Node_c;
import polyglot.ast.Precedence;
import polyglot.types.SemanticException;
import polyglot.util.CodeWriter;
import polyglot.util.Position;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeBuilder;
import specjava.logic.formula.Formula;
import specjava.logic.formula.UnknownFormula;

/**
 * Abstract class implementing the base of all FormulaNode.
 */
public abstract class FormulaNode_c extends Node_c implements FormulaNode {
	
	protected Formula formula;

	public FormulaNode_c(Position pos) {
		super(pos);
	}
	
	public Node buildTypes(TypeBuilder tb) throws SemanticException {		
		return formula(new UnknownFormula());
	}
	
	public boolean isTypeChecked() {
		return formula != null && formula.isCanonical() &&
		super.isTypeChecked();
	}
	
	/** Get the precedence of the expression. */
    public Precedence precedence() {
    	return Precedence.UNKNOWN;
    }
	
	/**
     * Correctly parenthesize the sub-formula <code>form</code> given
     * its precedence and the precedence of the current formula.
     *
     * If the sub-formula has the same precedence as this formula
     * we do not parenthesize.
     *
     * @param form The sub-formula.
     * @param w The output writer.
     * @param pp The pretty printer.
     */
    public void printSubForm(FormulaNode form, CodeWriter w, PrettyPrinter pp) {
        printSubForm(form, true, w, pp);
    }

    /**
     * Correctly parenthesize the sub-formula <code>form</code> given
     * its precedence and the precedence of the current formula.
     *
     * If the sub-formula has the same precedence as this formula
     * we parenthesize if the sub-formula does not associate; e.g.,
     * we parenthesis the right sub-formula of a left-associative
     * operator.
     *
     * @param form The sub-formula.
     * @param associative Whether prop is the left (right) child of a left-
     * (right-) associative operator.
     * @param w The output writer.
     * @param pp The pretty printer.
     */
	public void printSubForm(FormulaNode form, boolean associative, CodeWriter w,
			PrettyPrinter pp) {
		if (!associative && precedence().equals(form.precedence())
				|| precedence().isTighter(form.precedence())) {
			w.write("(");
			printBlock(form, w, pp);
			w.write(")");
		} else {
			print(form, w, pp);
		}
	}
	
	public Formula formula() {
		return formula;
	}
	
	public FormulaNode formula(Formula formula) {
		FormulaNode_c n = (FormulaNode_c) copy();
		n.formula = formula;
		return n;
	}
}
