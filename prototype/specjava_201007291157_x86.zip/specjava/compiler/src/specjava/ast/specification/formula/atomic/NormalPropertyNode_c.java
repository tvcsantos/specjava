package specjava.ast.specification.formula.atomic;

import polyglot.ast.Expr;
import polyglot.ast.Field;
import polyglot.ast.Id;
import polyglot.ast.Local;
import polyglot.ast.NamedVariable;
import polyglot.ast.Node;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import polyglot.visit.TypeChecker;
import specjava.logic.Utils;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.VariableTerm;
import specjava.types.Property;
import specjava.types.SpecJavaPrimitiveType;
import specjava.types.SpecJavaReferenceType;

public class NormalPropertyNode_c extends SinglePropertyNode_c 
	implements NormalPropertyNode {

	protected Expr expr;
	
	public String toString() {
		return expr + ":" + prop;
	}
	
	public NormalPropertyNode_c(Position pos, Expr expr, Id prop) {
		super(pos, prop);
		assert(expr != null);
		this.expr = expr;
	}
		
	protected NormalPropertyNode_c reconstruct(Id prop, Expr expr) {
		if (expr != this.expr) {
			NormalPropertyNode_c n = (NormalPropertyNode_c) copy();
			n.expr = expr;
			return (NormalPropertyNode_c) n.reconstruct(prop);
		}

		return (NormalPropertyNode_c) super.reconstruct(prop);
	}
	
	public Node visitChildren(NodeVisitor v) {
		Expr expr = (Expr) visitChild(this.expr, v);
		Id prop = (Id) visitChild(this.prop, v);
		return reconstruct(prop, expr);
	}
		
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		NormalPropertyNode_c n = (NormalPropertyNode_c) super.typeCheck(tc);
		
		if (!(n.expr instanceof NamedVariable))
			throw new SemanticException(
					"The expression must be a named variable", expr.position());
				
		NamedVariable nv = (NamedVariable) n.expr;
		
		Type tv = nv.varInstance().type();
		Property p = null;
		
		if (tv.isReference()) {
			SpecJavaReferenceType fsjct = (SpecJavaReferenceType) tv.toReference();
			p = fsjct.propertyNamed(n.prop.id());
		} else if (tv.isPrimitive()) {
			SpecJavaPrimitiveType sjpt = (SpecJavaPrimitiveType) tv;
			p = sjpt.propertyNamed(n.prop.id());
		} else {
			System.err.println("NOT REFERENCE NOR PRIMITIVE");
			return n;
		}
		
		if (p == null)
			throw new SemanticException(tv + " does not contain "
					+ n.prop + " defined.", n.prop.position());
		
		if (nv instanceof Field) {
			Field f = (Field)nv;
			FieldPath fp = Utils.getFieldPath(f);
			return n.formula(new StatePredicate(p.toString(), new VariableTerm(f, fp)));
		} else if (nv instanceof Local) {
			Local l = (Local)nv;
			return n.formula(new StatePredicate(p.toString(), new VariableTerm(l)));
		} else throw new SemanticException(
				"The expression must be a field or local variable", expr.position());
	}	
	
	public Expr expr() {
		return expr;
	}
	
	public NormalPropertyNode expr(Expr expr) {
		NormalPropertyNode_c n = (NormalPropertyNode_c) copy();
		n.expr = expr;
		return n;
	}
}

