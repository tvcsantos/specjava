package specjava.ast.specification.formula;

import polyglot.ast.Binary;
import polyglot.ast.Precedence;

/**
 * A <code>BinaryFormulaNode</code> represents a
 * binary formula node, an immutable pair of
 * formula nodes combined with an operator.
 */
public interface BinaryFormulaNode extends FormulaNode {

	/** Implication Binary Operator */
	public static final Binary.Operator IMPLY =
		new Binary.Operator("=>", FormulaNode.IMPLY);
	
	/** Equivalence Binary Operator */
	public static final Binary.Operator EQUIVALENT =
		new Binary.Operator("<=>", FormulaNode.EQUIVALENT);
	
	/** Left child of the binary. */
	FormulaNode left();
	
	/** Set the left child of the binary. */
	BinaryFormulaNode left(FormulaNode left);
	
	/** The binary's operator. */
	Binary.Operator operator();
	
	/** Set the binary's operator. */
	BinaryFormulaNode operator(Binary.Operator op);
	
	/** Right child of the binary. */
	FormulaNode right();
	
	/** Set the right child of the binary. */
	BinaryFormulaNode right(FormulaNode right);
	
	/** Set the precedence of the expression. */
	BinaryFormulaNode precedence(Precedence precedence);
	
}
