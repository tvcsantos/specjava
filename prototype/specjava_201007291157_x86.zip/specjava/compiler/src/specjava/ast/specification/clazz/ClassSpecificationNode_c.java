package specjava.ast.specification.clazz;

import polyglot.ast.Term_c;
import polyglot.util.Position;

/**
 * Abstract class that represents the base of all
 * SpecJava class specification nodes.
 */
public abstract class ClassSpecificationNode_c extends Term_c implements ClassSpecificationNode {

	public ClassSpecificationNode_c(Position pos) {
		super(pos);
	}
}
