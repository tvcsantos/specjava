package specjava.ast.specification.formula.atomic;

import polyglot.ast.Id;
import polyglot.ast.Node;
import polyglot.util.Position;
import polyglot.visit.NodeVisitor;
import specjava.ast.specification.formula.FormulaNode_c;

public abstract class SinglePropertyNode_c 
	extends FormulaNode_c implements SinglePropertyNode {
	
	protected Id prop;
	
	public SinglePropertyNode_c(Position pos, Id prop) {
		super(pos);
		assert(prop != null);
		this.prop = prop;
	}
	
	public Id property() {
		return prop;
	}
	
	public Node visitChildren(NodeVisitor v) {
		Id prop = (Id) visitChild(this.prop, v);
		return reconstruct(prop);
	}
	
	protected SinglePropertyNode_c reconstruct(Id prop) {
        if (this.prop != prop) {
            SinglePropertyNode_c n = (SinglePropertyNode_c) copy();
            n.prop = prop;
            return n;
        }

        return this;
    }
	
	public SinglePropertyNode property(Id prop) {
		SinglePropertyNode_c n = (SinglePropertyNode_c) copy();
		n.prop = prop;
		return n;
	}
}
