package specjava.ast.extension;

import polyglot.ast.JL_c;
import polyglot.ast.Node;
import polyglot.ast.NullLit;
import polyglot.ast.Synchronized;
import polyglot.types.SemanticException;
import polyglot.visit.TypeChecker;

/**
 * Delegation of a Java language <code>synchronized</code>
 * block.
 */
public class SpecJavaSynchronizedDel_c extends JL_c {
    public Node typeCheck(TypeChecker tc) throws SemanticException {
        Synchronized n = (Synchronized) super.typeCheck(tc);
        
        // can't synchronize on null reference
        if (n.expr() instanceof NullLit)
        	throw new SemanticException("Null is not a valid" +
        			"argument for the synchronized statement",
        			n.expr().position());

        return n;
    }
}
