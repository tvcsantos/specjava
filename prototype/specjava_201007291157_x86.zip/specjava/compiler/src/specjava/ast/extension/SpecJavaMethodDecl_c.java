package specjava.ast.extension;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import polyglot.ast.Block;
import polyglot.ast.Formal;
import polyglot.ast.Id;
import polyglot.ast.Local;
import polyglot.ast.MethodDecl;
import polyglot.ast.MethodDecl_c;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.ast.TypeNode;
import polyglot.frontend.Job;
import polyglot.types.Flags;
import polyglot.types.LocalInstance;
import polyglot.types.ReferenceType;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.util.CodeWriter;
import polyglot.util.CollectionUtil;
import polyglot.util.Pair;
import polyglot.util.Position;
import polyglot.util.TypedList;
import polyglot.visit.AmbiguityRemover;
import polyglot.visit.NodeVisitor;
import polyglot.visit.PrettyPrinter;
import polyglot.visit.TypeChecker;
import specjava.ast.specification.formula.DualNode;
import specjava.ast.specification.procedure.ProcedureAssertionNode;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.extension.statement.SpecJavaStmtExt;
import specjava.logic.DualLogic;
import specjava.logic.Utils;
import specjava.logic.formula.Dual;
import specjava.logic.formula.DualImpl;
import specjava.logic.visit.Simplifier;
import specjava.logic.visit.Substitutor;
import specjava.logic.visit.VisitorException;
import specjava.types.SpecJavaClassType;
import specjava.types.SpecJavaFlags;
import specjava.types.SpecJavaProcedureInstance;
import specjava.visit.LocalAssignVisitor;
import specjava.visit.PureVisitor;
import specjava.visit.VariableVisitor;
import specjava.visit.WeakestPreconditionBuilder;

/**
 * A <code>SpecJavaMethodDecl</code> is an immutable representation of a
 * method declaration as part of a class body.
 */
public class SpecJavaMethodDecl_c extends MethodDecl_c implements
		SpecJavaProcedureDecl, MethodDecl {

	protected List specs;
	
	protected Dual wpd;
	protected List vcsd;
	
	public SpecJavaMethodDecl_c(Position pos, Flags flags,
			TypeNode returnType, Id name, List formals, List specs,
			List throwTypes,
			Block body) {
		super(pos, flags, returnType, name, formals, throwTypes, body);
		assert(specs != null);
		this.specs = TypedList.copyAndCheck(specs, ProcedureAssertionNode.class, true);
		
		this.vcsd = new TypedList(new LinkedList(), Dual.class, false);
		this.wpd = null;
	}
	
	public boolean isTypeChecked() {
		return super.isTypeChecked() && 
			((SpecJavaProcedureInstance)mi).isFullCanonical();
	}
		
	public Dual weakestPrecondition() {
		return wpd;
	}
	
	public List verificationConditions() {
		return vcsd;
	}
	
	protected SpecJavaMethodDecl_c reconstruct(TypeNode returnType, Id name,
			List formals, List specs, List throwTypes, Block body) {
		if (!CollectionUtil.equals(this.specs, specs)) {
			SpecJavaMethodDecl_c n = (SpecJavaMethodDecl_c) copy();
			n.specs = TypedList.copyAndCheck(specs, ProcedureAssertionNode.class, true);
			return (SpecJavaMethodDecl_c) n.reconstruct(returnType, name,
					formals, throwTypes, body);
		}

		return (SpecJavaMethodDecl_c) super.reconstruct(returnType, name,
				formals, throwTypes, body);
	}
	
	public Node visitChildren(NodeVisitor v) {
		Id name = (Id) visitChild(this.name, v);
        List formals = visitList(this.formals, v);
        TypeNode returnType = (TypeNode) visitChild(this.returnType, v);
        List specs = visitList(this.specs, v);
		List throwTypes = visitList(this.throwTypes, v);
		Block body = (Block) visitChild(this.body, v);
		return reconstruct(returnType, name, formals, specs, throwTypes, body);
	}
	
	public Node disambiguate(AmbiguityRemover ar) throws SemanticException {
		SpecJavaMethodDecl_c n = (SpecJavaMethodDecl_c) super.disambiguate(ar);
		
		if (n.mi.isCanonical())
			return n;
				
		List l = new LinkedList();
		for(Iterator it = n.formals.iterator(); it.hasNext(); ) {
			Formal f = (Formal) it.next();
			if (!f.isDisambiguated()) return n;
			l.add(f.localInstance());
		}
		
		SpecJavaProcedureInstance spi = (SpecJavaProcedureInstance)n.mi;
		
		spi.setFormalNames(l);
		
		return n;
	}
	
	public Node typeCheck(TypeChecker tc) throws SemanticException {
		SpecJavaMethodDecl_c n = (SpecJavaMethodDecl_c) super.typeCheck(tc);
		SpecJavaProcedureInstance spi = (SpecJavaProcedureInstance)n.mi;
		
		Dual pre = null;
		Dual post = null;
		ListIterator lit = n.specs.listIterator(n.specs.size());
		while (lit.hasPrevious()) {
			ProcedureAssertionNode sn = (ProcedureAssertionNode) lit.previous();
			DualNode fn = sn.dualNode();
			if (!fn.isTypeChecked()) return n;
			Dual fnd = new DualImpl(fn.classicFormula().formula(),
					DualLogic.getFormulas(fn.sepLogicFormulas()));
			if (sn.isRequires()) {				
				if (pre == null) pre = fnd;
				else pre = DualLogic.and(fnd, pre);
			} else if (sn.isEnsures()) {
				if (post == null) post = fnd;
				else post = DualLogic.and(fnd, post);
			}
		}
		
		// XXX add invariants if not static
		
		ReferenceType rt = n.mi.container();
		
		Dual is = null;
		if (!flags().isStatic() && rt.isClass()) {
			SpecJavaClassType sjct = (SpecJavaClassType)rt.toClass();
			List invs = sjct.invariants();
			Iterator it = invs.iterator();
			if (it.hasNext()) is = (Dual)it.next();			
			while(it.hasNext()) {
				Dual d = (Dual)it.next();
				is = DualLogic.and(is, d);
			}
		}

		if (is != null) { 
			post = DualLogic.and(post, is);
			pre = DualLogic.and(pre, is);
		}
			
		spi.setPreconditiond(pre);
		spi.setPostconditiond(post);
		
		if (n.mi.flags().contains(SpecJavaFlags.PURE) && 
				DualLogic.isPure(n.mi.container()) &&
				!DualLogic.isPure(n.mi.returnType()))
			throw new SemanticException("Pure objects cannot " +
					"return linear objects: " + n.mi.returnType()
					+ " is linear but method " + n.mi.name() + " is pure", position());
		
		PureVisitor purvis = new PureVisitor(tc.job(), tc.typeSystem(), 
				tc.nodeFactory(), spi);
		purvis.begin();
		visit(purvis);
		
		return n;
	}

	public Node buildWP(WeakestPreconditionBuilder v) throws WPCalculusException {
		Job j = v.job();
		TypeSystem ts = v.typeSystem();
		NodeFactory nf = v.nodeFactory();
		
		VariableVisitor vx = new VariableVisitor(j, ts, nf);
		vx.begin();
		visit(vx);
		
		LocalAssignVisitor assvx = new LocalAssignVisitor(j, ts, nf);
		assvx.begin();
		visit(assvx);
		
		SpecJavaProcedureInstance spi = (SpecJavaProcedureInstance)procedureInstance();		
		Dual pre = spi.preconditiond();
		Dual post = spi.postconditiond();
		
		List l = formals();
		Set s = new HashSet();
		for (Iterator it = l.iterator(); it.hasNext();) {
			Formal formal = (Formal) it.next();
			s.add(formal.localInstance());
		}
		
		Set inter = specjava.util.CollectionUtil.intersection(assvx.ass, s);
		
		List undos = new LinkedList();
		if (!inter.isEmpty()) {
			// must replace because we are assigning
			// new values to formal parameters
			for (Iterator it = inter.iterator(); it.hasNext();) {
				LocalInstance li = (LocalInstance) it.next();
				Local loc = (Local) nf.Local(li.position(), nf.Id(li.position(),
						li.name())).localInstance(li).type(li.type());
				Local fresh = (Local) WPCalculus.getFresh(loc, loc.type(), nf, ts, vx.vars);
				Substitutor sub = new Substitutor(li.name(), fresh);
				Substitutor undo_sub = new Substitutor(fresh.name(), loc);
				undos.add(undo_sub);
				try {
					post = Utils.visit(post, sub);
				} catch (VisitorException e) {
					throw WPCalculus.warp(e, position());
				}
			}
		}		
		
		WPCalculus wpc = v.getCalculus();
		
		if (pre == null) {
			System.err.println("WARNING: " + spi + 
					" precondition is null assuming " + 
					Dual.TRUE_EMPTY);
			pre = Dual.TRUE_EMPTY;
		}
		if (post == null) {
			System.err.println("WARNING: " + spi + 
					" postcondition is null assuming " + 
					Dual.TRUE_EMPTY);
			post = Dual.TRUE_EMPTY;
		}
		
		SpecJavaStmtExt stmt = (SpecJavaStmtExt) body.ext();
		System.out.println("{" + pre.toString() + "} " + 
				name() + " {" + post.toString() + "}");
			
		wpc.setMethodpost(post);
		wpc.setMethodpre(pre);
		
		wpd = stmt.wp(wpc, post);
		
		wpc.subs.clear();
		
		vcsd = stmt.vc(wpc, post);
		
		for (Iterator it = undos.iterator(); it.hasNext();) {
			Substitutor undo = (Substitutor) it.next();
			try {
				wpd = Utils.visit(wpd, undo);
				vcsd = Utils.visitDualList(vcsd, undo);
			} catch (VisitorException e) {
				WPCalculus.warp(e, position());
			}
		}		
		
		Dual vcd = DualLogic.imply(pre, wpd);
				
		vcsd.add(0, new Pair(vcd, position()));
		
		Simplifier simpl = new Simplifier();
		
		try {
			wpd = Utils.visit(wpd, simpl);
			vcsd = Utils.visitDualList(vcsd, simpl);
		} catch (VisitorException e) {
			throw WPCalculus.warp(e, position());
		}
		
		System.out.println("WEAKEST PRECONDITION " + wpd.toString() + "\n" + 
				"VERIFICATION CONDITIONS " + vcsd.toString() + "\n");
		return this;
	}
	
	public List specs() {
		return Collections.unmodifiableList(this.specs);
	}
	
	public void prettyPrintHeader(Flags flags, CodeWriter w, PrettyPrinter tr) {
		flags = flags.clear(SpecJavaFlags.PURE);
		super.prettyPrintHeader(flags, w, tr);
	}
}
