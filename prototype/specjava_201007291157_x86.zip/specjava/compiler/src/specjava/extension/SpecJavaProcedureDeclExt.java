package specjava.extension;

import polyglot.ast.Ext;
import polyglot.ast.Node;
import polyglot.types.SemanticException;
import specjava.visit.SpecificationChecker;

public interface SpecJavaProcedureDeclExt extends Ext {
	
	public Node specCheck(SpecificationChecker sc) throws SemanticException;
	
}
