package specjava.extension;

import java.util.LinkedList;
import java.util.List;

import polyglot.ast.Ext_c;
import polyglot.ast.Node;
import polyglot.types.SemanticException;
import specjava.ast.extension.SpecJavaProcedureDecl;
import specjava.logic.CVCProver;
import specjava.logic.Prover;
import specjava.logic.ProverException;
import specjava.logic.Result;
import specjava.visit.SpecificationChecker;

public class SpecJavaProcedureDeclExt_c extends Ext_c
	implements SpecJavaProcedureDeclExt	
{
	
	public Node specCheck(SpecificationChecker sc)
			throws SemanticException {
		Node n = node();
		List vcs = new LinkedList();
		if (n instanceof SpecJavaProcedureDecl)
			vcs = ((SpecJavaProcedureDecl)n).verificationConditions();
		
		if (vcs.isEmpty()) return n;
				
		try {
			Prover pv = new CVCProver(vcs);
			Result r = pv.prove(true);
			if (r.getStatus() != Prover.VALID)
				throw new SemanticException("Invalid Specification", r.getPosition());
		} catch (ProverException e) {
			SemanticException se = new SemanticException();
			se.initCause(e);
			throw se;
		}
		
		return n;
	}
}
