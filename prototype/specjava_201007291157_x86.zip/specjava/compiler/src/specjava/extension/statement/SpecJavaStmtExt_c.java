package specjava.extension.statement;

import java.util.List;

import polyglot.ast.Ext_c;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;

public class SpecJavaStmtExt_c extends Ext_c implements SpecJavaStmtExt {

	public String toString() {
		return node().toString();
	}
	
	/**
	 * Calculate the weakest precondition of the statement in respect
	 * to the postcondition in argument.
	 * Note all subclasses of this class must override the method.
	 */
	public Dual wp(WPCalculus calc, Dual post) throws WPCalculusException {
		throw new WPCalculusException("Statement not supported: " + 
				node().getClass().getCanonicalName(), node().position());
	}
	
	/**
	 * Calculate the weakest precondition of the statement in respect
	 * to the postcondition in argument.
	 * Note all subclasses of this class must override the method.
	 */
	public List vc(WPCalculus calc, Dual post) throws WPCalculusException {
		throw new WPCalculusException("Statement not supported: " + 
				node().getClass().getCanonicalName(), node().position());
	}
	
}
