package specjava.extension.statement;

import java.util.List;

import polyglot.ast.Synchronized;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;

public class SpecJavaSynchronizedExt_c extends SpecJavaStmtExt_c {

	public Dual wp(WPCalculus calc, Dual post) throws WPCalculusException {
		return calc.wp((Synchronized)node(), post);
	}
	
	public List vc(WPCalculus calc, Dual post) throws WPCalculusException {
		return calc.vc((Synchronized)node(), post);
	}
}
