package specjava.extension.statement;

import java.util.List;

import polyglot.ast.ConstructorCall;
import specjava.extension.WPCalculus;
import specjava.extension.WPCalculusException;
import specjava.logic.formula.Dual;

public class SpecJavaConstructorCallExt_c extends SpecJavaStmtExt_c {
	
	public Dual wp(WPCalculus calc, Dual post) throws WPCalculusException {
		ConstructorCall pc = (ConstructorCall) node().del();
		
		if (pc.kind() == ConstructorCall.SUPER
				&& !pc.arguments().isEmpty())
			throw new WPCalculusException("Inheritance not supported " +
					"for the time being", pc.position());
		
		return calc.wp(pc, post);
	}
	
	public List vc(WPCalculus calc, Dual post) throws WPCalculusException {
		ConstructorCall pc = (ConstructorCall) node().del();
		
		if (pc.kind() == ConstructorCall.SUPER
				&& !pc.arguments().isEmpty())
			throw new WPCalculusException("Inheritance not supported " +
					"for the time being", pc.position());
		
		return calc.vc(pc, post);
	}
}
