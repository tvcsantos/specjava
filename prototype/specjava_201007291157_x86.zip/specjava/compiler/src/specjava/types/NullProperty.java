package specjava.types;

public interface NullProperty extends Property {

}
