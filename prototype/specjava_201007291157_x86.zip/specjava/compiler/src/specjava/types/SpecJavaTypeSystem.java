package specjava.types;

import polyglot.types.ClassType;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

public interface SpecJavaTypeSystem extends TypeSystem {
    // declare any new methods needed
	
	Property NullProperty(Position pos);
	Property BooleanProperty(Position pos, boolean value);
	Property NumberProperty(Position pos, Property.NumberType type);
	Property NamedProperty(Position pos, String name);
	Property NamedProperty(Position pos, String name, ClassType ct);
	// add class
}
