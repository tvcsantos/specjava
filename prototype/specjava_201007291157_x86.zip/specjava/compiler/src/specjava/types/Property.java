package specjava.types;

import polyglot.types.Named;
import polyglot.types.Type;
import polyglot.util.Enum;

public interface Property extends Named {
	
	public static final NumberType POS = new NumberType("pos");
	public static final NumberType NEG = new NumberType("neg");
	public static final NumberType ZERO = new NumberType("zero");
	
	public static class NumberType extends Enum {
		private static final long serialVersionUID = 3958771749405108897L;

		public NumberType(String name) {
			super(name);
		}
	}
	
	// x:S, represent the S part
	boolean typeConforms(Type t);
	boolean isBaseProperty();
}