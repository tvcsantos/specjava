package specjava.types;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import polyglot.types.ArrayType;
import polyglot.types.ArrayType_c;
import polyglot.types.ClassType;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.util.Position;
import specjava.logic.formula.Dual;

public interface SpecJavaClassType extends ClassType, SpecJavaReferenceType {
	boolean isPure();
}

interface SpecJavaArrayType extends ArrayType, SpecJavaReferenceType { }

class SpecJavaArrayType_c extends ArrayType_c 
	implements SpecJavaReferenceType, ArrayType {

	private static final long serialVersionUID = -1030671515423858923L;
	
	protected List props;
	protected List invs;
	protected Map defs;
	
	/** Used for deserializing types. */
    protected SpecJavaArrayType_c() { }

    public SpecJavaArrayType_c(TypeSystem ts, Position pos, Type base) {
    	super(ts, pos, base);
    	props = new LinkedList();
		invs = new LinkedList();
		SpecJavaTypeSystem sjts = (SpecJavaTypeSystem)ts;
		Property nullp = sjts.NullProperty(Position.COMPILER_GENERATED);
		props.add(nullp);
		defs = new HashMap();
		defs.put(nullp, null);
    }
	
	public List invariants() {
		return Collections.unmodifiableList(invs);
	}

	public List properties() {
		return Collections.unmodifiableList(props);
	}

	public Property propertyNamed(String name) {
		for (Iterator i = props.iterator(); i.hasNext(); ) {
            Property p = (Property) i.next();
            if (p.name().equals(name)) {
                return p;
            }
        }
		
		return null;
	}

	public boolean isAbstract(Property prop)
		throws PropertyNotFoundException
	{
		if (!defs.containsKey(prop))
			throw new PropertyNotFoundException(prop.toString());
		return defs.containsKey(prop) &&
				defs.get(prop) == null;
	}

	public Dual getDefinition(Property prop)
		throws PropertyNotFoundException
	{
		if (!defs.containsKey(prop))
			throw new PropertyNotFoundException(prop.toString());
		return (Dual) defs.get(prop);
	}
	
	public Set definitions() {
		return Collections.unmodifiableSet(defs.entrySet());
	}
	
}