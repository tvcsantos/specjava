package specjava.types;

import polyglot.types.ClassType;
import polyglot.types.Type;
import polyglot.types.TypeObject;
import polyglot.types.TypeObject_c;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

public class NamedProperty_c
	extends TypeObject_c implements Property {

	private static final long serialVersionUID = 5611682969469666269L;
	
	protected String name;
	protected boolean local;
	
	protected TypeObject where;

	public NamedProperty_c(TypeSystem ts, Position pos, String name) {
		super(ts, pos);
		this.name = name;
		this.local = true;
	}
		
	public NamedProperty_c(TypeSystem ts, Position pos, String name, ClassType ct) {
		super(ts, pos);
		this.name = name;
		this.local = false;
		this.where = ct;
	}
	
	public String name() {
        return name;
    }
	
	public String fullName() {
		if (!isLocal()) {
			ClassType ct = (ClassType)where;
			return ct.fullName() + "." + name();
		} else {
			return name();
		}
	}

    public int hashCode() {
        return name.hashCode();
    }

    public String toString() {
        return fullName();
    }

    public boolean isCanonical() {
        return true;
    }

	public boolean typeConforms(Type t) {
		return true;
	}
	
	public boolean isBaseProperty() {
		return false;
	}
	
	public boolean equalsImpl(TypeObject t) {
		if (t instanceof Property) {
            return name().equalsIgnoreCase(((Property) t).name());
        }
        return false;
	}
	
	public boolean isLocal() {
		return local;
	}
	
}
