package specjava.types;

import java.util.Set;

import polyglot.types.Context;
import polyglot.types.SemanticException;

public interface SpecJavaContext extends Context {
	public void addProperty(Property prop);
	public Property findPropertyz(String name) throws SemanticException;
	public Property findProperty(String name) throws SemanticException;
	public Property findPropertySilent(String name);
	
	public Set variablesInScope();
}
