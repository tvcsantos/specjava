package specjava.types;

public interface NamedProperty extends Property { }
