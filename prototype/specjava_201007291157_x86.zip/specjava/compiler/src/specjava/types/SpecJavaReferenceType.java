package specjava.types;

import java.util.List;
import java.util.Set;

import polyglot.types.ReferenceType;
import specjava.logic.formula.Dual;

public interface SpecJavaReferenceType extends ReferenceType {	
	List properties(); // List[Property]
	
	Property propertyNamed(String name);
	
	List invariants(); 	// List[Formula]
	
	Set definitions(); // Set[Entry[Property, Dual]]
	
	Dual getDefinition(Property prop)
		throws PropertyNotFoundException;
	
	boolean isAbstract(Property prop)
		throws PropertyNotFoundException;
}
