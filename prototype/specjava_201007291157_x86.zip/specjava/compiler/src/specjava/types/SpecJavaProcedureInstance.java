package specjava.types;

import java.util.List;

import polyglot.types.ProcedureInstance;
import specjava.logic.formula.Dual;

public interface SpecJavaProcedureInstance extends ProcedureInstance {

	List formalNames();
	
	void setFormalNames(List names);
	
	SpecJavaProcedureInstance formalNames(List names);
	
	Dual preconditiond();
	void setPreconditiond(Dual pre);
	
	Dual postconditiond();
	void setPostconditiond(Dual post);
	
	boolean isFullCanonical();
}
