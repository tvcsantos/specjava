package specjava.types;

import polyglot.types.TypeObject;
import polyglot.types.TypeObject_c;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

public final class NumberProperty_c
	extends TypeObject_c implements Property {
	
	private static final long serialVersionUID = 8284068426864037622L;
	
	protected NumberType type;
	
	public NumberProperty_c(
			TypeSystem ts, Position pos, NumberType t) {
		super(ts, pos);
		this.type = t;
	}
	
	public String name() {
		return type.toString();
	}
	
	public String fullName() {
		return name();
	}
	
	public boolean isCanonical() {
		return true;
	}
	
	public int hashCode() {
		return name().hashCode();
	}
	
	public String toString() {
		return name();
	}

	public boolean typeConforms(polyglot.types.Type t) {
		return t.isReference() || t.isNumeric();
	}
	
	public boolean isBaseProperty() {
		return true;
	}
	
	public boolean equalsImpl(TypeObject t) {
		if (t instanceof Property) {
			return name().equalsIgnoreCase(((Property) t).name());
        }
        return false;
	}
	
	public boolean isLocal() {
		return false;
	}
}
