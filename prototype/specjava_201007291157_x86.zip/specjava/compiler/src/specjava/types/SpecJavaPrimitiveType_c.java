package specjava.types;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import polyglot.types.PrimitiveType_c;
import polyglot.types.TypeSystem;
import polyglot.util.Position;

public class SpecJavaPrimitiveType_c extends PrimitiveType_c implements
		SpecJavaPrimitiveType {

	private static final long serialVersionUID = -8007281531516897384L;
	
	protected List props;
	
	/** Used for deserializing types. */
    protected SpecJavaPrimitiveType_c() { }

    public SpecJavaPrimitiveType_c(TypeSystem ts, Kind kind) {
    	super(ts, kind);
    	initProps();
    }
    
    protected void initProps() {
    	props = new LinkedList();
    	SpecJavaTypeSystem sjts = (SpecJavaTypeSystem)ts;
    	if (isNumeric()) {
      		props.add(sjts.NumberProperty(Position.COMPILER_GENERATED, Property.POS));
    		props.add(sjts.NumberProperty(Position.COMPILER_GENERATED, Property.NEG));
    		props.add(sjts.NumberProperty(Position.COMPILER_GENERATED, Property.ZERO));
    	} else if (isBoolean()) {
    		props.add(sjts.BooleanProperty(Position.COMPILER_GENERATED, true));
    		props.add(sjts.BooleanProperty(Position.COMPILER_GENERATED, false));
    	}    		
    }

	public List properties() {
		return Collections.unmodifiableList(props);
	}

	public Property propertyNamed(String name) {
		for (Iterator i = props.iterator(); i.hasNext(); ) {
            Property p = (Property) i.next();
            if (p.name().equals(name)) {
                return p;
            }
        }
		
		return null;
	}

}
