package specjava.frontend.goals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.frontend.Scheduler;
import polyglot.frontend.goals.Goal;
import polyglot.frontend.goals.VisitorGoal;
import polyglot.types.TypeSystem;
import specjava.ExtensionInfo.SpecJavaScheduler;
import specjava.visit.WeakestPreconditionBuilder;

/**
 * a <code>WeakestPreconditionBuilt</code> is reached after
 * computing procedures weakest preconditions.
 */
public class WeakestPreconditionBuilt extends VisitorGoal {
    public static Goal create(Scheduler scheduler, Job job, TypeSystem ts, NodeFactory nf) {
        return scheduler.internGoal(new WeakestPreconditionBuilt(job, ts, nf));
    }

    protected WeakestPreconditionBuilt(Job job, TypeSystem ts, NodeFactory nf) {
        super(job, new WeakestPreconditionBuilder(job, ts, nf));
    }

    public Collection prerequisiteGoals(Scheduler scheduler) {
    	List l = new ArrayList();
        l.addAll(super.prerequisiteGoals(scheduler));
        l.add(((SpecJavaScheduler)scheduler).TypeCheckedBarrier(job));
        l.add(scheduler.TypeChecked(job));
        //l.add(scheduler.ConstantsChecked(job));
        l.add(scheduler.ReachabilityChecked(job));
        l.add(scheduler.ExceptionsChecked(job));
        l.add(scheduler.ExitPathsChecked(job));
        l.add(scheduler.InitializationsChecked(job));
        l.add(scheduler.ConstructorCallsChecked(job));
        l.add(scheduler.ForwardReferencesChecked(job));
        return l;
    }
}
