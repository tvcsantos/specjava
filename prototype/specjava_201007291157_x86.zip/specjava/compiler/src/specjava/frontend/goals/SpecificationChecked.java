package specjava.frontend.goals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.frontend.Scheduler;
import polyglot.frontend.goals.Goal;
import polyglot.frontend.goals.VisitorGoal;
import polyglot.types.TypeSystem;
import specjava.ExtensionInfo.SpecJavaScheduler;
import specjava.visit.SpecificationChecker;

/**
 * a <code>SpecificationChecked</code> is reached after
 * verifying program correctness according to its specification.
 */
public class SpecificationChecked extends VisitorGoal {
    public static Goal create(Scheduler scheduler, Job job, TypeSystem ts, NodeFactory nf) {
        return scheduler.internGoal(new SpecificationChecked(job, ts, nf));
    }

    protected SpecificationChecked(Job job, TypeSystem ts, NodeFactory nf) {
        super(job, new SpecificationChecker(job, ts, nf));
    }

    public Collection prerequisiteGoals(Scheduler scheduler) {
    	List l = new ArrayList();
    	l.add(((SpecJavaScheduler)scheduler).WeaskestPreconditionBuilt(job));
        l.addAll(super.prerequisiteGoals(scheduler));
        return l;
    }
}
