package specjava.visit;

import polyglot.ast.ConstructorDecl;
import polyglot.ast.MethodDecl;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.Type;
import polyglot.types.TypeSystem;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;
import specjava.ast.extension.SpecJavaProcedureDecl;
import specjava.extension.WPCalculus;

public class WeakestPreconditionBuilder extends ErrorHandlingVisitor {
	
	private WPCalculus wpcalc; 

	public WeakestPreconditionBuilder(Job job, TypeSystem ts, NodeFactory nf) {
		super(job, ts, nf);
	}
	
	protected Node leaveCall(Node old, Node n, NodeVisitor v)
			throws SemanticException {
		if (n.del() instanceof SpecJavaProcedureDecl) {
			VariableVisitor vx = new VariableVisitor(job, ts, nf);
			vx.begin();
			SpecJavaProcedureDecl spd = (SpecJavaProcedureDecl) n.del();
			spd.visit(vx);
			Type t = null;
			if (spd instanceof ConstructorDecl) {
				ConstructorDecl cd = (ConstructorDecl) spd;
				t = cd.constructorInstance().container();
			} else if (spd instanceof MethodDecl) {
				MethodDecl md = (MethodDecl) spd;
				t = md.methodInstance().returnType();
			} else throw new SemanticException("Must be a method or constructor declaration", n.position());
				
			wpcalc = new WPCalculus(nf, ts, vx.vars, t);
			Node nr = ((SpecJavaProcedureDecl) n.del()).buildWP((WeakestPreconditionBuilder) v);
			wpcalc = null;
			return nr;
		}

		return n;
	}
	
	public WPCalculus getCalculus() {
		return wpcalc;
	}
}
