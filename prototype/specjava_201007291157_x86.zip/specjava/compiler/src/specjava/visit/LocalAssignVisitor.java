package specjava.visit;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Assign;
import polyglot.ast.Local;
import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ContextVisitor;
import polyglot.visit.NodeVisitor;

public class LocalAssignVisitor extends ContextVisitor {
	
	public Set ass = new HashSet();

	public LocalAssignVisitor(Job job, TypeSystem ts, NodeFactory nf) {
		super(job, ts, nf);
	}
	
	protected Node leaveCall(Node old, Node n, NodeVisitor v)
			throws SemanticException {
		if (n instanceof Assign) {
			Assign a = (Assign)n;
			if (a.left() instanceof Local) {
				Local l = (Local)a.left();
				ass.add(l.localInstance());
			}
		}		
		return n;
	}
}