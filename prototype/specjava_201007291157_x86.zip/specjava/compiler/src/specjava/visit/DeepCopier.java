package specjava.visit;

import polyglot.ast.Node;
import polyglot.visit.NodeVisitor;

public class DeepCopier extends NodeVisitor {

	public Node leave(Node old, Node n, NodeVisitor v) {
		return (Node) n.copy();
	}

}