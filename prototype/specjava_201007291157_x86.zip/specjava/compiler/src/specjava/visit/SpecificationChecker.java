package specjava.visit;

import polyglot.ast.Node;
import polyglot.ast.NodeFactory;
import polyglot.frontend.Job;
import polyglot.types.SemanticException;
import polyglot.types.TypeSystem;
import polyglot.visit.ErrorHandlingVisitor;
import polyglot.visit.NodeVisitor;
import specjava.extension.SpecJavaProcedureDeclExt;

/** Visitor which performs specification checking on the AST. */
public class SpecificationChecker extends ErrorHandlingVisitor
{
    public SpecificationChecker(Job job, TypeSystem ts, NodeFactory nf) {
        super(job, ts, nf);
    }
    
    protected Node leaveCall(Node old, Node n, NodeVisitor v)
    		throws SemanticException {
    	if (n.ext() instanceof SpecJavaProcedureDeclExt) {
			return ((SpecJavaProcedureDeclExt) n.ext()).specCheck((SpecificationChecker) v);
		} else return super.leaveCall(old, n, v);
    }
}
