package specjava;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import polyglot.ast.NodeFactory;
import polyglot.frontend.CupParser;
import polyglot.frontend.FileSource;
import polyglot.frontend.JLScheduler;
import polyglot.frontend.Job;
import polyglot.frontend.Parser;
import polyglot.frontend.Scheduler;
import polyglot.frontend.goals.Barrier;
import polyglot.frontend.goals.EmptyGoal;
import polyglot.frontend.goals.Goal;
import polyglot.frontend.goals.Serialized;
import polyglot.frontend.goals.VisitorGoal;
import polyglot.lex.Lexer;
import polyglot.types.TypeSystem;
import polyglot.util.ErrorQueue;
import polyglot.visit.DumpAst;
import specjava.ast.factory.SpecJavaNodeFactory_c;
import specjava.frontend.goals.SpecificationChecked;
import specjava.frontend.goals.WeakestPreconditionBuilt;
import specjava.parse.Grm;
import specjava.parse.Lexer_c;
import specjava.types.SpecJavaTypeSystem_c;

/**
 * Extension information for specjava extension.
 */
public class ExtensionInfo extends polyglot.frontend.JLExtensionInfo {
    static {
        // force Topics to load
        /*Topics t =*/ new Topics();
    }

    public String defaultFileExtension() {
        return "sj";
    }

    public String compilerName() {
        return "specjavac";
    }

    public Parser parser(Reader reader, FileSource source, ErrorQueue eq) {
        Lexer lexer = new Lexer_c(reader, source, eq);
        Grm grm = new Grm(lexer, ts, nf, eq);
        return new CupParser(grm, source, eq);
    }

    protected NodeFactory createNodeFactory() {
        return new SpecJavaNodeFactory_c();
    }

    protected TypeSystem createTypeSystem() {
        return new SpecJavaTypeSystem_c();
    }
    
    public Scheduler createScheduler() {
        return new SpecJavaScheduler(this);
    }
    
    public static class SpecJavaScheduler extends JLScheduler {

		public SpecJavaScheduler(ExtensionInfo extInfo) {
			super(extInfo);
		}
		
		public Goal WeaskestPreconditionBuilt(Job job) {
			TypeSystem ts = extInfo.typeSystem();
			NodeFactory nf = extInfo.nodeFactory();
			Goal g = WeakestPreconditionBuilt.create(this, job, ts, nf);
			return g;
		}
		
		public Goal TypeCheckedBarrier(Job job) {
			return TypeCheckedBarrier.create(this);
		}
		
		public Goal DumpedAst(Job job) {
			Goal g = DumpedAst.create(this, job);
			return g;
		}
		
		static class DumpedAst extends VisitorGoal {
			public static Goal create(Scheduler scheduler, Job job) {
				try {
					return scheduler.internGoal(new DumpedAst(job));
				} catch(Exception e) {
					return scheduler.internGoal(new EmptyGoal(job));
				}
			}
			
			@SuppressWarnings("deprecation")
			protected DumpedAst(Job job) throws IOException {
//				super(job, new DumpAst(new SimpleCodeWriter(/*System.out,*/
//						new FileOutputStream("ast.txt"), 80)));
				super(job, new DumpAst("ast.txt", 100));
			}
		}
		
		static class TypeCheckedBarrier extends Barrier {
		    public static Goal create(Scheduler scheduler) {
		        return scheduler.internGoal(new TypeCheckedBarrier(scheduler));
		    }

		    protected TypeCheckedBarrier(Scheduler scheduler) {
		        super("TYPES_CHECKED_BARRIER", scheduler);
		    }
		    
		    public Goal goalForJob(Job j) {
		        return scheduler.TypeChecked(j);
		    }
		}
			
		public Goal SpecificationChecked(Job job) {
			TypeSystem ts = extInfo.typeSystem();
			NodeFactory nf = extInfo.nodeFactory();
			Goal g = SpecificationChecked.create(this, job, ts, nf);
			return g;
		}
    	
		public Goal Serialized(Job job) {
			Goal g = internGoal(new Serialized(job) {
                public Collection prerequisiteGoals(Scheduler scheduler) {
                    List l = new ArrayList();
                    l.addAll(super.prerequisiteGoals(scheduler));
                    l.add(SpecificationChecked(job));
                    //l.add(DumpedAst(job));
                    return l;
                }
            });
            return g;
		}
    }

}
