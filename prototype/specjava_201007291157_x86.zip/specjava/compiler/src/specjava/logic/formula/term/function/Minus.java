package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Minus extends AbstractFunction {

	private static final long serialVersionUID = -7252264736942917658L;

	public Minus(Term t) {
		super(new Term[]{ t });
	}
	
	public Minus(Term left, Term right) {
		super(new Term[]{left, right});
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}
