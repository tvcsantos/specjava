package specjava.logic.formula.term;

import java.util.HashSet;
import java.util.Set;

import polyglot.types.Type;
import polyglot.types.UnknownType;
import specjava.ast.specification.formula.atomic.SpecialPropertyNode.Kind;
import specjava.logic.DualLogic;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public final class SpecialTerm implements Term {
	
	private static final long serialVersionUID = -4867350870072500129L;
	
	private Kind kind;
	private Type kt;
	
	public SpecialTerm(Kind kind, Type kt) {
		this.kind = kind;
		this.kt = kt;
	}

	public boolean isCanonical() {
		return kt != null && !(kt instanceof UnknownType);
	}

	public Set symbols() {
		Set res = new HashSet();
		res.add(kind.toString());
		return res;
	}
	
	public Set pureSymbols() {
		if (!DualLogic.isPure(kt))
			return new HashSet();
		else return symbols();
	}
	
	public Set linearSymbols() {
		if (DualLogic.isPure(kt))
			return new HashSet();
		else return symbols();
	}
	
	public Set targets() {
		Set res = new HashSet();
		res.add(kind.toString());
		return res;
	}
	
	public String toString() {
		return kind.toString();
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public Kind getKind() {
		return kind;
	}
	
	public Type getType() {
		return kt;
	}

}
