package specjava.logic.formula;

import java.util.HashSet;
import java.util.Set;

import specjava.logic.formula.predicate.Predicate;
import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public final class False implements Formula, Predicate {

	private static final long serialVersionUID = 1384009254524761007L;

	public String toString() { return "false"; }
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public boolean isCanonical() {
		return true;
	}
	
	public Set symbols() {
		return new HashSet();
	}
	
	public Set pureSymbols() {
		return new HashSet();
	}
	
	public Set linearSymbols() {
		return new HashSet();
	}

	public Set targets() {
		return new HashSet();
	}

	public Formula cnf() {
		return this;
	}

	public int arity() {
		return 0;
	}

	public Term getTerm(int n) throws IndexOutOfBoundsException {
		throw new IndexOutOfBoundsException();
	}
}
