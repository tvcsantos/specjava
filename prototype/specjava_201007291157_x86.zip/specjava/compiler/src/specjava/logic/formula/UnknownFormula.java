package specjava.logic.formula;

import java.util.Set;

import specjava.logic.visit.PLVisitor;

public class UnknownFormula extends AbstractFormula {

	private static final long serialVersionUID = 3317950251629127626L;

	public Object accept(PLVisitor pv) {
		return this;
	}

	public boolean isCanonical() {
		return false;
	}
	
	public String toString() {
		return "<unknown>";
	}

	public Set symbols() {
		throw new UnsupportedOperationException();
	}
	
	public Set pureSymbols() {
		throw new UnsupportedOperationException();
	}
	
	public Set linearSymbols() {
		throw new UnsupportedOperationException();
	}

	public Set targets() {
		throw new UnsupportedOperationException();
	}

}
