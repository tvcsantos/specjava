package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Div extends AbstractFunction {
	
	private static final long serialVersionUID = 5222177204324501510L;
	
	private final boolean real;

	public Div(Term left, Term right, boolean real) {
		super(new Term[]{left, right});
		this.real = real;		
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public boolean isReal() {
		return real;
	}
}
