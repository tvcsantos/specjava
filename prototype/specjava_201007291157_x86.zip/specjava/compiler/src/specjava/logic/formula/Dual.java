package specjava.logic.formula;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import polyglot.ast.NodeFactory;
import specjava.logic.visit.VisitorException;

public interface Dual extends Serializable {
	public static final Dual TRUE_EMPTY =
		new DualImpl(Formula.TRUE, new LinkedList());
	public static final Dual FALSE_EMPTY =
		new DualImpl(Formula.FALSE, new LinkedList());
	
	Formula classicFormula();
	
	List sepLogicFormulas();
	
	boolean isCanonical();
	
	Dual expr(NodeFactory nf) throws VisitorException;
}
