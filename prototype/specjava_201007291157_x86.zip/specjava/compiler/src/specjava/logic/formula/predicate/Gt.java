package specjava.logic.formula.predicate;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Gt extends AbstractPredicate {

	private static final long serialVersionUID = -1387044646931162088L;

	public Gt(Term left, Term right) {
		super(new Term[]{left, right});
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}
