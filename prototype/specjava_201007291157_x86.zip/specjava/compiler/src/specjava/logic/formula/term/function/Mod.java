package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Mod extends AbstractFunction {

	private static final long serialVersionUID = -8851035042891487664L;

	public Mod(Term left, Term right) {
		super(new Term[]{left, right});
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}
