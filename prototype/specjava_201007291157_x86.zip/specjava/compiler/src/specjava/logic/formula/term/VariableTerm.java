package specjava.logic.formula.term;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Expr;
import polyglot.ast.Field;
import polyglot.ast.Local;
import polyglot.ast.NamedVariable;
import polyglot.ast.NodeFactory;
import polyglot.ast.Special;
import polyglot.ast.Special.Kind;
import polyglot.types.LocalInstance;
import polyglot.types.Type;
import polyglot.types.UnknownType;
import polyglot.util.Position;
import specjava.ast.specification.formula.atomic.FieldPath;
import specjava.logic.DualLogic;
import specjava.logic.Utils;
import specjava.logic.formula.AbstractFormula;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public final class VariableTerm implements Term {

	private static final long serialVersionUID = -1462869784577680211L;
	
	private String x;
	private Type xtype;
	private Position pos;
	
	////// WHEN FIELD //////
	private boolean field;
	private FieldPath fp;
	////////////////////////
	
	////// WHEN LOCAL //////
	private boolean local;
	private LocalInstance li;
	////////////////////////
	
	////// WHEN SPECIAL //////	
	private boolean special;
	private Kind k;
	//////////////////////////
	
	private transient Expr expr;

	public VariableTerm(Expr v) {
		this.expr = v;
		this.x = v.toString();
		this.xtype = v.type();
		this.pos = v.position();
		if (v instanceof Field) {
			Field f = (Field)v;
			this.fp = Utils.getFieldPathSilent(f);
			field = true;
		} else if (v instanceof Local) {
			Local l = (Local)v;
			this.li = l.localInstance();
			local = true;
		} else if (v instanceof Special) {
			Special s = (Special)v;
			this.k = s.kind();
			special = true;
		}
	}
	
	public VariableTerm(NamedVariable nv) {
		this.expr = nv;
		this.x = nv.toString();
		this.xtype = nv.type();
		this.pos = nv.position();
		if (nv instanceof Field) {
			Field f = (Field)nv;
			this.fp = Utils.getFieldPathSilent(f);
			field = true;
		} else if (nv instanceof Local) {
			Local l = (Local)nv;
			this.li = l.localInstance();
			local = true;
		}
	}
	
	public VariableTerm(Field f) {
		this.expr = f;
		this.x = f.toString();
		this.xtype = f.type();
		this.pos = f.position();
		this.fp = Utils.getFieldPathSilent(f);
		field = true;
	}
	
	public VariableTerm(Field f, FieldPath fp) {
		this.expr = f;
		this.x = f.toString();
		this.xtype = f.type();
		this.pos = f.position();
		this.fp = fp;
		field = true;
	}
	
	public VariableTerm(Local l) {
		this.expr = l;
		this.x = l.toString();
		this.xtype = l.type();
		this.pos = l.position();
		this.li = l.localInstance();
		local = true;
	}
	
	public VariableTerm(Special s) {
		this.expr = s;
		this.x = s.toString();
		this.xtype = s.type();
		this.pos = s.position();
		this.k = s.kind();
		this.special = true;
	}
	
	public VariableTerm initExpr(NodeFactory nf) {
		if (expr != null) 
			return this;
		if (field) {
			Field f = fp.toField(nf);
			return new VariableTerm(f, fp); 
		} else if (local) {
			Local l = (Local) nf.Local(pos,
					nf.Id(pos, li.name())).localInstance(li).type(xtype);
			return new VariableTerm(l);
		} else { //if (isSpecial) {
			Special s = (Special) nf.Special(pos, k).type(xtype);
			return new VariableTerm(s);
		}
	}
	
	public boolean isCanonical() {
		return xtype != null && !(xtype instanceof UnknownType);
	}

	public Set symbols() {
		if (expr == null) {
			Set res = new HashSet();
			res.add(x);
			return res;
		}
		return AbstractFormula.symbols(expr);
	}
	
	public Set pureSymbols() {
		if (!DualLogic.isPure(xtype))
			return new HashSet();
		else {
			if (expr == null) {
				Set res = new HashSet();
				res.add(x);
				return res;
			}
			return AbstractFormula.variables(expr, true);
		}
	}
	
	public Set linearSymbols() {
		if (DualLogic.isPure(xtype))
			return new HashSet();
		else {
			if (expr == null) {
				Set res = new HashSet();
				res.add(x);
				return res;
			}
			return AbstractFormula.variables(expr, false);
		}
	}
	
	public Set targets() {
		if (expr == null) {
			Set res = new HashSet();
			res.add(x);
			return res;
		}
		return AbstractFormula.vars(expr);
	}
	
	public String toString() {
		return expr != null ? expr.toString() : x;
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public boolean isField() {
		return field;
	}

	public boolean isLocal() {
		return local;
	}

	public boolean isSpecial() {
		return special;
	}
	
	public Field toField() {
		return (Field)expr;
	}
	
	public Local toLocal() {
		return (Local)expr;
	}
	
	public Special toSpecial() {
		return (Special)expr;
	}
	
	public Expr getExpr() {
		return expr;
	}
	
}
