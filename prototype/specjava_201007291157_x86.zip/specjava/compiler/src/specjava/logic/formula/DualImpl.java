package specjava.logic.formula;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import polyglot.ast.NodeFactory;
import polyglot.util.TypedList;
import specjava.logic.Utils;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.visit.AbstractPLVisitor;
import specjava.logic.visit.VisitorException;

public class DualImpl implements Dual {
	
	private static final long serialVersionUID = -7403097295537160726L;

	private Formula classicFormula;
	private List sepLogicFormulas;
	
	public DualImpl(Formula classicFormula,
			List sepLogicFormulas) {
		this.classicFormula = classicFormula;
		this.sepLogicFormulas = 
			TypedList.copyAndCheck(sepLogicFormulas, Formula.class, true);
	}

	public Formula classicFormula() {
		return classicFormula;
	}

	public List sepLogicFormulas() {
		return Collections.unmodifiableList(sepLogicFormulas);
	}
	
	public String toString() {
		return classicFormula + " + " + sepLogicFormulas;
	}
	
	public boolean isCanonical() {
		if (!classicFormula.isCanonical())
			return false;
		for (Iterator i = sepLogicFormulas.iterator(); i.hasNext(); )
			if (!((Formula)i.next()).isCanonical()) return false;
		return true;
	}
	
	public Dual expr(NodeFactory nf) throws VisitorException {
		ExpressionCreator ec = new ExpressionCreator(nf);
		Formula cf = (Formula) classicFormula.accept(ec);
		List l = Utils.visitList(sepLogicFormulas, ec);
		return new DualImpl(cf, l);
	}

	
	private class ExpressionCreator extends AbstractPLVisitor {
		private NodeFactory nf;
		
		public ExpressionCreator(NodeFactory nf) {
			this.nf = nf;
		}
		
		public Term visit(VariableTerm v) {
			return v.initExpr(nf);
		}
	}
}
