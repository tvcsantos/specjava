package specjava.logic.formula.binary;

import java.util.HashSet;
import java.util.Set;

import specjava.logic.formula.AbstractFormula;
import specjava.logic.formula.Formula;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Or extends AbstractFormula implements Formula {

	private static final long serialVersionUID = -7387915591804631567L;
	
	protected Formula left;
	protected Formula right;
	
	public Or(Formula left, Formula right) {
		this.left = left;
		this.right = right;
	}
	
	public String toString() {
		return "(" + left.toString() + " | " + right.toString() + ")";
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public Formula getLeft() {
		return left;
	}

	public Formula getRight() {
		return right;
	}
	
	public boolean isCanonical() {
		return left.isCanonical() && right.isCanonical();
	}
	
	public Set symbols() {
		Set res = new HashSet();
		res.addAll(left.symbols());
		res.addAll(right.symbols());
		return res;
	}
	
	public Set pureSymbols() {
		Set res = new HashSet();
		res.addAll(left.pureSymbols());
		res.addAll(right.pureSymbols());
		return res;
	}
	
	public Set linearSymbols() {
		Set res = new HashSet();
		res.addAll(left.linearSymbols());
		res.addAll(right.linearSymbols());
		return res;
	}
	
	public Set targets() {
		Set res = new HashSet();
		res.addAll(left.targets());
		res.addAll(right.targets());
		return res;
	}
}
