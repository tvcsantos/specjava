package specjava.logic.formula.predicate;

import specjava.logic.formula.Formula;
import specjava.logic.formula.term.Term;

public interface Predicate extends Formula {
	public Term getTerm(int n) throws IndexOutOfBoundsException;
	public int arity();
}
