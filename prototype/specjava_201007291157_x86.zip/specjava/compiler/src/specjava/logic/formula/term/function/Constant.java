package specjava.logic.formula.term.function;

import java.util.HashSet;
import java.util.Set;

import polyglot.ast.Lit;
import polyglot.types.Type;
import polyglot.types.UnknownType;
import polyglot.util.Position;
import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public final class Constant implements Function {

	private static final long serialVersionUID = -232037678151295374L;
	
	private String x;
	private Type xtype;
	private Position pos;
	
	private transient Lit expr;
	
	public Constant(Lit lit) {
		this.xtype = lit.type();
		this.pos = lit.position();
		this.expr = lit;
	}
	
	public boolean isCanonical() {
		return xtype != null && !(xtype instanceof UnknownType);
	}

	public Set symbols() {
		return new HashSet();
	}
	
	public Set pureSymbols() {
		return new HashSet();
	}
	
	public Set linearSymbols() {
		return new HashSet();
	}
	
	public Set targets() {
		return new HashSet();
	}
	
	public String toString() {
		return expr != null ? expr.toString() : x;
	}

	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public int arity() {
		return 0;
	}

	public Term getTerm(int n) throws IndexOutOfBoundsException {
		throw new IndexOutOfBoundsException();
	}
	
	public Position getPosition() {
		return pos;
	}
	
}
