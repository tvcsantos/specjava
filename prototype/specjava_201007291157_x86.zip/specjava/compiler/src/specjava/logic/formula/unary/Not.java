package specjava.logic.formula.unary;

import java.util.Set;

import specjava.logic.formula.AbstractFormula;
import specjava.logic.formula.Formula;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Not extends AbstractFormula implements Formula {

	private static final long serialVersionUID = -4290454487775972134L;
	
	protected Formula cond;
	
	public Not(Formula cond) {
		this.cond = cond;
	}
	
	public String toString() {
		return "!" + "(" + cond.toString() + ")";
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
	
	public Formula getNegated() {
		return cond;
	}
	
	public boolean isCanonical() {
		return cond.isCanonical();
	}
	
	public Set symbols() {
		return cond.symbols();
	}
	
	public Set pureSymbols() {
		return cond.pureSymbols();
	}
	
	public Set linearSymbols() {
		return cond.linearSymbols();
	}
	
	public Set targets() {
		return cond.targets();
	}
}
