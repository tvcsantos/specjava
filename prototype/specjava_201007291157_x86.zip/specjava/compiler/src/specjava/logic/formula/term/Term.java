package specjava.logic.formula.term;

import java.io.Serializable;
import java.util.Set;

import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public interface Term extends Serializable {
	public Set symbols();
	public boolean isCanonical();
	public Object accept(PLVisitor pv) throws VisitorException;
	public Set pureSymbols();
	public Set linearSymbols();
	public Set targets();
}
