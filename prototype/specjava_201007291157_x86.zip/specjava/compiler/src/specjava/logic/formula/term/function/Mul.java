package specjava.logic.formula.term.function;

import specjava.logic.formula.term.Term;
import specjava.logic.visit.PLVisitor;
import specjava.logic.visit.VisitorException;

public class Mul extends AbstractFunction {
	
	private static final long serialVersionUID = -1923020553668829234L;

	public Mul(Term left, Term right) {
		super(new Term[]{left, right});
	}
	
	public Object accept(PLVisitor pv) throws VisitorException {
		return pv.visit(this);
	}
}

