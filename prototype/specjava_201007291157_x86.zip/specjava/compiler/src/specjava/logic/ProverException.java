package specjava.logic;

public class ProverException extends Exception {

	private static final long serialVersionUID = -2986529837528240799L;

	public ProverException() {
		super();
	}

	public ProverException(String m, Throwable cause) {
		super(m, cause);
	}

	public ProverException(String m) {
		super(m);
	}

	public ProverException(Throwable cause) {
		super(cause);
	}

	
}
