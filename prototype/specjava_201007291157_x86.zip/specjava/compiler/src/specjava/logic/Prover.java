package specjava.logic;

public interface Prover {
	
	public static final int UNSAT = 1;
	public static final int SAT = 2;
	public static final int VALID = 4;
	public static final int UNKNOWN = 6;
	
	//UNSAT -> !VALID && !SAT
	//SAT -> !UNSAT
	//VALID -> SAT && !UNSAT

	public Result prove(boolean valid) throws ProverException;
}