package specjava.logic.visit;

import specjava.logic.formula.False;
import specjava.logic.formula.Formula;
import specjava.logic.formula.True;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.predicate.Eq;
import specjava.logic.formula.predicate.Gt;
import specjava.logic.formula.predicate.Lt;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.SpecialTerm;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.formula.term.function.Constant;
import specjava.logic.formula.term.function.Div;
import specjava.logic.formula.term.function.Minus;
import specjava.logic.formula.term.function.Mod;
import specjava.logic.formula.term.function.Mul;
import specjava.logic.formula.term.function.Plus;
import specjava.logic.formula.unary.Not;

public abstract class AbstractPLVisitor implements PLVisitor {

	public Formula visit(And fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		return new And(sl, sr);
	}

	public Formula visit(Equivalence fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		return new Equivalence(sl, sr);
	}

	public Formula visit(False fs) {
		return fs;
	}

	public Formula visit(Implication fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		return new Implication(sl, sr);
	}

	public Formula visit(Not fs) throws VisitorException {
		Formula ns = (Formula) fs.getNegated().accept(this);
		return new Not(ns);
	}

	public Formula visit(Or fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		return new Or(sl, sr);
	}

	public Formula visit(True ts) throws VisitorException {
		return ts;
	}
	
	public Formula visit(Eq eq) throws VisitorException {
		Term lt = (Term) eq.getTerm(0).accept(this);
		Term rt = (Term) eq.getTerm(1).accept(this);
		return new Eq(lt, rt);
	}
	
	public Formula visit(Gt gt) throws VisitorException {
		Term lt = (Term) gt.getTerm(0).accept(this);
		Term rt = (Term) gt.getTerm(1).accept(this);
		return new Gt(lt, rt);
	}
	
	public Formula visit(Lt lt) throws VisitorException {
		Term let = (Term) lt.getTerm(0).accept(this);
		Term rt = (Term) lt.getTerm(1).accept(this);
		return new Lt(let, rt);
	}
	
	public Formula visit(StatePredicate sp) throws VisitorException {
		Term t = (Term) sp.getTerm(0).accept(this);
		return new StatePredicate(sp.getProperty(), t);
	}
		
	public Term visit(Div div) throws VisitorException {
		Term lt = (Term) div.getTerm(0).accept(this);
		Term rt = (Term) div.getTerm(1).accept(this);
		return new Div(lt, rt, div.isReal());
	}

	public Term visit(Minus minus) throws VisitorException {
		Term lt = (Term) minus.getTerm(0).accept(this);
		if (minus.arity() == 1)
			return new Minus(lt);
		Term rt = (Term) minus.getTerm(1).accept(this);
		return new Minus(lt, rt);
	}
	
	public Term visit(Mod mod) throws VisitorException {
		Term lt = (Term) mod.getTerm(0).accept(this);
		Term rt = (Term) mod.getTerm(1).accept(this);
		return new Mod(lt, rt);
	}
	
	public Term visit(Mul mul) throws VisitorException {
		Term lt = (Term) mul.getTerm(0).accept(this);
		Term rt = (Term) mul.getTerm(1).accept(this);
		return new Mul(lt, rt);
	}

	public Term visit(Plus plus) throws VisitorException {
		Term lt = (Term) plus.getTerm(0).accept(this);
		if (plus.arity() == 1)
			return new Plus(lt);
		Term rt = (Term) plus.getTerm(1).accept(this);
		return new Plus(lt, rt);
	}
	
	public Term visit(SpecialTerm st) throws VisitorException {
		return st;
	}
	
	public Term visit(VariableTerm v) throws VisitorException {
		return v;
	}
	
	public Term visit(Constant c) throws VisitorException {
		return c;
	}
}
