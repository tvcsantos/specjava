package specjava.logic.visit;

import specjava.logic.formula.Formula;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Or;

public class DistributeOrOverAnd extends AbstractPLVisitor {

	public Formula visit(Or fs) throws VisitorException {
		// Distribute and over or
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		
		//a or (b and c) = (a or b) and (a or c)
		if (sr instanceof And) {
			And ad = (And)sr;
			Formula b = ad.getLeft();
			Formula c = ad.getRight();
			return new And((Formula) new Or(sl, b).accept(this), 
					(Formula) new Or(sl, c).accept(this));
		}		
		
		//(a and b) or c = (a or c) and (b or c)
		if (sl instanceof And) {
			And ad = (And)sl;
			Formula a = ad.getLeft();
			Formula b = ad.getRight();
			return new And((Formula) new Or(a, sr).accept(this),
					(Formula) new Or(b, sr).accept(this));
		}
		
		return new Or(sl, sr);
	}	
}
