package specjava.logic.visit;

public class VisitorException extends Exception {

	private static final long serialVersionUID = 6783204738011641456L;

	public VisitorException() {
		super();
	}

	public VisitorException(String message, Throwable cause) {
		super(message, cause);
	}

	public VisitorException(String message) {
		super(message);
	}

	public VisitorException(Throwable cause) {
		super(cause);
	}

	
}
