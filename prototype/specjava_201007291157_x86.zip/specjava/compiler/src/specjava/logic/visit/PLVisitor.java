package specjava.logic.visit;

import specjava.logic.formula.False;
import specjava.logic.formula.True;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.predicate.Eq;
import specjava.logic.formula.predicate.Gt;
import specjava.logic.formula.predicate.Lt;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.SpecialTerm;
import specjava.logic.formula.term.VariableTerm;
import specjava.logic.formula.term.function.Constant;
import specjava.logic.formula.term.function.Div;
import specjava.logic.formula.term.function.Minus;
import specjava.logic.formula.term.function.Mod;
import specjava.logic.formula.term.function.Mul;
import specjava.logic.formula.term.function.Plus;
import specjava.logic.formula.unary.Not;

public interface PLVisitor {
	
	/// VISIT FORMULA ///	
	public Object visit(True ts) throws VisitorException;

	public Object visit(False fs) throws VisitorException;

	public Object visit(Not fs) throws VisitorException;

	public Object visit(Equivalence fs) throws VisitorException;
	
	public Object visit(Implication fs) throws VisitorException;
	
	public Object visit(And fs) throws VisitorException;
	
	public Object visit(Or fs) throws VisitorException;
	
	/// VISIT PREDICATE ///
	public Object visit(Eq eq) throws VisitorException;
	
	public Object visit(Gt gt) throws VisitorException;
	
	public Object visit(Lt lt) throws VisitorException;
	
	public Object visit(StatePredicate sp) throws VisitorException;
	
	/// VISIT TERM ///
	public Object visit(Div div) throws VisitorException;
	
	public Object visit(Minus minus) throws VisitorException;
	
	public Object visit(Mod mod) throws VisitorException;
	
	public Object visit(Mul mul) throws VisitorException;
	
	public Object visit(Plus plus) throws VisitorException;
		
	public Object visit(SpecialTerm st) throws VisitorException;

	public Object visit(VariableTerm v) throws VisitorException;
	
	public Object visit(Constant c) throws VisitorException;
}
