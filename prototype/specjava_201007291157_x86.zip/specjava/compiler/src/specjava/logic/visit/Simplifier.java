package specjava.logic.visit;

import specjava.logic.formula.False;
import specjava.logic.formula.Formula;
import specjava.logic.formula.True;
import specjava.logic.formula.binary.And;
import specjava.logic.formula.binary.Equivalence;
import specjava.logic.formula.binary.Implication;
import specjava.logic.formula.binary.Or;
import specjava.logic.formula.predicate.StatePredicate;
import specjava.logic.formula.term.Term;
import specjava.logic.formula.unary.Not;

public class Simplifier extends AbstractPLVisitor {

	public Simplifier() {
		
	}
	
	public Formula visit(Not fs) throws VisitorException {
		Formula neg = (Formula) fs.getNegated().accept(this);
		
		if (neg instanceof Not)
			return ((Not) neg).getNegated();
		
		if (neg instanceof True)
			return Formula.FALSE;
		
		if (neg instanceof False)
			return Formula.TRUE;
		
		return new Not(neg);
	}
	
	public Formula visit(And fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		
		if (sl instanceof True) return sr;
		if (sr instanceof True) return sl;
		
		if (sl instanceof False || sr instanceof False) 
			return Formula.FALSE;
		
		return new And(sl, sr);
	}
	
	public Formula visit(Or fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		
		if (sl instanceof True || sr instanceof True)
			return Formula.TRUE;
		
		if (sl instanceof False) return sr;
		if (sr instanceof False) return sl;
		
		return new Or(sl, sr);
	}
	
	public Formula visit(Implication fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		
		if (sr instanceof True || sl instanceof False)
			return Formula.TRUE;
		
		if (sl instanceof True && sr instanceof False)
			return Formula.FALSE;
		
		if (sl instanceof True)
			return sr;
		
		return new Implication(sl, sr);
	}
	
	public Formula visit(Equivalence fs) throws VisitorException {
		Formula sl = (Formula) fs.getLeft().accept(this);
		Formula sr = (Formula) fs.getRight().accept(this);
		
		if ((sl instanceof True && sr instanceof True)
				|| (sl instanceof False && sr instanceof False))
			return Formula.TRUE;
		
		if ((sl instanceof False && sr instanceof True)
				|| (sl instanceof True && sr instanceof False))
			return Formula.FALSE;
		
		if (sl instanceof False)
			return (Formula) new Not(sr).accept(this);
		else if (sl instanceof True)
			return sr;
		
		if (sr instanceof False)
			return (Formula) new Not(sl).accept(this);
		else if (sr instanceof True)
			return sl;
		
		return new Equivalence(sl, sr);			
	}
	
	public Formula visit(StatePredicate sp) throws VisitorException {
		String prop = sp.getProperty();
		Term t = sp.getTerm(0);
		String x = t.toString();
		if (prop.compareTo("null") == 0) {
			if (x.compareTo("null") == 0)
				return Formula.TRUE;
			else if (x.compareTo("this") == 0)
				return Formula.FALSE;
		} else if (prop.compareTo("true") == 0) {
			if (x.compareTo("true") == 0)
				return Formula.TRUE;
			else if (x.compareTo("false") == 0)
				return Formula.FALSE;
		} else if (prop.compareTo("false") == 0) {
			if (x.compareTo("true") == 0)
				return Formula.FALSE;
			else if (x.compareTo("false") == 0)
				return Formula.TRUE;
		} else if (x.compareTo("null") == 0)
				return Formula.FALSE;
		return sp;
	}
}
