package specjava.logic;

public class VisitorException extends Exception {

	private static final long serialVersionUID = -2099919867382249427L;

	public VisitorException() {
	}

	public VisitorException(String message) {
		super(message);
	}

	public VisitorException(Throwable cause) {
		super(cause);
	}

	public VisitorException(String message, Throwable cause) {
		super(message, cause);
	}

}
